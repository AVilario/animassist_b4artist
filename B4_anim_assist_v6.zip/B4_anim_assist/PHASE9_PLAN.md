# Phase 9 Implementation Plan — Mirroring, Opposite-Side Pairing, Symmetry Helpers

## A. Objective
Implement mirrored-control and symmetry workflows for character animation, enabling animators to detect left/right bone pairs, mirror poses and keyframes across sides, manage pair mappings for non-standard rigs, and batch-process mirror operations across selections and frame ranges.

## B. Dependencies from Prior Phases
- **Phase 8 (`p8_match_math`)**: Reuses `mirror_name()` for basic L/R naming swap, `compute_match()` for transform matching, `ChannelFilter`/`AxisMask` for channel filtering, `visual_world_matrix()` for evaluated transforms, `decompose_matrix()`/`compose_matrix()` for TRS decomposition.
- **Phase 8 (`p8_switch_detect`)**: Reuses `SwitchPattern` for mirroring switch targets by naming (Feature 40).
- **Phase 7 (`p7_session`)**: Referenced for mirroring proxy helpers by naming (Feature 41).
- **Core infrastructure**: `ui_helpers`, `PanelAnatomyMixin`, `DopeSheetSidebarPanel`/`View3DSidebarPanel`, `make_editor_variants`, `HelpEntry`, logging, `ClassRegistry`.

## C. File/Module Layout

```
anim_assist/
├── core/
│   ├── p9_pair_detect.py      [NEW] — Pair detection engine (Features 1-5, 17)
│   ├── p9_mirror_math.py      [NEW] — Mirror transform math (Features 11-16, 23-27)
│   ├── p9_pair_cache.py       [NEW] — Opposite target cache (Feature 5)
│   ├── p9_properties.py       [NEW] — Scene-scoped PropertyGroup
│   ├── help_phase9_entries.py  [NEW] — 45 HelpEntry records
│   └── app_handlers.py        [UPDATED] — Clear P9 caches on load_post
├── operators/
│   ├── __init__.py             [UPDATED] — Add P9 imports and CLASSES
│   ├── p9_select_ops.py       [NEW] — Selection operators (Features 6-8)
│   ├── p9_mirror_ops.py       [NEW] — Mirror operators (Features 9-16, 18-28)
│   ├── p9_pair_ops.py         [NEW] — Pair management (Features 34-36, 40-42, 44-45)
│   └── p9_batch_ops.py        [NEW] — Batch mirror + reports (Features 29-33, 37-39, 43)
├── ui/
│   ├── __init__.py             [UPDATED] — Add P9 panel imports
│   └── p9_panels.py           [NEW] — Panels for Dope Sheet + View 3D
├── __init__.py                 [UPDATED] — P9 registration wiring
└── tests/
    └── test_p9_pair_detect.py  [NEW] — Unit tests
```

## D. Pair Detection Rules and Precedence

Detection order (first match wins):
1. **Manual override table** — user-defined pairs in scene PropertyGroup, highest priority
2. **Naming exceptions** — renames that don't follow standard patterns
3. **`.L` / `.R` suffix** — e.g., `Hand.L` ↔ `Hand.R`, `Finger_01.L` ↔ `Finger_01.R`
4. **`_L` / `_R` suffix** — e.g., `Hand_L` ↔ `Hand_R`
5. **`_l` / `_r` suffix** — lowercase variant
6. **`Left` / `Right` substring** — e.g., `LeftHand` ↔ `RightHand`
7. **`left` / `right` substring** — lowercase variant
8. **Custom pattern presets** — user-defined regex patterns stored in scene

The `p9_pair_detect` module exposes `find_opposite(name, overrides, exceptions, custom_patterns) -> str | None` that walks these in order.

## E. Mirrored Transform Strategy

Mirror transform = negate specific axes while preserving others.

For a standard biped rig (root facing +Y):
- **Location**: negate X (left/right axis)
- **Rotation Euler**: negate Y and Z (keep X)
- **Scale**: copy as-is (no negation)

The `p9_mirror_math` module provides:
- `mirror_transform(loc, rot, sca, mirror_axis='X')` → mirrored (loc, rot, sca)
- `compute_mirror_matrix(source_matrix, mirror_axis)` → Matrix
- `apply_mirror_to_bone(src_bone, dst_bone, mirror_axis, channel_filter)` — writes mirrored values
- `swap_bone_transforms(bone_a, bone_b)` — for L/R swap operations

Visual mirror (Feature 25): uses evaluated depsgraph matrices and `compute_match()` to handle constrained rigs where direct value copy breaks IK/constraints.

## F. Manual Override and Preset Representation

- **Manual pairs**: CollectionProperty of `AA_P9_PairOverride` items, each with `bone_a: StringProperty` and `bone_b: StringProperty`
- **Naming exceptions**: CollectionProperty of `AA_P9_NamingException` items, each with `original: StringProperty` and `opposite: StringProperty`
- **Pair presets**: JSON serialized to scene custom properties, keyed by `"anim_assist_p9_pair_presets"`. Save/load via operators.

## G. Batch Workflow Behavior

- **Batch mirror across selected** (Feature 29): iterates all selected pose bones, finds each opposite, mirrors transform. Skips bones without a detected pair (logs warning).
- **Batch mirror from active side** (Feature 30): detects which side the active bone is on (L or R), mirrors ALL bones of that side to their opposites.
- **Frame range operations** (Features 18-20): loop over frames, set frame, mirror, insert keyframe. Uses `bpy.context.scene.frame_set()` for depsgraph evaluation.

## H. Reporting and Warning Systems

- **Per-target mirror report** (Feature 31): `analysis_box` showing what was mirrored and to where
- **Missing opposite warning** (Feature 32): `draw_context_warning` for bones with no detected pair
- **Ambiguous pair warning** (Feature 33): when multiple patterns match a bone, shows which was selected
- **Pair-map validation** (Feature 45): diagnostic operator that scans all pose bones, reports paired/unpaired/ambiguous counts

## I. UI Strategy

**Primary panel** — Dope Sheet sidebar (keyframe-centric mirror workflows):
- `draw_primary`: Mirror Pose, Swap L/R, Quick Mirror buttons
- `draw_scope`: Channel filters (loc/rot/sca), axis mask, mirror space (local/world/visual)
- `draw_advanced`: Pair detection settings, naming patterns, exceptions table, presets, pair manager

**Secondary panel** — View 3D sidebar (pose-oriented):
- Lightweight mirror + select opposite tools

**Graph Editor variant** — via `make_editor_variants` (mirror keyed channels)

## J. Help System Integration

- 45 HelpEntry records in `help_phase9_entries.py`
- 8 categories: Pair Detection, Opposite Selection, Mirror Transforms, Mirror Scope, Mirror Space, Pair Management, Batch Mirror, Mirror Diagnostics
- `register()` / `unregister()` wrappers calling `register_phase_help("phase9", entries)` / `unregister_phase_help("phase9")`
- `explained_op()` used for all operator buttons in panels
- `explained_prop()` used for naming pattern selectors, mirror axis, space mode

## K. Edge Cases

- **Asymmetrical rigs**: bones without an opposite silently skip in batch (no crash), warning in report
- **Naming collisions**: manual override takes priority; detection returns first match
- **Missing opposite**: `find_opposite()` returns None, operator reports warning, skips bone
- **Constrained bones**: visual mirror (Feature 25) uses depsgraph-evaluated matrices to compute correct target values even when IK/constraints are active
- **Different rest orientations**: mirror math operates on pose-space values relative to rest pose; does NOT assume rest poses are symmetric (handles offset via current evaluation)

## L. Excluded Overlapping Animaide-Style Features

- NO ease/blend/smooth/noise/overshoot tools
- NO generic curve shaping operators
- NO breakdancer/match-and-paste tools (covered by Phase 3/8)
- NO pose library integration (Blender has its own)

## M. Feature-to-Module Mapping

| # | Feature | Module |
|---|---------|--------|
| 1 | Detect .L/.R | `p9_pair_detect` |
| 2 | Detect _L/_R | `p9_pair_detect` |
| 3 | Detect Left/Right | `p9_pair_detect` |
| 4 | Custom naming presets | `p9_pair_detect` + `p9_pair_ops` |
| 5 | Opposite target cache | `p9_pair_cache` |
| 6 | Select opposite | `p9_select_ops` |
| 7 | Add opposite to selection | `p9_select_ops` |
| 8 | Swap active and opposite | `p9_select_ops` |
| 9 | Match active to opposite | `p9_mirror_ops` |
| 10 | Match opposite to active | `p9_mirror_ops` |
| 11 | Mirror pose to opposite | `p9_mirror_ops` |
| 12 | Mirror selected subset | `p9_mirror_ops` |
| 13 | Mirror location only | `p9_mirror_ops` |
| 14 | Mirror rotation only | `p9_mirror_ops` |
| 15 | Mirror scale only | `p9_mirror_ops` |
| 16 | Axis-aware mirror masks | `p9_mirror_math` + `p9_properties` |
| 17 | Naming exceptions table | `p9_properties` + `p9_pair_ops` |
| 18 | Mirror selected frame | `p9_mirror_ops` |
| 19 | Mirror key range | `p9_mirror_ops` |
| 20 | Mirror preview range | `p9_mirror_ops` |
| 21 | Mirror keyed channels only | `p9_mirror_ops` |
| 22 | Mirror visible channels only | `p9_mirror_ops` |
| 23 | Mirror local space | `p9_mirror_math` |
| 24 | Mirror world space | `p9_mirror_math` |
| 25 | Visual mirror (constrained) | `p9_mirror_math` + `p9_mirror_ops` |
| 26 | Mirror with offset | `p9_mirror_ops` |
| 27 | Mirror without offset | `p9_mirror_ops` |
| 28 | Swap L/R poses | `p9_mirror_ops` |
| 29 | Batch mirror selected | `p9_batch_ops` |
| 30 | Batch mirror from active side | `p9_batch_ops` |
| 31 | Per-target mirror report | `p9_batch_ops` |
| 32 | Missing opposite warning | `p9_batch_ops` |
| 33 | Ambiguous pair warning | `p9_batch_ops` |
| 34 | Pair manager UI | `p9_pair_ops` + `p9_panels` |
| 35 | Manual pair override | `p9_pair_ops` + `p9_properties` |
| 36 | Save/load pair presets | `p9_pair_ops` |
| 37 | Opposite channel resolver | `p9_batch_ops` |
| 38 | Mirror metadata | `p9_batch_ops` |
| 39 | Mirror transform presets | `p9_batch_ops` |
| 40 | Mirror switch targets | `p9_pair_ops` |
| 41 | Mirror proxy helpers | `p9_pair_ops` |
| 42 | Mirror selection sets | `p9_pair_ops` |
| 43 | Repeat last mirror | `p9_batch_ops` |
| 44 | Next unpaired navigation | `p9_pair_ops` |
| 45 | Pair-map validation | `p9_pair_ops` |
