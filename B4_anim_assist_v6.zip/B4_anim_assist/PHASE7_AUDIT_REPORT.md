# ANIM ASSIST — PHASE 7 SYSTEMS INTEGRITY AUDIT

---

## 1. GATE DECISION

# REWORK

Two HIGH-severity findings prevent GO. Zero CRITICAL findings.

---

## 2. EXECUTIVE SUMMARY

- Phase 7 is **structurally sound** and integrates cleanly into the existing anim_assist codebase. The registration chain, help system, panel anatomy, and session lifecycle are well-architected.
- **48 operators** across 6 operator files cover all 45 spec features plus 3 utility/session operators. 53 unit tests pass. Zero syntax errors. Zero duplicate `bl_idname` values.
- **HIGH-1: rename_proxy has a session-tracking bug** — `old_name` is captured AFTER the rename assignment, so the session registry update never fires. This means renamed proxies become orphans that cleanup cannot find.
- **HIGH-2: apply_offset overwrites instead of adding** — described as "additive offset" but actually replaces the target's full transform with the proxy's local transform, destroying existing animation.
- **MEDIUM: batch_create_proxies in cleanup_ops has dead code** referencing a `display_type == "CURVE"` branch that can never be true (no proxy config sets it).
- **MEDIUM: reconnect_session directly accesses private `p7s._sessions` dict**, breaking the session module's encapsulation contract.
- All project invariants (Blender 4.x API, root package, relative imports, no "animbot", no Animaide overlap, full files) are satisfied.
- The UI uses PanelAnatomyMixin correctly with Primary/Scope/Advanced/Destructive sections, and all panels use the established editor_placement and ui_helpers infrastructure.

---

## 3. SPEC COVERAGE MAP

| # | Feature | Status | Implementing File(s) | Operator(s) | Panel | Help Entry |
|---|---------|--------|----------------------|-------------|-------|------------|
| 1 | Create locator at target | Full | p7_locator_ops.py | p7_create_locator | draw_primary | Yes |
| 2 | Create locator at avg selection | Full | p7_locator_ops.py | p7_create_locator_average | draw_primary | Yes |
| 3 | Create locator at cursor | Full | p7_locator_ops.py | p7_create_locator_cursor | draw_primary | Yes |
| 4 | Parent locator to target | Full | p7_locator_ops.py | p7_parent_locator | draw_primary | Yes |
| 5 | Constrain target to locator | Full | p7_locator_ops.py | p7_constrain_target_to_locator | draw_primary | Yes |
| 6 | Constrain locator to target | Full | p7_locator_ops.py | p7_constrain_locator_to_target | draw_primary | Yes |
| 7 | Bake locator from target | Full | p7_locator_ops.py | p7_bake_locator_from_target | draw_primary | Yes |
| 8 | Bake target from locator | Full | p7_locator_ops.py | p7_bake_target_from_locator | draw_primary | Yes |
| 9 | Match target to locator | Full | p7_locator_ops.py | p7_match_target_to_locator | draw_primary | Yes |
| 10 | Match locator to target | Full | p7_locator_ops.py | p7_match_locator_to_target | draw_primary | Yes |
| 11 | Orientation Proxy | Full | p7_proxy_ops.py | p7_create_proxy (ORIENTATION) | draw_primary | Yes |
| 12 | Translation Proxy | Full | p7_proxy_ops.py | p7_create_proxy (TRANSLATION) | draw_primary | Yes |
| 13 | Aim Proxy | Full | p7_proxy_ops.py | p7_create_proxy (AIM) | draw_primary | Yes |
| 14 | Pole Helper | Full | p7_proxy_ops.py | p7_create_proxy (POLE) | draw_primary | Yes |
| 15 | Up-Vector Helper | Full | p7_proxy_ops.py | p7_create_proxy (UP_VECTOR) | draw_primary | Yes |
| 16 | Multi-Target Average | Full | p7_proxy_ops.py | p7_create_proxy (MULTI_TARGET) | draw_primary | Yes |
| 17 | Parent-Space Proxy | Full | p7_proxy_ops.py | p7_create_proxy (PARENT_SPACE) | draw_primary | Yes |
| 18 | World-Space Proxy | Full | p7_proxy_ops.py | p7_create_proxy (WORLD_SPACE) | draw_primary | Yes |
| 19 | Camera-Space Proxy | Full | p7_proxy_ops.py | p7_create_proxy (CAMERA_SPACE) | draw_primary | Yes |
| 20 | Toggle proxy display | Full | p7_manage_ops.py | p7_toggle_display | draw_advanced | Yes |
| 21 | Color coding by type | Full | p7_manage_ops.py | p7_set_proxy_color | draw_advanced | Yes |
| 22 | Proxy naming rules | Partial* | p7_manage_ops.py | p7_rename_proxy | draw_advanced | Yes |
| 23 | Proxy collection manager | Full | p7_manage_ops.py | p7_toggle_collection | draw_advanced | Yes |
| 24 | Cleanup session | Full | p7_cleanup_ops.py | p7_cleanup_session | draw_destructive | Yes |
| 25 | Cleanup all sessions | Full | p7_cleanup_ops.py | p7_cleanup_all | draw_destructive | Yes |
| 26 | Reconnect session | Full | p7_manage_ops.py | p7_reconnect_session | draw_advanced | Yes |
| 27 | Session metadata | Full | p7_manage_ops.py | p7_show_session_info + p7_list_sessions | draw_primary + draw_advanced | Yes |
| 28 | Mute/unmute constraints | Full | p7_manage_ops.py | p7_mute_constraints | draw_advanced | Yes |
| 29 | Lock original target | Full | p7_manage_ops.py | p7_lock_target | draw_advanced | Yes |
| 30 | Quick switch proxy mode | Full | p7_manage_ops.py | p7_switch_proxy_mode | draw_advanced | Yes |
| 31 | Bake selected range | Full | p7_bake_ops.py | p7_bake_range | draw_primary | Yes |
| 32 | Bake preview range | Full | p7_bake_ops.py | p7_bake_preview | draw_primary | Yes |
| 33 | Bake selected channels | Full | p7_bake_ops.py | p7_bake_selected_channels | draw_primary | Yes |
| 34 | Smart bake + key reduction | Full | p7_bake_ops.py | p7_smart_bake + p7_reduce_keys | draw_primary | Yes |
| 35 | Preserve timing | Full | p7_bake_ops.py | p7_bake_preserve_timing | draw_primary | Yes |
| 36 | Proxy offset mode | Partial* | p7_manage_ops.py | p7_apply_offset | draw_advanced | Yes |
| 37 | Zero-out proxy | Full | p7_manage_ops.py | p7_zero_proxy | draw_advanced | Yes |
| 38 | Recenter proxy | Full | p7_manage_ops.py | p7_recenter_proxy | draw_advanced | Yes |
| 39 | Temporary pivot proxy | Full | p7_manage_ops.py | p7_temp_pivot | draw_primary | Yes |
| 40 | Batch proxy creation | Full | p7_cleanup_ops.py | p7_batch_create_proxies | draw_advanced | Yes |
| 41 | Batch cleanup stale | Full | p7_cleanup_ops.py | p7_auto_cleanup | draw_destructive | Yes |
| 42 | Constraint validation | Full | p7_cleanup_ops.py | p7_validate_session | draw_advanced | Yes |
| 43 | Unsupported setup warning | Full | p7_cleanup_ops.py | p7_check_setup | draw_advanced | Yes |
| 44 | Proxy mirroring | Full | p7_cleanup_ops.py | p7_mirror_proxy | draw_advanced | Yes |
| 45 | One-click workflow | Full | p7_cleanup_ops.py | p7_one_click_proxy_bake + p7_one_click_cleanup + p7_quick_proxy + p7_export_session | draw_destructive | Yes |

\* Feature 22 (rename_proxy) — session tracking update is broken due to ordering bug.
\* Feature 36 (apply_offset) — overwrites target transform instead of applying additive delta.

---

## 4. SCORECARD

| Dimension | Rating | Notes |
|-----------|--------|-------|
| S1. Blender API Correctness | PASS | All ops use manual frame_set + keyframe_insert, avoiding bpy.ops.nla.bake context issues. Correct property types, no deprecated API. |
| S2. Animation Math / Data Correctness | WARN | apply_offset (Feature 36) replaces rather than adds. RDP key reduction algorithm is correct. Bake helpers are sound. |
| S3. Registration & Load/Unload Safety | PASS | PropertyGroups before operators, unregister reverses register, help entries defensive with clear_all_help backstop, p7_session.clear_all_sessions in unregister. |
| S4. Context Safety & Defensive Coding | PASS | All poll() methods guard active_object, session existence, and p7 availability. All execute() methods report errors. |
| S5. Undo/Redo & State Hygiene | WARN | All modifying ops have REGISTER+UNDO. But Python-side session registry (_sessions) is not undo-aware — an undo could desync it from scene state. This is a known architectural limitation documented in p7_session.py. |
| S6. Cross-Phase Contract Integrity | PASS | No P7 code depends on undeclared prior-phase side effects. All infrastructure (PanelAnatomyMixin, ui_helpers, editor_placement, help_registry) used correctly. |
| S7. UI/UX Foundation Compliance | PASS | Uses PanelAnatomyMixin with all four relevant sections. section_header, subsection, explained_op, danger_box all used correctly. Dope Sheet + Graph Editor cloning via make_editor_variants. |
| S8. Spec Fidelity & Completeness | WARN | 43 of 45 features fully implemented. Features 22 and 36 are partially implemented (bugs in logic). |
| S9. Performance & Scalability | PASS | Frame-by-frame baking is O(n_frames * n_objects). poll() in cleanup_all iterates all objects — could be slow on large scenes but is standard Blender pattern. |
| S10. Project Rule Compliance | PASS | Zero "animbot" occurrences. Zero Animaide overlap. Root package is anim_assist. All imports relative. Full file outputs. |

---

## 5. RISK REGISTER

### Finding 1

| Field | Value |
|-------|-------|
| # | 1 |
| Severity | HIGH |
| Dimension | S2, S8 |
| File | operators/p7_manage_ops.py |
| Line(s) | 174, 177 |
| Description | rename_proxy: old_name captured AFTER obj.name assignment — session tracking update always fails |
| Impact | 3 (orphaned proxy in session registry, cleanup cannot find renamed object) |
| Likelihood | 3 (common workflow — user renames proxy) |
| Risk | 9 |

**Why it matters:** When the user renames a proxy, the session's `created_objects` list still holds the old name. Cleanup/rollback will fail to find and delete the renamed object, leaving scene debris.

**Before (line 174, 177):**
```python
obj.name = new_name
old_name = obj.name  # BUG: this is already new_name
```

**After:**
```python
old_name = obj.name
obj.name = new_name
```

---

### Finding 2

| Field | Value |
|-------|-------|
| # | 2 |
| Severity | HIGH |
| Dimension | S2 |
| File | operators/p7_manage_ops.py |
| Line(s) | 527-537 |
| Description | apply_offset: described as "additive" but replaces target transform with proxy local coords, destroying animation |
| Impact | 3 (incorrect animation result, data loss if no undo) |
| Likelihood | 3 (common workflow) |
| Risk | 9 |

**Why it matters:** An animator expecting additive offset will instead get their target snapped to the proxy's location/rotation/scale, destroying whatever animation was on the target at that frame.

**Before:**
```python
target.location = proxy_world_loc
target.rotation_euler = proxy_world_rot
target.scale = proxy_world_scl
```

**After (additive delta):**
```python
delta_loc = proxy.matrix_world.translation - target.matrix_world.translation
target.location += delta_loc
# Similar for rotation/scale
```

---

### Finding 3

| Field | Value |
|-------|-------|
| # | 3 |
| Severity | MEDIUM |
| Dimension | S4 |
| File | operators/p7_manage_ops.py |
| Line(s) | 268 |
| Description | reconnect_session directly accesses private p7s._sessions dict, breaking session module encapsulation |
| Impact | 2 (maintenance risk, future refactoring hazard) |
| Likelihood | 2 (only on reconnect path) |
| Risk | 4 |

**Why it matters:** If the session module's internal storage changes (e.g., to a database or per-scene dict), this direct access will silently break.

**Before:**
```python
p7s._sessions[session_id] = existing_session
```

**After:** Add a public `restore_session(session)` function to p7_session.py.

---

### Finding 4

| Field | Value |
|-------|-------|
| # | 4 |
| Severity | MEDIUM |
| Dimension | S1 |
| File | operators/p7_cleanup_ops.py |
| Line(s) | 304-308 |
| Description | Dead code: batch_create_proxies checks cfg.display_type == "CURVE" but no ProxyConfig ever sets this |
| Impact | 1 (dead code, no runtime effect) |
| Likelihood | 4 (deterministic dead branch) |
| Risk | 4 |

**Why it matters:** Confusing for maintainers and creates unnecessary code paths for a case that can never occur.

**Before:**
```python
if cfg.display_type == "CURVE":
    curve_data = bpy.data.curves.new(name, type="CURVE")
    ...
else:
    proxy = bpy.data.objects.new(name, None)
```

**After:** Remove the CURVE branch entirely.

---

### Finding 5

| Field | Value |
|-------|-------|
| # | 5 |
| Severity | MEDIUM |
| Dimension | S5 |
| File | core/p7_session.py (architectural) |
| Line(s) | 193 |
| Description | Python-side session registry (_sessions dict) is not undo-aware — undo can desync with scene state |
| Impact | 2 (session state mismatch after undo) |
| Likelihood | 2 (user undoes proxy creation then tries cleanup) |
| Risk | 4 |

**Why it matters:** After undo, the scene may no longer contain the proxy objects but the session registry still tracks them. Cleanup will attempt to delete non-existent objects (handled gracefully) but the registry will be stale. This is documented as a known limitation.

**Mitigation:** The existing `undo_post` handler in app_handlers.py could be extended to re-sync sessions, or the validate_session operator can detect and fix mismatches.

---

### Finding 6

| Field | Value |
|-------|-------|
| # | 6 |
| Severity | LOW |
| Dimension | S7 |
| File | core/help_phase7_entries.py |
| Line(s) | All |
| Description | 49 help entries vs spec's 45 features — 4 extra utility entries in "One-Click Workflows" category |
| Impact | 1 (cosmetic, no functional impact — extra help is benign) |
| Likelihood | 1 (informational only) |
| Risk | 1 |

**Why it matters:** Minor spec deviation but harmless — extra help entries for list_sessions, quick_proxy, export_session, reduce_keys provide useful documentation.

---

### Finding 7

| Field | Value |
|-------|-------|
| # | 7 |
| Severity | LOW |
| Dimension | S4 |
| File | operators/p7_manage_ops.py |
| Line(s) | 269 |
| Description | reconnect_session uses broad Exception catch instead of specific types |
| Impact | 1 (could mask unexpected errors) |
| Likelihood | 1 (rare — only on corrupted scene data) |
| Risk | 1 |

---

## 6. MANUAL QA ESCALATION PLAN

### Tier 1 — Must test before merge (max 5)

1. **Undo/redo with active proxy session**: Create proxy, add constraint, undo twice, redo once. Verify session registry stays consistent with scene state. Test cleanup after undo sequence.

2. **File save/reload with active session**: Create proxies, save file, close Blender, reopen. Verify stale session detection fires and recovery operators work. Test that reconnect_session can rebuild from scene tags.

3. **Rename proxy then cleanup**: Use rename_proxy on a tracked proxy, then invoke cleanup_session. Verify the renamed object is actually removed (this will fail with current code — validates Finding 1).

4. **Armature bone proxy workflow**: Select a pose bone, create a proxy, add constraint, bake, cleanup. Verify bone-level constraints are properly created, baked, and removed. Test with mixed bone+object selection.

5. **One-click proxy bake end-to-end**: On an animated object with existing keyframes, run one_click_proxy_bake. Verify the original animation is preserved in baked form and all temporary artifacts are removed.

### Tier 2 — Nice to test if time allows (max 5)

1. **Cross-editor panel sync**: Open View3D, Dope Sheet, and Graph Editor simultaneously. Verify P7 panels appear in correct editors. Change bake settings in one editor and verify they're reflected in others.

2. **Multiple simultaneous sessions**: Create proxies in Scene1, switch to Scene2, create more proxies. Verify sessions are scene-scoped and don't cross-contaminate.

3. **Object without animation data**: Run bake operators (smart_bake, bake_range, bake_preserve_timing) on an object with no animation_data. Verify graceful handling and proper action creation.

4. **Addon reload**: Disable and re-enable the addon without restarting Blender. Verify all P7 handlers, properties, and sessions are properly torn down and re-initialized.

5. **Mirror proxy on non-L/R named objects**: Run mirror_proxy on objects without L/R naming convention. Verify graceful fallback (same name used, no crash).

---

## 7. CUMULATIVE HEALTH NOTE

### New Module Dependencies
Phase 7 adds 10 files to the codebase:
- `core/p7_proxy_math.py` (pure Python, no bpy)
- `core/p7_properties.py` (PropertyGroup)
- `core/p7_session.py` (session management)
- `core/help_phase7_entries.py` (help data)
- `operators/p7_locator_ops.py` (10 operators)
- `operators/p7_proxy_ops.py` (1 unified operator)
- `operators/p7_manage_ops.py` (14 operators)
- `operators/p7_bake_ops.py` (8 operators)
- `operators/p7_cleanup_ops.py` (13 operators)
- `ui/p7_panels.py` (3 panel classes)

Plus `operators/p7_session_ops.py` (2 operators) and `tests/test_p7_proxy_math.py` from the prep phase.

### Registration Changes
- `operators/__init__.py`: 5 new P7 module imports added to CLASSES tuple (after session_ops)
- `ui/__init__.py`: p7_panels added to UI CLASSES tuple
- `__init__.py`: P7 property registration, help entry registration, session cleanup all wired

### Probable Regression Surface
- **Low**: Pure-math module (p7_proxy_math) has no bpy dependency — cannot regress other phases
- **Low**: PropertyGroup (p7_properties) is scene-scoped, does not interfere with prior phase properties
- **Medium**: Session module (p7_session) introduces persistent scene custom properties and module-level state — undo/redo interaction needs manual testing
- **Low**: All P7 operators are namespaced with `p7_` prefix — no collision risk

### Maintenance Burden
Phase 7 is the largest single phase by operator count (48 operators). The session management system adds significant complexity but is well-documented and has good error recovery paths. The two-tier persistence model (Python dict + scene custom property) is a thoughtful design that handles crash recovery. Test coverage is adequate for the math layer but the operator layer depends on manual Blender testing.

---

## 8. FINAL VERDICT

**REWORK** — Not ready for merge. Resolve the two HIGH findings first:

1. **Fix rename_proxy session tracking** (Finding 1, Risk 9): Store old_name before assignment
2. **Fix apply_offset to compute additive delta** (Finding 2, Risk 9): Compute delta between proxy and target rather than replacing target transform

Additionally recommended before merge:
3. Remove dead CURVE branch from batch_create_proxies (Finding 4)
4. Replace direct `_sessions` access with a public API function (Finding 3)

After these fixes, the phase should achieve GO status.
