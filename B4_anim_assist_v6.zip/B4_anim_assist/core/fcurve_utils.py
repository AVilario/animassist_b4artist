"""FCurve inspection, snapshot, and classification helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import bpy


# ---------------------------------------------------------------------------
# Transform classifier
# ---------------------------------------------------------------------------

_TRANSFORM_SUBPATHS: dict[str, str] = {
    "location": "LOCATION",
    "rotation_euler": "ROTATION",
    "rotation_quaternion": "ROTATION",
    "rotation_axis_angle": "ROTATION",
    "scale": "SCALE",
}


def classify_transform_channel(data_path: str) -> Optional[str]:
    if '"].' in data_path:
        sub = data_path.split('"].', 1)[-1]
    else:
        sub = data_path
    return _TRANSFORM_SUBPATHS.get(sub)


# ---------------------------------------------------------------------------
# Keyframe snapshots
# ---------------------------------------------------------------------------

@dataclass
class KeyframeSnapshot:
    frame: float
    value: float
    selected: bool
    interpolation: str
    handle_left: tuple[float, float]
    handle_right: tuple[float, float]


def get_keyframe_snapshots(
    fcurve: bpy.types.FCurve,
    selected_only: bool = False,
) -> list[KeyframeSnapshot]:
    results: list[KeyframeSnapshot] = []
    for kp in fcurve.keyframe_points:
        if selected_only and not kp.select_control_point:
            continue
        results.append(
            KeyframeSnapshot(
                frame=float(kp.co[0]),
                value=float(kp.co[1]),
                selected=bool(kp.select_control_point),
                interpolation=kp.interpolation,
                handle_left=(float(kp.handle_left[0]), float(kp.handle_left[1])),
                handle_right=(
                    float(kp.handle_right[0]),
                    float(kp.handle_right[1]),
                ),
            )
        )
    return results


def get_selected_key_snapshots(
    fcurve: bpy.types.FCurve,
) -> list[KeyframeSnapshot]:
    """Return snapshots for **selected** keyframe points only."""
    return get_keyframe_snapshots(fcurve, selected_only=True)


def get_selected_key_frames(fcurve: bpy.types.FCurve) -> list[float]:
    return sorted(
        float(kp.co[0])
        for kp in fcurve.keyframe_points
        if kp.select_control_point
    )


# ---------------------------------------------------------------------------
# Per-channel queries
# ---------------------------------------------------------------------------

def is_channel_locked(fcurve: bpy.types.FCurve) -> bool:
    return bool(fcurve.lock)


def is_channel_muted(fcurve: bpy.types.FCurve) -> bool:
    return bool(fcurve.mute)


def is_channel_hidden(fcurve: bpy.types.FCurve) -> bool:
    return bool(fcurve.hide)


# ---------------------------------------------------------------------------
# Bulk channel filters
# ---------------------------------------------------------------------------

def get_locked_channels(
    fcurves: list[bpy.types.FCurve] | None,
) -> list[bpy.types.FCurve]:
    if not fcurves:
        return []
    return [fc for fc in fcurves if fc.lock]


def get_muted_channels(
    fcurves: list[bpy.types.FCurve] | None,
) -> list[bpy.types.FCurve]:
    if not fcurves:
        return []
    return [fc for fc in fcurves if fc.mute]


def get_hidden_channels(
    fcurves: list[bpy.types.FCurve] | None,
) -> list[bpy.types.FCurve]:
    if not fcurves:
        return []
    return [fc for fc in fcurves if fc.hide]


def get_visible_unlocked_channels(
    fcurves: list[bpy.types.FCurve] | None,
) -> list[bpy.types.FCurve]:
    if not fcurves:
        return []
    return [fc for fc in fcurves if not fc.hide and not fc.lock]


# ---------------------------------------------------------------------------
# Channel snapshots
# ---------------------------------------------------------------------------

@dataclass
class ChannelSnapshot:
    data_path: str
    array_index: int
    is_locked: bool
    is_muted: bool
    is_hidden: bool
    is_selected: bool
    transform_type: Optional[str]


def get_channel_snapshots(
    fcurves: list[bpy.types.FCurve] | None,
) -> list[ChannelSnapshot]:
    if not fcurves:
        return []
    results: list[ChannelSnapshot] = []
    for fc in fcurves:
        results.append(
            ChannelSnapshot(
                data_path=fc.data_path,
                array_index=fc.array_index,
                is_locked=bool(fc.lock),
                is_muted=bool(fc.mute),
                is_hidden=bool(fc.hide),
                is_selected=bool(getattr(fc, "select", False)),
                transform_type=classify_transform_channel(fc.data_path),
            )
        )
    return results


def get_selected_channel_snapshots(
    fcurves: list[bpy.types.FCurve] | None,
) -> list[ChannelSnapshot]:
    """Return snapshots for **selected** channels only.

    Uses RNA ``FCurve.select`` as the selection signal.
    """
    if not fcurves:
        return []
    results: list[ChannelSnapshot] = []
    for fc in fcurves:
        if not getattr(fc, "select", False):
            continue
        results.append(
            ChannelSnapshot(
                data_path=fc.data_path,
                array_index=fc.array_index,
                is_locked=bool(fc.lock),
                is_muted=bool(fc.mute),
                is_hidden=bool(fc.hide),
                is_selected=True,
                transform_type=classify_transform_channel(fc.data_path),
            )
        )
    return results


# ---------------------------------------------------------------------------
# Bone-related FCurve parsing
# ---------------------------------------------------------------------------

def get_bone_name_from_fcurve(fcurve: bpy.types.FCurve) -> Optional[str]:
    dp = fcurve.data_path
    if not dp.startswith('pose.bones["'):
        return None
    start = len('pose.bones["')
    end = dp.find('"]', start)
    if end < 0:
        return None
    return dp[start:end]


def get_sub_path_from_bone_fcurve(fcurve: bpy.types.FCurve) -> Optional[str]:
    dp = fcurve.data_path
    idx = dp.find('"].')
    if idx < 0:
        return None
    return dp[idx + 3:]