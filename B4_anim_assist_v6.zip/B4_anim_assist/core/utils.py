"""Shared data structures and utility functions (pure Python)."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

EPSILON: float = 1e-6


@dataclass
class KeyData:
    frame: float
    value: float
    selected: bool = False
    handle_left: tuple[float, float] = (0.0, 0.0)
    handle_right: tuple[float, float] = (0.0, 0.0)


@dataclass
class FCurveSnapshot:
    data_path: str = ""
    array_index: int = 0
    keys: list[KeyData] = field(default_factory=list)


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def clamp(value: float, min_val: float, max_val: float) -> float:
    return max(min_val, min(max_val, value))


def smoothstep(t: float) -> float:
    t = clamp(t, 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def inverse_lerp(a: float, b: float, value: float) -> float:
    denom = b - a
    if abs(denom) < EPSILON:
        return 0.0
    return (value - a) / denom


def remap(value: float, from_min: float, from_max: float, to_min: float, to_max: float) -> float:
    t = inverse_lerp(from_min, from_max, value)
    return lerp(to_min, to_max, t)


def get_selected_indices(keys: list[KeyData]) -> list[int]:
    return [i for i, k in enumerate(keys) if k.selected]


def find_neighbors(
    all_keys: list[KeyData],
    selected_indices: list[int],
) -> tuple[Optional[KeyData], Optional[KeyData]]:
    if not selected_indices:
        return None, None

    sel_set = set(selected_indices)
    min_idx = min(selected_indices)
    max_idx = max(selected_indices)

    left: Optional[KeyData] = None
    for i in range(min_idx - 1, -1, -1):
        if i not in sel_set:
            left = all_keys[i]
            break

    right: Optional[KeyData] = None
    for i in range(max_idx + 1, len(all_keys)):
        if i not in sel_set:
            right = all_keys[i]
            break

    return left, right