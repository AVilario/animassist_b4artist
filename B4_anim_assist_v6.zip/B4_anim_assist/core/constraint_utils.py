"""Constraint inspection helpers."""

from __future__ import annotations

from typing import Optional

import bpy



def get_bone_constraints(
    obj: bpy.types.Object | None,
    bone_name: str,
) -> list[bpy.types.Constraint]:
    if obj is None or obj.type != "ARMATURE":
        return []
    pose = getattr(obj, "pose", None)
    if pose is None:
        return []
    bone = pose.bones.get(bone_name)
    if bone is None:
        return []
    return list(bone.constraints)


def get_object_constraints(
    obj: bpy.types.Object | None,
) -> list[bpy.types.Constraint]:
    if obj is None:
        return []
    return list(obj.constraints)


def get_active_constraints(
    obj: bpy.types.Object | None,
    bone_name: Optional[str] = None,
) -> list[bpy.types.Constraint]:
    """Return enabled constraints with non-zero influence."""
    if bone_name is not None:
        constraints = get_bone_constraints(obj, bone_name)
    else:
        constraints = get_object_constraints(obj)
    return [c for c in constraints if not c.mute and c.influence > 0.0]


def has_ik_constraint(
    obj: bpy.types.Object | None,
    bone_name: str,
) -> bool:
    constraints = get_bone_constraints(obj, bone_name)
    return any(c.type == "IK" and not c.mute for c in constraints)


def get_constraint_targets(
    constraint: bpy.types.Constraint,
) -> list[bpy.types.Object]:
    targets: list[bpy.types.Object] = []
    target = getattr(constraint, "target", None)
    if target is not None:
        targets.append(target)
    target_list = getattr(constraint, "targets", None)
    if target_list is not None:
        for entry in target_list:
            tgt = getattr(entry, "target", None)
            if tgt is not None:
                targets.append(tgt)
    return targets