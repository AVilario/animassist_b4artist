# --- PHASE 5 PREP ---
"""Centralized app handler registration for lifecycle events.

Registers and tracks ``bpy.app.handlers.*`` callbacks so the addon can
respond to file loads, undo/redo, and depsgraph updates.  Uses the same
tracked-append pattern as ``ui/headers.py`` for safe teardown.

Currently wired callbacks:

* ``load_post`` — tears down all draw handlers (stale after file load)
  and resets the session cache generation.
* ``undo_post`` / ``redo_post`` — increments the session cache generation
  counter so overlay caches know their data is stale.

Future phases may add ``depsgraph_update_post`` or ``frame_change_post``
callbacks through the same module.
"""

from __future__ import annotations

from typing import Callable

import bpy

from .logging import get_logger

_log = get_logger(__name__)

#: Tracks every ``(handler_list, callback)`` pair we have appended so
#: :func:`unregister` can remove them in reverse order.
_appended: list[tuple[list, Callable]] = []


# ---------------------------------------------------------------------------
# Handler callbacks
# ---------------------------------------------------------------------------

def _on_load_post(*_args) -> None:
    """Called after a .blend file is loaded.

    All viewport draw handlers are stale because the SpaceView3D
    instances they were attached to no longer exist.  Wipe them, reset
    the cache generation, and clear the action-change hash cache.
    """
    from . import draw_registry as dreg
    from . import cache as cache_mod
    from . import runtime as rts_mod

    count = dreg.unregister_all()
    if count:
        _log.info("load_post: removed %d stale draw handler(s)", count)

    try:
        cache_mod.get_cache().bump_generation()
    except Exception:
        _log.debug("load_post: cache generation bump failed", exc_info=True)

    try:
        cache_mod.invalidate_cache()
    except Exception:
        _log.debug("load_post: action hash invalidation failed", exc_info=True)

    # Reset overlay state — no overlays survive a file load.
    try:
        state = rts_mod.get_state()
        state.overlay_enabled = False
        state.active_overlay_tags.clear()
    except Exception:
        _log.debug("load_post: overlay state reset failed", exc_info=True)

    # --- PHASE 5 TRAJECTORY ---
    # Clear the p5_draw module's stale handler IDs and draw data so the
    # overlay can be cleanly re-enabled on the new file.  Without this,
    # get_handler_ids() returns stale positive IDs and the enable operator
    # reports "already active" with nothing visible.
    try:
        from . import p5_draw as p5_draw_mod
        p5_draw_mod.clear_draw_data()
        p5_draw_mod.clear_handler_ids()
    except Exception:
        _log.debug("load_post: p5_draw state reset failed", exc_info=True)

    # Also wipe the per-target path cache so stale samples are not served.
    try:
        from . import p5_path_cache as p5_cache_mod
        p5_cache_mod.invalidate_all()
    except Exception:
        _log.debug("load_post: p5 path cache invalidation failed", exc_info=True)

    # --- PHASE 6 RETIME ---
    # Clear the three module-level caches so stale snapshots from a prior
    # file cannot corrupt the newly loaded scene.
    try:
        from ..operators.p6_retime_ops import clear_last_backup
        clear_last_backup()
    except Exception:
        _log.debug("load_post: p6 retime backup clear failed", exc_info=True)

    try:
        from ..operators.p6_gap_ops import clear_cached_gaps
        clear_cached_gaps()
    except Exception:
        _log.debug("load_post: p6 gap cache clear failed", exc_info=True)

    try:
        from ..operators.p6_diag_ops import clear_cached_diag
        clear_cached_diag()
    except Exception:
        _log.debug("load_post: p6 diag cache clear failed", exc_info=True)

    # --- PHASE 7 PREP ---
    # Clear the Python-side session registry (stale after file load) and
    # scan all scenes for non-committed session records that indicate an
    # incomplete proxy/bake workflow left artifacts in the file.
    try:
        from . import p7_session as p7s
        p7s.clear_all_sessions()
        stale = p7s.detect_stale_sessions()
        if stale:
            _log.warning(
                "load_post: found %d stale P7 session(s) — use "
                "'Recover P7 Session' to clean up", len(stale),
            )
    except Exception:
        _log.debug("load_post: p7 session check failed", exc_info=True)

    # --- PHASE 8 MATCHING ---
    # Clear module-level caches that are stale after a file load:
    # preview state in switch ops, cached detection patterns, and
    # the ephemeral switch history stack.
    try:
        from ..operators.p8_switch_ops import clear_preview_state
        clear_preview_state()
    except Exception:
        _log.debug("load_post: p8 preview state clear failed", exc_info=True)

    try:
        from ..operators.p8_detect_ops import clear_cached_patterns
        clear_cached_patterns()
    except Exception:
        _log.debug("load_post: p8 detection cache clear failed", exc_info=True)

    try:
        from . import p8_switch_history as p8_hist
        p8_hist.clear_history()
    except Exception:
        _log.debug("load_post: p8 switch history clear failed", exc_info=True)

    # --- PHASE 9 MIRRORING ---
    # Clear the pair cache so stale pair mappings from a prior file are
    # never served to mirror operators.
    try:
        from . import p9_pair_cache as p9_cache
        p9_cache.clear_cache()
    except Exception:
        _log.debug("load_post: p9 pair cache clear failed", exc_info=True)

    try:
        from ..operators.p9_batch_ops import clear_last_mirror
        clear_last_mirror()
    except Exception:
        _log.debug("load_post: p9 last mirror clear failed", exc_info=True)

    # --- PHASE 10 ORCHESTRATION ---
    # Clear recovery snapshots and audit buffers — they reference a prior
    # file's property state and are meaningless after a load.
    try:
        from . import p10_recovery as p10_rec
        p10_rec.clear_snapshots()
    except Exception:
        _log.debug("load_post: p10 recovery clear failed", exc_info=True)

    try:
        from . import p10_audit as p10_aud
        p10_aud.clear_all()
    except Exception:
        _log.debug("load_post: p10 audit clear failed", exc_info=True)


def _on_undo_post(*_args) -> None:
    """Called after an undo step.

    Animation data has changed — bump the cache generation so overlay
    caches know to rebuild.
    """
    from . import cache as cache_mod

    try:
        cache_mod.get_cache().bump_generation()
    except Exception:
        _log.debug("undo_post: cache generation bump failed", exc_info=True)

    try:
        cache_mod.invalidate_cache()
    except Exception:
        _log.debug("undo_post: action hash invalidation failed", exc_info=True)

    # --- PHASE 9 MIRRORING ---
    # Invalidate pair cache so stale pair mappings are not served after undo.
    try:
        from . import p9_pair_cache as p9_cache
        p9_cache.invalidate()
    except Exception:
        _log.debug("undo_post: p9 pair cache invalidation failed", exc_info=True)


def _on_redo_post(*_args) -> None:
    """Called after a redo step.  Same invalidation as undo."""
    from . import cache as cache_mod

    try:
        cache_mod.get_cache().bump_generation()
    except Exception:
        _log.debug("redo_post: cache generation bump failed", exc_info=True)

    try:
        cache_mod.invalidate_cache()
    except Exception:
        _log.debug("redo_post: action hash invalidation failed", exc_info=True)

    # --- PHASE 9 MIRRORING ---
    try:
        from . import p9_pair_cache as p9_cache
        p9_cache.invalidate()
    except Exception:
        _log.debug("redo_post: p9 pair cache invalidation failed", exc_info=True)


# ---------------------------------------------------------------------------
# Register / unregister
# ---------------------------------------------------------------------------

def register() -> None:
    """Append all app handler callbacks.  Safe to call multiple times."""
    _pairs: list[tuple[list, Callable]] = [
        (bpy.app.handlers.load_post, _on_load_post),
        (bpy.app.handlers.undo_post, _on_undo_post),
        (bpy.app.handlers.redo_post, _on_redo_post),
    ]
    for handler_list, callback in _pairs:
        # Guard against double-append (e.g. F8 reload without unregister).
        if callback not in handler_list:
            handler_list.append(callback)
            _appended.append((handler_list, callback))
            _log.debug("App handler registered: %s → %s",
                       _handler_list_name(handler_list), callback.__name__)


def unregister() -> None:
    """Remove all tracked app handler callbacks."""
    for handler_list, callback in reversed(_appended):
        try:
            handler_list.remove(callback)
        except ValueError:
            pass  # Already removed — harmless.
    _appended.clear()
    _log.debug("All app handlers unregistered")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _handler_list_name(handler_list: list) -> str:
    """Best-effort human-readable name for a ``bpy.app.handlers.*`` list."""
    for attr in dir(bpy.app.handlers):
        if getattr(bpy.app.handlers, attr, None) is handler_list:
            return f"bpy.app.handlers.{attr}"
    return repr(handler_list)
