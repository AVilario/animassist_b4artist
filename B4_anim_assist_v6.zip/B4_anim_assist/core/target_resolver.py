"""Selected animation target snapshot utilities."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import bpy

from .cache import push_selection_entry, remember_active_target


@dataclass
class TargetSnapshot:
    # NOTE: field is named 'obj' (not 'object') to avoid shadowing Python's
    # built-in 'object' type, which can confuse type-checkers and linters.
    obj: bpy.types.Object
    bone_name: Optional[str] = None
    action: Optional[bpy.types.Action] = None
    fcurves: list[bpy.types.FCurve] = field(default_factory=list)
    is_linked: bool = False


def get_active_target(
    context: bpy.types.Context | None = None,
) -> Optional[TargetSnapshot]:
    """Snapshot the active object (and optional active pose bone)."""
    ctx = context or bpy.context
    obj = getattr(ctx, "active_object", None) or getattr(ctx, "object", None)
    if obj is None:
        return None

    is_linked = obj.library is not None and obj.override_library is None

    bone_name: str | None = None
    if obj.type == "ARMATURE" and obj.mode == "POSE":
        active_bone = getattr(ctx, "active_pose_bone", None)
        if active_bone is not None:
            bone_name = active_bone.name

    action: bpy.types.Action | None = None
    fcurves: list[bpy.types.FCurve] = []
    anim_data = getattr(obj, "animation_data", None)
    if anim_data is not None:
        action = anim_data.action
        if action is not None:
            fcurves = list(action.fcurves)

    return TargetSnapshot(
        obj=obj,
        bone_name=bone_name,
        action=action,
        fcurves=fcurves,
        is_linked=is_linked,
    )


def resolve_and_remember_active_target(
    context: bpy.types.Context | None = None,
) -> Optional[TargetSnapshot]:
    target = get_active_target(context)
    if target is not None:
        remember_active_target(target.obj.name, target.bone_name)
        push_selection_entry(target.obj.name, target.bone_name)
    return target


def get_selected_target_snapshots(
    context: bpy.types.Context | None = None,
) -> list[TargetSnapshot]:
    ctx = context or bpy.context
    selected = getattr(ctx, "selected_objects", None) or []
    results: list[TargetSnapshot] = []

    for obj in selected:
        is_linked = obj.library is not None and obj.override_library is None
        action: bpy.types.Action | None = None
        fcurves: list[bpy.types.FCurve] = []
        anim_data = getattr(obj, "animation_data", None)
        if anim_data is not None:
            action = anim_data.action
            if action is not None:
                fcurves = list(action.fcurves)

        if obj.type == "ARMATURE" and obj.mode == "POSE":
            pose = getattr(obj, "pose", None)
            if pose is not None:
                selected_bones = [b for b in pose.bones if b.bone.select]
                if selected_bones:
                    for bone in selected_bones:
                        prefix = f'pose.bones["{bone.name}"].'
                        bone_fcurves = [
                            fc for fc in fcurves
                            if fc.data_path.startswith(prefix)
                        ]
                        results.append(
                            TargetSnapshot(
                                obj=obj,
                                bone_name=bone.name,
                                action=action,
                                fcurves=bone_fcurves,
                                is_linked=is_linked,
                            )
                        )
                    continue

        results.append(
            TargetSnapshot(
                obj=obj,
                bone_name=None,
                action=action,
                fcurves=fcurves,
                is_linked=is_linked,
            )
        )

    return results


get_selected_targets = get_selected_target_snapshots


def get_selected_pose_bone_names(
    context: bpy.types.Context | None = None,
) -> list[str]:
    ctx = context or bpy.context
    bones = getattr(ctx, "selected_pose_bones", None) or []
    return [b.name for b in bones]
