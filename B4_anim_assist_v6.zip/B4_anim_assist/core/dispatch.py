"""Internal command dispatch table."""

from __future__ import annotations

from typing import Any, Callable

from .logging import get_logger

_log = get_logger(__name__)

_commands: dict[str, Callable[..., Any]] = {}


def register_command(name: str, handler: Callable[..., Any]) -> None:
    if name in _commands:
        _log.warning("Overwriting existing command: %s", name)
    _commands[name] = handler


def dispatch(name: str, **kwargs: Any) -> Any:
    handler = _commands.get(name)
    if handler is None:
        _log.error("Unknown command: %s", name)
        return None
    try:
        return handler(**kwargs)
    except Exception:
        _log.exception("Command '%s' failed", name)
        return None


def has_command(name: str) -> bool:
    return name in _commands


def list_commands() -> list[str]:
    """Return a sorted list of all registered command names."""
    return sorted(_commands.keys())


def clear() -> None:
    _commands.clear()