"""Pure logic for Anim Offset propagation (no bpy)."""

from __future__ import annotations

from dataclasses import dataclass

from .utils import EPSILON, clamp, smoothstep


@dataclass
class MaskRegion:
    start: float
    end: float
    blend_in: float = 5.0
    blend_out: float = 5.0
    enabled: bool = True


def mask_weight(frame: float, mask: MaskRegion) -> float:
    if not mask.enabled:
        return 1.0

    outer_left = mask.start - mask.blend_in
    outer_right = mask.end + mask.blend_out

    if frame < outer_left or frame > outer_right:
        return 0.0

    if frame < mask.start and mask.blend_in > EPSILON:
        t = (frame - outer_left) / mask.blend_in
        return smoothstep(clamp(t, 0.0, 1.0))

    if frame > mask.end and mask.blend_out > EPSILON:
        t = (outer_right - frame) / mask.blend_out
        return smoothstep(clamp(t, 0.0, 1.0))

    return 1.0


def compute_propagated_values(
    original_values: dict[float, float],
    delta: float,
    mask: MaskRegion,
    current_frame: float,
) -> dict[float, float]:
    result: dict[float, float] = {}
    for frame, orig in original_values.items():
        if abs(frame - current_frame) < EPSILON:
            continue
        w = mask_weight(frame, mask)
        if w > EPSILON:
            result[frame] = orig + delta * w
    return result


def compute_propagated_values_full_range(
    original_values: dict[float, float],
    delta: float,
    current_frame: float,
) -> dict[float, float]:
    result: dict[float, float] = {}
    for frame, orig in original_values.items():
        if abs(frame - current_frame) < EPSILON:
            continue
        result[frame] = orig + delta
    return result


def frames_outside_mask(frames: list[float], mask: MaskRegion) -> list[float]:
    return [f for f in frames if mask_weight(f, mask) < EPSILON]