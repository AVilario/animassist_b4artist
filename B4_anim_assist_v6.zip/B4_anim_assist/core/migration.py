"""Scene-level data migration helpers."""

from __future__ import annotations

from typing import Callable

import bpy

from .. import constants
from .logging import get_logger

_log = get_logger(__name__)

_MIGRATIONS: list[tuple[int, Callable[[bpy.types.Scene], None]]] = []


def register_migration(version: int) -> Callable:
    """Decorator that registers a scene migration step at *version*."""
    def decorator(fn: Callable[[bpy.types.Scene], None]) -> Callable:
        _MIGRATIONS.append((version, fn))
        _MIGRATIONS.sort(key=lambda x: x[0])
        return fn
    return decorator


@register_migration(1)
def _migration_v1(scene: bpy.types.Scene) -> None:
    """Initial migration – ensure property group is initialised."""
    props = getattr(scene, constants.SCENE_PROP_ATTR, None)
    if props is not None:
        _log.debug("Migration v1: scene '%s' OK", scene.name)


def migrate_scene(scene: bpy.types.Scene) -> None:
    props = getattr(scene, constants.SCENE_PROP_ATTR, None)
    if props is None:
        return

    current = props.migration_version
    for version, fn in _MIGRATIONS:
        if version > current:
            try:
                fn(scene)
                props.migration_version = version
                _log.info("Migrated scene '%s' to v%d", scene.name, version)
            except Exception:
                _log.exception(
                    "Migration v%d failed for scene '%s'", version, scene.name
                )
                break


def migrate_all_scenes() -> None:
    for scene in bpy.data.scenes:
        migrate_scene(scene)