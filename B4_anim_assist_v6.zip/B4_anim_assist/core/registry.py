"""Safe class registration / unregistration manager."""

from __future__ import annotations

import bpy

from .logging import get_logger

_log = get_logger(__name__)


class ClassRegistry:
    """Register Blender classes in order with rollback on failure."""

    def __init__(self) -> None:
        self._classes: list[type] = []
        self._registered: list[type] = []

    def add(self, cls: type) -> None:
        if cls not in self._classes:
            self._classes.append(cls)

    def extend(self, classes: tuple[type, ...] | list[type]) -> None:
        for cls in classes:
            self.add(cls)

    def register(self) -> None:
        for cls in self._classes:
            try:
                bpy.utils.register_class(cls)
                self._registered.append(cls)
            except ValueError as exc:
                if "already registered" in str(exc):
                    _log.debug("Class %s already registered; skipping", cls.__name__)
                    self._registered.append(cls)
                else:
                    _log.exception("Failed to register %s; rolling back", cls)
                    self.unregister()
                    raise
            except Exception:
                _log.exception("Failed to register %s; rolling back", cls)
                self.unregister()
                raise

    def unregister(self) -> None:
        for cls in reversed(self._registered):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                _log.debug("Failed to unregister %s", cls, exc_info=True)
        self._registered.clear()

    @property
    def registered_count(self) -> int:
        return len(self._registered)