"""Capability registry – tracks what features/subsystems are available."""

from __future__ import annotations

from .logging import get_logger

_log = get_logger(__name__)


class CapabilityRegistry:
    def __init__(self) -> None:
        self._capabilities: dict[str, bool] = {}

    def register(self, name: str, available: bool = True) -> None:
        self._capabilities[name] = available

    def is_available(self, name: str) -> bool:
        return self._capabilities.get(name, False)

    def all_capabilities(self) -> dict[str, bool]:
        return dict(self._capabilities)

    def clear(self) -> None:
        self._capabilities.clear()


_registry: CapabilityRegistry | None = None


def init() -> None:
    global _registry
    _registry = CapabilityRegistry()
    _registry.register("preferences", True)
    _registry.register("diagnostics", True)
    _registry.register("settings_io", True)
    _registry.register("context_resolver", True)
    _registry.register("fcurve_utils", True)
    _registry.register("metadata", True)
    _registry.register("hotkeys", True)
    _registry.register("cache", True)
    _registry.register("runtime", True)


def get_registry() -> CapabilityRegistry:
    global _registry
    if _registry is None:
        init()
    return _registry


def shutdown() -> None:
    global _registry
    if _registry is not None:
        _registry.clear()
        _registry = None