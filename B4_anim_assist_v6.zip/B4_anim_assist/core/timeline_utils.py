"""Timeline and preview-range resolvers."""

from __future__ import annotations

from typing import Optional

import bpy

from .logging import get_logger

_log = get_logger(__name__)


def get_scene_frame_range(
    context: bpy.types.Context | None = None,
) -> tuple[int, int]:
    ctx = context or bpy.context
    scene = getattr(ctx, "scene", None)
    if scene is None:
        return (1, 250)
    return (scene.frame_start, scene.frame_end)


def get_preview_range(
    context: bpy.types.Context | None = None,
) -> Optional[tuple[int, int]]:
    ctx = context or bpy.context
    scene = getattr(ctx, "scene", None)
    if scene is None:
        return None
    if not scene.use_preview_range:
        return None
    return (scene.frame_preview_start, scene.frame_preview_end)


def get_effective_frame_range(
    context: bpy.types.Context | None = None,
) -> tuple[int, int]:
    """Return preview range if active, otherwise scene range."""
    preview = get_preview_range(context)
    if preview is not None:
        return preview
    return get_scene_frame_range(context)


def get_current_frame(
    context: bpy.types.Context | None = None,
) -> int:
    ctx = context or bpy.context
    scene = getattr(ctx, "scene", None)
    if scene is None:
        return 1
    return scene.frame_current