"""Animation editor context resolvers."""

from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Optional

import bpy


@dataclass
class AnimEditorInfo:
    area: bpy.types.Area
    space: bpy.types.Space
    region: bpy.types.Region | None

    @property
    def type(self) -> str:
        return self.area.type


class AnimContextResolver:
    """Stateless helper for locating and overriding animation editor contexts."""

    @staticmethod
    def find_areas_by_type(
        context: bpy.types.Context, area_type: str
    ) -> list[AnimEditorInfo]:
        results: list[AnimEditorInfo] = []
        screen = getattr(context, "screen", None)
        if screen is None:
            return results

        for area in screen.areas:
            if area.type != area_type:
                continue
            space = area.spaces.active
            region = next(
                (r for r in area.regions if r.type == "WINDOW"), None
            )
            results.append(AnimEditorInfo(area=area, space=space, region=region))
        return results

    @staticmethod
    def get_graph_editor(
        context: bpy.types.Context,
    ) -> Optional[AnimEditorInfo]:
        editors = AnimContextResolver.find_areas_by_type(context, "GRAPH_EDITOR")
        return editors[0] if editors else None

    @staticmethod
    def get_dope_sheet(
        context: bpy.types.Context,
    ) -> Optional[AnimEditorInfo]:
        screen = getattr(context, "screen", None)
        if screen is None:
            return None

        for area in screen.areas:
            if area.type != "DOPESHEET_EDITOR":
                continue
            space = area.spaces.active
            mode = getattr(space, "mode", None)
            if mode == "TIMELINE":
                continue
            region = next(
                (r for r in area.regions if r.type == "WINDOW"), None
            )
            return AnimEditorInfo(area=area, space=space, region=region)
        return None

    @staticmethod
    def get_timeline(
        context: bpy.types.Context,
    ) -> Optional[AnimEditorInfo]:
        screen = getattr(context, "screen", None)
        if screen is None:
            return None

        for area in screen.areas:
            if area.type != "DOPESHEET_EDITOR":
                continue
            space = area.spaces.active
            mode = getattr(space, "mode", None)
            if mode == "TIMELINE":
                region = next(
                    (r for r in area.regions if r.type == "WINDOW"), None
                )
                return AnimEditorInfo(area=area, space=space, region=region)
        return None

    @staticmethod
    def get_active_anim_editor(
        context: bpy.types.Context,
    ) -> Optional[AnimEditorInfo]:
        area = getattr(context, "area", None)
        if area is not None and area.type in {"GRAPH_EDITOR", "DOPESHEET_EDITOR"}:
            space = area.spaces.active
            region = next(
                (r for r in area.regions if r.type == "WINDOW"), None
            )

            if area.type == "DOPESHEET_EDITOR":
                mode = getattr(space, "mode", None)
                if mode == "TIMELINE":
                    return AnimContextResolver.get_timeline(context)

            return AnimEditorInfo(area=area, space=space, region=region)

        for getter in (
            AnimContextResolver.get_graph_editor,
            AnimContextResolver.get_dope_sheet,
            AnimContextResolver.get_timeline,
        ):
            result = getter(context)
            if result is not None:
                return result
        return None

    @staticmethod
    @contextmanager
    def temp_override_for_editor(
        context: bpy.types.Context,
        info: AnimEditorInfo,
    ) -> Iterator[AnimEditorInfo | None]:
        """Context-manager that establishes a safe ``temp_override`` for
        the given editor *info*.

        Yields the *info* on success, or ``None`` when the override cannot
        be established safely.
        """
        window = getattr(context, "window", None)
        screen = (
            getattr(window, "screen", None) if window is not None else None
        )

        if (
            window is None
            or screen is None
            or info.region is None
            or info.area not in screen.areas
            or info.region not in info.area.regions
        ):
            yield None
            return

        with context.temp_override(
            window=window, area=info.area, region=info.region
        ):
            yield info