"""Bone path resolver and per-bone metadata accessor."""

from __future__ import annotations

import json
from typing import Optional

import bpy

from .. import constants
from .logging import get_logger

_log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Data-path helpers
# ---------------------------------------------------------------------------

def get_bone_data_path(bone_name: str, property_name: str) -> str:
    return f'pose.bones["{bone_name}"].{property_name}'


def get_bone_transform_paths(bone_name: str) -> dict[str, str]:
    return {
        "location": get_bone_data_path(bone_name, "location"),
        "rotation_euler": get_bone_data_path(bone_name, "rotation_euler"),
        "rotation_quaternion": get_bone_data_path(
            bone_name, "rotation_quaternion"
        ),
        "scale": get_bone_data_path(bone_name, "scale"),
    }


def get_bone_fcurves(
    action: bpy.types.Action, bone_name: str
) -> list[bpy.types.FCurve]:
    prefix = f'pose.bones["{bone_name}"].'
    return [fc for fc in action.fcurves if fc.data_path.startswith(prefix)]


# ---------------------------------------------------------------------------
# Per-bone metadata (stored in scene property group)
# ---------------------------------------------------------------------------

def get_bone_metadata(
    scene: bpy.types.Scene,
    object_name: str,
    bone_name: str,
) -> dict:
    props = getattr(scene, constants.SCENE_PROP_ATTR, None)
    if props is None:
        return {}

    for item in props.bone_metadata:
        if item.object_name == object_name and item.bone_name == bone_name:
            try:
                return json.loads(item.metadata_json)
            except (json.JSONDecodeError, TypeError):
                return {}
    return {}


def set_bone_metadata(
    scene: bpy.types.Scene,
    object_name: str,
    bone_name: str,
    data: dict,
) -> bool:
    if not isinstance(data, dict):
        _log.warning("Bone metadata must be a dict, got %s", type(data).__name__)
        return False

    # Guard against linked scene / library write restrictions.
    if scene.library is not None and scene.override_library is None:
        _log.debug("Skipping bone metadata write for linked scene '%s'", scene.name)
        return False

    props = getattr(scene, constants.SCENE_PROP_ATTR, None)
    if props is None:
        return False

    for item in props.bone_metadata:
        if item.object_name == object_name and item.bone_name == bone_name:
            item.metadata_json = json.dumps(data, ensure_ascii=False)
            return True

    item = props.bone_metadata.add()
    item.object_name = object_name
    item.bone_name = bone_name
    item.metadata_json = json.dumps(data, ensure_ascii=False)
    return True


# ---------------------------------------------------------------------------
# Context helper
# ---------------------------------------------------------------------------

def resolve_bone_from_context(
    context: bpy.types.Context | None = None,
) -> Optional[tuple[bpy.types.Object, str]]:
    """Return ``(armature_object, bone_name)`` if in pose mode, else *None*."""
    ctx = context or bpy.context
    obj = getattr(ctx, "active_object", None)
    if obj is None or obj.type != "ARMATURE" or obj.mode != "POSE":
        return None

    active_bone = getattr(ctx, "active_pose_bone", None)
    if active_bone is None:
        return None

    return (obj, active_bone.name)