"""Key utility/clipboard helpers (Phase 2)."""

from __future__ import annotations

import bpy

from .context_utils import iter_visible_fcurves, iter_selected_keys


# ---------------------------------------------------------------------------
# Session-transient clipboard
# ---------------------------------------------------------------------------

# (action.name, data_path, array_index) -> list of serialised keyframe dicts
_clipboard: dict[tuple, list[dict]] = {}


def copy_selected_keys(context: bpy.types.Context) -> int:
    """Copy selected keys (with handle data) into the module clipboard.

    Replaces any previously copied data.
    """
    _clipboard.clear()
    count = 0
    for obj, action, fc in iter_visible_fcurves(context):
        items: list[dict] = []
        for kp in fc.keyframe_points:
            if not kp.select_control_point:
                continue
            items.append({
                "frame": float(kp.co.x),
                "value": float(kp.co.y),
                "interpolation": kp.interpolation,
                "type": kp.type,
                "hl": (float(kp.handle_left.x), float(kp.handle_left.y)),
                "hr": (float(kp.handle_right.x), float(kp.handle_right.y)),
                "hlt": kp.handle_left_type,
                "hrt": kp.handle_right_type,
            })
        if items:
            _clipboard[(action.name, fc.data_path, fc.array_index)] = items
            count += len(items)
    return count


def paste_keys(context: bpy.types.Context, frame_offset: float = 0.0) -> int:
    """Paste clipboard keys onto matching FCurves, shifted by *frame_offset*."""
    count = 0
    for _o, action, fc in iter_visible_fcurves(context):
        items = _clipboard.get((action.name, fc.data_path, fc.array_index))
        if not items:
            continue
        for it in items:
            kp = fc.keyframe_points.insert(
                it["frame"] + frame_offset, it["value"], options={"FAST"}
            )
            kp.interpolation = it["interpolation"]
            kp.type = it["type"]
            kp.handle_left_type = it["hlt"]
            kp.handle_right_type = it["hrt"]
            kp.handle_left.x = it["hl"][0] + frame_offset
            kp.handle_left.y = it["hl"][1]
            kp.handle_right.x = it["hr"][0] + frame_offset
            kp.handle_right.y = it["hr"][1]
            count += 1
        fc.update()
    return count


def clipboard_size() -> int:
    return sum(len(v) for v in _clipboard.values())


# ---------------------------------------------------------------------------
# In-place key mutations
# ---------------------------------------------------------------------------

def _collect_touched(it) -> tuple[int, list[bpy.types.FCurve]]:
    """Helper: iterate *it*, collecting unique FCurves that were touched.

    ``it`` must yield ``(obj, action, fc, index, kp)`` tuples.
    Returns ``(count, unique_touched_fcs)``.
    """
    touched_ids: set[int] = set()
    touched_fcs: list[bpy.types.FCurve] = []
    count = 0
    for item in it:
        fc = item[2]
        # mutation done by caller — we just track which fcs to update
        if id(fc) not in touched_ids:
            touched_ids.add(id(fc))
            touched_fcs.append(fc)
        count += 1
    return count, touched_fcs


def offset_selected(context: bpy.types.Context, dx: float = 0.0, dy: float = 0.0) -> int:
    """Shift selected keys by *dx* frames and *dy* value units.

    Only FCurves that actually contain selected keys are updated.
    """
    touched_ids: set[int] = set()
    touched_fcs: list[bpy.types.FCurve] = []
    count = 0
    for _o, _a, fc, _i, kp in iter_selected_keys(context):
        kp.co.x += dx
        kp.co.y += dy
        kp.handle_left.x += dx
        kp.handle_left.y += dy
        kp.handle_right.x += dx
        kp.handle_right.y += dy
        if id(fc) not in touched_ids:
            touched_ids.add(id(fc))
            touched_fcs.append(fc)
        count += 1
    for fc in touched_fcs:
        fc.update()
    return count


def snap_selected_to_integer_frames(context: bpy.types.Context) -> int:
    """Round selected keys' frame positions to the nearest integer."""
    touched_ids: set[int] = set()
    touched_fcs: list[bpy.types.FCurve] = []
    count = 0
    for _o, _a, fc, _i, kp in iter_selected_keys(context):
        kp.co.x = round(kp.co.x)
        if id(fc) not in touched_ids:
            touched_ids.add(id(fc))
            touched_fcs.append(fc)
        count += 1
    for fc in touched_fcs:
        fc.update()
    return count


def mirror_selected(context: bpy.types.Context, pivot: float) -> int:
    """Mirror selected keys horizontally around *pivot* (frame number).

    Both the key's X position and its bezier handles are mirrored correctly:
    the left and right handles swap sides, with both X and Y exchanged so
    tangent curvature is preserved after the flip.
    """
    touched_ids: set[int] = set()
    touched_fcs: list[bpy.types.FCurve] = []
    count = 0
    for _o, _a, fc, _i, kp in iter_selected_keys(context):
        # Mirror the control point.
        kp.co.x = 2.0 * pivot - kp.co.x

        # Capture both handles before mutating either.
        old_hl_x = float(kp.handle_left.x)
        old_hl_y = float(kp.handle_left.y)
        old_hr_x = float(kp.handle_right.x)
        old_hr_y = float(kp.handle_right.y)

        # After mirroring, the old right handle becomes the new left handle and
        # vice-versa.  Mirror the X and swap the Y values between sides.
        kp.handle_left.x = 2.0 * pivot - old_hr_x
        kp.handle_left.y = old_hr_y
        kp.handle_right.x = 2.0 * pivot - old_hl_x
        kp.handle_right.y = old_hl_y

        if id(fc) not in touched_ids:
            touched_ids.add(id(fc))
            touched_fcs.append(fc)
        count += 1
    for fc in touched_fcs:
        fc.update()
    return count
