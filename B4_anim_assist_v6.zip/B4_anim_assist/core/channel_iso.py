"""Channel isolation / filtering helpers (Phase 2)."""

from __future__ import annotations

import re
from typing import Iterable

import bpy

from .context_utils import iter_visible_fcurves


# Module-level state stack (isolation snapshots).
_isolation_stack: list[dict] = []


def iter_action_fcurves(context: bpy.types.Context):
    """Yield ``(obj, action, fcurve)`` for every action used in the view layer.

    Deduplicates shared actions (linked characters etc.) by ``id(action)``.
    Includes hidden and muted FCurves — use this when you need to operate on
    *all* channels regardless of their visibility state (e.g. isolation ops).
    """
    view_layer = getattr(context, "view_layer", None)
    if view_layer is None:
        return
    seen: set[int] = set()
    for obj in view_layer.objects:
        ad = obj.animation_data
        if ad and ad.action and id(ad.action) not in seen:
            seen.add(id(ad.action))
            for fc in ad.action.fcurves:
                yield obj, ad.action, fc


def snapshot_state(context: bpy.types.Context) -> dict:
    snap = {}
    for _o, action, fc in iter_action_fcurves(context):
        key = (action.name, fc.data_path, fc.array_index)
        snap[key] = (bool(fc.hide), bool(fc.mute), bool(fc.select), bool(fc.lock))
    return snap


def restore_state(context: bpy.types.Context, snap: dict) -> int:
    n = 0
    for _o, action, fc in iter_action_fcurves(context):
        key = (action.name, fc.data_path, fc.array_index)
        state = snap.get(key)
        if state is None:
            continue
        fc.hide, fc.mute, fc.select, fc.lock = state
        n += 1
    return n


def push_isolation(context: bpy.types.Context) -> None:
    _isolation_stack.append(snapshot_state(context))


def pop_isolation(context: bpy.types.Context) -> bool:
    if not _isolation_stack:
        return False
    snap = _isolation_stack.pop()
    restore_state(context, snap)
    return True


def clear_isolation_stack() -> None:
    _isolation_stack.clear()


def isolate_where(
    context: bpy.types.Context,
    predicate,
    push: bool = True,
) -> int:
    if push:
        push_isolation(context)
    shown = 0
    for _o, action, fc in iter_action_fcurves(context):
        keep = bool(predicate(_o, action, fc))
        fc.hide = not keep
        if keep:
            shown += 1
    return shown


def match_data_path_regex(pattern: str):
    rx = re.compile(pattern)
    return lambda _o, _a, fc: bool(rx.search(fc.data_path))


def match_transform_channel(channel: str):
    """channel in {'loc','rot','scale','all_transform'}."""
    mapping = {
        "loc": ("location",),
        "rot": ("rotation_euler", "rotation_quaternion", "rotation_axis_angle"),
        "scale": ("scale",),
    }
    if channel == "all_transform":
        needles = mapping["loc"] + mapping["rot"] + mapping["scale"]
    else:
        needles = mapping.get(channel, ())
    return lambda _o, _a, fc: any(n in fc.data_path for n in needles)


def match_selected_bones(context: bpy.types.Context):
    """Return predicate matching fcurves of currently-selected pose bones."""
    bone_paths: set[str] = set()
    obj = context.object
    if obj and obj.type == "ARMATURE" and obj.mode == "POSE":
        for pb in context.selected_pose_bones or []:
            bone_paths.add(f'pose.bones["{pb.name}"]')
    return lambda _o, _a, fc: any(fc.data_path.startswith(p) for p in bone_paths)


def match_custom_property():
    return lambda _o, _a, fc: fc.data_path.startswith('["') or '][' in fc.data_path
