"""Lightweight diagnostic heuristics for FCurve key quality."""

from __future__ import annotations

from typing import Iterable

import bpy

from .context_utils import iter_visible_fcurves


def scan_density(context: bpy.types.Context, min_gap: float = 1.0) -> list[dict]:
    results: list[dict] = []
    for obj, action, fc in iter_visible_fcurves(context):
        kps = fc.keyframe_points
        for i in range(1, len(kps)):
            gap = kps[i].co.x - kps[i - 1].co.x
            if gap < min_gap:
                results.append({
                    "obj": obj.name,
                    "data_path": fc.data_path,
                    "array_index": fc.array_index,
                    "frame": float(kps[i].co.x),
                    "gap": float(gap),
                    "kind": "DENSE",
                })
    return results


def scan_redundant(context: bpy.types.Context, tol: float = 1e-4) -> list[dict]:
    """Detect keys that lie on a straight line between neighbours."""
    results: list[dict] = []
    for obj, action, fc in iter_visible_fcurves(context):
        kps = fc.keyframe_points
        for i in range(1, len(kps) - 1):
            a, b, c = kps[i - 1], kps[i], kps[i + 1]
            dx = c.co.x - a.co.x
            if abs(dx) < 1e-9:
                continue
            t = (b.co.x - a.co.x) / dx
            expected = a.co.y + t * (c.co.y - a.co.y)
            if abs(b.co.y - expected) <= tol:
                results.append({
                    "obj": obj.name,
                    "data_path": fc.data_path,
                    "array_index": fc.array_index,
                    "frame": float(b.co.x),
                    "kind": "REDUNDANT",
                })
    return results


def scan_spikes(context: bpy.types.Context, ratio: float = 4.0) -> list[dict]:
    results: list[dict] = []
    for obj, action, fc in iter_visible_fcurves(context):
        kps = fc.keyframe_points
        for i in range(1, len(kps) - 1):
            a, b, c = kps[i - 1], kps[i], kps[i + 1]
            d_left = abs(b.co.y - a.co.y)
            d_right = abs(c.co.y - b.co.y)
            base = max(abs(c.co.y - a.co.y), 1e-6)
            if (d_left + d_right) / base >= ratio:
                results.append({
                    "obj": obj.name,
                    "data_path": fc.data_path,
                    "array_index": fc.array_index,
                    "frame": float(b.co.x),
                    "kind": "SPIKE",
                })
    return results


def summarise(results: Iterable[dict]) -> dict:
    out = {"DENSE": 0, "REDUNDANT": 0, "SPIKE": 0, "TOTAL": 0}
    for r in results:
        out[r["kind"]] = out.get(r["kind"], 0) + 1
        out["TOTAL"] += 1
    return out
