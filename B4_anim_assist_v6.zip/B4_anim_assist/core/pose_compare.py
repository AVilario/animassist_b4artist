# --- PHASE 3 BREAKDOWN ---
"""Pose snapshot + compare state used by the Phase 3 pose-compare tools.

A snapshot is an in-memory dict keyed by ``(data_path, array_index)``
containing the fcurve-evaluated value at a specific frame. Two slots
("previous" and "next") are tracked at module scope so an animator can
Copy Prev / Copy Next and then run a breakdown toward either reference.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import bpy

from .logging import get_logger

_log = get_logger(__name__)


PoseKey = Tuple[str, int]


@dataclass
class PoseSnapshot:
    frame: float
    label: str
    values: Dict[PoseKey, float] = field(default_factory=dict)

    def get(self, data_path: str, array_index: int) -> Optional[float]:
        return self.values.get((data_path, int(array_index)))


@dataclass
class PoseCompareState:
    prev_snapshot: Optional[PoseSnapshot] = None
    next_snapshot: Optional[PoseSnapshot] = None
    reference_snapshot: Optional[PoseSnapshot] = None
    last_report: List[str] = field(default_factory=list)


_STATE = PoseCompareState()


def get_state() -> PoseCompareState:
    return _STATE


def snapshot_object(
    obj: bpy.types.Object,
    frame: float,
    label: str,
) -> PoseSnapshot:
    snap = PoseSnapshot(frame=frame, label=label)
    adata = getattr(obj, "animation_data", None)
    if adata is None or adata.action is None:
        return snap
    for fc in adata.action.fcurves:
        try:
            value = float(fc.evaluate(frame))
        except Exception:  # pragma: no cover — defensive against RNA edge cases
            continue
        snap.values[(fc.data_path, int(fc.array_index))] = value
    return snap


def set_prev(obj: bpy.types.Object, frame: float) -> PoseSnapshot:
    _STATE.prev_snapshot = snapshot_object(obj, frame, "Previous Pose")
    return _STATE.prev_snapshot


def set_next(obj: bpy.types.Object, frame: float) -> PoseSnapshot:
    _STATE.next_snapshot = snapshot_object(obj, frame, "Next Pose")
    return _STATE.next_snapshot


def set_reference(obj: bpy.types.Object, frame: float) -> PoseSnapshot:
    _STATE.reference_snapshot = snapshot_object(obj, frame, "Reference Pose")
    return _STATE.reference_snapshot


def clear() -> None:
    _STATE.prev_snapshot = None
    _STATE.next_snapshot = None
    _STATE.reference_snapshot = None
    _STATE.last_report.clear()


def compare_snapshots(
    a: PoseSnapshot,
    b: PoseSnapshot,
    *,
    tolerance: float = 1e-5,
) -> List[str]:
    """Return a human-readable list of differing channels."""
    if a is None or b is None:
        return ["Both snapshots required for compare."]
    diffs: List[str] = []
    keys = set(a.values.keys()) | set(b.values.keys())
    for key in sorted(keys):
        va = a.values.get(key)
        vb = b.values.get(key)
        if va is None:
            diffs.append(f"+ {key[0]}[{key[1]}]  (only in {b.label})")
            continue
        if vb is None:
            diffs.append(f"- {key[0]}[{key[1]}]  (only in {a.label})")
            continue
        if abs(va - vb) > tolerance:
            diffs.append(
                f"~ {key[0]}[{key[1]}]  {va:.4f} → {vb:.4f}"
            )
    return diffs
