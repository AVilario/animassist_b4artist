# Phase 7 Implementation Plan

## A. Objective
Implement Phase 7 — Temporary Controls, Proxy Helpers, Bake Utilities, Session Tracking, and Cleanup Tools — for the Anim Assist Blender addon. 45 features across 5 functional groups, all built on the P7Session infrastructure already in place.

## B. Dependencies
- `core/p7_session.py` (already built) — session lifecycle, tagging, rollback, persistence
- `core/p6_properties.py` pattern — PropertyGroup with callable-items enums
- `ui/panel_anatomy.py` — PanelAnatomyMixin for section ordering
- `ui/editor_placement.py` — View3DSidebarPanel, DopeSheetSidebarPanel, make_editor_variants
- `ui/ui_helpers.py` — section_header, subsection, explained_op, explained_prop, danger_box, separator
- `core/help_registry.py` — HelpEntry, register_phase_help/unregister_phase_help

## C. File Structure

### New files:
1. `core/p7_properties.py` — Scene-scoped PropertyGroup for P7 settings
2. `core/p7_proxy_math.py` — Pure-Python proxy creation helpers and bake math
3. `core/help_phase7_entries.py` — 45 HelpEntry records across 8 categories
4. `operators/p7_locator_ops.py` — Features 1-6 (locator/empty creation, parenting, constraining)
5. `operators/p7_proxy_ops.py` — Features 11-19 (unified proxy operator with proxy_type enum)
6. `operators/p7_bake_ops.py` — Features 7-10, 31-35 (bake/match, smart bake, range bake)
7. `operators/p7_manage_ops.py` — Features 20-23, 28-30, 36-39 (display, control, utility)
8. `operators/p7_cleanup_ops.py` — Features 24-27, 40-45 (cleanup, batch, validation, mirror)
9. `ui/p7_panels.py` — View3D (primary) + Dope Sheet (secondary) panels

### Modified files:
10. `operators/__init__.py` — add P7 operator imports
11. `ui/__init__.py` — add P7 panel imports
12. `__init__.py` — add P7 property registration, help entries, singleton cleanup

## D. Proxy Data Model
Each proxy type is a configuration dict consumed by a unified `AA_OT_p7_create_proxy` operator:

```
PROXY_CONFIGS = {
    "POSITION": {"display_type": "EMPTY", "empty_display": "PLAIN_AXES", "constraint": "COPY_LOCATION"},
    "ROTATION": {"display_type": "EMPTY", "empty_display": "SINGLE_ARROW", "constraint": "COPY_ROTATION"},
    "LOOKAT":   {"display_type": "EMPTY", "empty_display": "SPHERE", "constraint": "TRACK_TO"},
    "PARENT":   {"display_type": "EMPTY", "empty_display": "CUBE", "constraint": "CHILD_OF"},
    "PIVOT":    {"display_type": "EMPTY", "empty_display": "CIRCLE", "constraint": None},
    "PATH":     {"display_type": "CURVE", "constraint": "FOLLOW_PATH"},
    "DISTANCE": {"display_type": "EMPTY", "empty_display": "PLAIN_AXES", "constraint": "LIMIT_DISTANCE"},
    "AIM":      {"display_type": "EMPTY", "empty_display": "CONE", "constraint": "DAMPED_TRACK"},
    "SPACE":    {"display_type": "EMPTY", "empty_display": "ARROWS", "constraint": None, "setup": "space_switch"},
}
```

## E. Constraint Strategy
- All injected constraints use `make_constraint_name(session_id, suffix)` → `AA_P7_<8char>_<TYPE>`
- Constraints are registered immediately via `session.register_constraint()`
- Constraint removal always happens BEFORE object deletion (enforced by rollback order)
- Object-level constraints on empties; pose-bone constraints on armature bones

## F. Bake Workflow
Manual frame-by-frame approach (avoids `bpy.ops.nla.bake()` context issues):
1. Determine frame range (from selection, scene range, or custom)
2. For each frame: set `scene.frame_set(f)` → evaluate → read transform → insert keyframe
3. After bake: `fc.update()` on all modified curves
4. Smart bake: post-process with key reduction (remove keys within tolerance)

## G. Session Approach
Every operator that creates scene artifacts:
1. Calls `begin_session(scene.name)` or uses existing active session
2. Tags every created object via `tag_artifact()`
3. Registers constraints via `session.register_constraint()`
4. Calls `save_session_to_scene()` after each artifact registration
5. On success: `commit_session()` — removes bookkeeping
6. On failure/cancel: `rollback_session()` — removes all artifacts

## H. Cleanup Lifecycle
- Per-session: rollback_session() removes artifacts in strict order
- Orphan scanner: purge_session_artifacts() as fallback
- File load: detect_stale_sessions() + recovery operators
- Addon disable: clear_all_sessions() + clear singletons

## I. UI Strategy
- **Primary panel**: View3D sidebar (Phase 7 operates on scene objects/pose bones)
- **Secondary panel**: Dope Sheet sidebar (lightweight bake settings view)
- Panel sections follow PanelAnatomyMixin: Primary → Scope → Advanced → Destructive → Help
- Primary: proxy creation, locator tools, quick bake
- Scope: target selection, frame range
- Advanced: bake settings, proxy display, batch tools
- Destructive: cleanup, purge, session rollback

## J. Help Integration
45 entries across 8 categories:
1. Locator Tools (6) — Features 1-6
2. Bake & Match (4) — Features 7-10
3. Proxy Types (9) — Features 11-19
4. Display & Control (4) — Features 20-23
5. Cleanup (4) — Features 24-27
6. Utility (3) — Features 28-30
7. Smart Bake (5) — Features 31-35
8. Batch & Validation (10) — Features 36-45

## K. Edge Cases
- No active object → poll returns False, panel shows info message
- Armature has no pose bones → proxy ops limited to object-level
- Session interrupted (crash) → stale detection on file load
- Bake on empty frame range → report warning, return CANCELLED
- Duplicate proxy creation → check existing constraints before adding

## L. Excluded Features
- NLA bake integration (deferred)
- Multi-scene proxy workflows (deferred)
- Custom proxy shapes from mesh library (deferred)

## M. Feature-to-Module Mapping

| Module | Features | Operators |
|--------|----------|-----------|
| p7_locator_ops | 1-6 | create_locator, parent_locator, constrain_to_locator, snap_locator, remove_locator, locator_from_bone |
| p7_bake_ops | 7-10, 31-35 | bake_to_locator, match_transform, bake_constraints, bake_action, smart_bake, reduce_keys, bake_range, bake_selected, bake_step |
| p7_proxy_ops | 11-19 | create_proxy (unified with proxy_type enum) |
| p7_manage_ops | 20-23, 28-30, 36-39 | toggle_display, set_proxy_color, lock_proxy, unlock_proxy, select_all_proxies, list_sessions, show_session_info, batch_create_proxies, batch_bake, batch_cleanup, mirror_proxy |
| p7_cleanup_ops | 24-27, 40-45 | cleanup_session, cleanup_all, remove_proxy, remove_constraints, validate_session, auto_cleanup, one_click_proxy_bake, one_click_cleanup, quick_proxy, export_session |
