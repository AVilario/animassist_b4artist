"""Anim Assist – Production animation workflow tools that complement Animaide."""

bl_info = {
    "name": "Anim Assist",
    "author": "Developer",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "View3D > Sidebar > AnimAssist",
    "description": "Production animation workflow tools for Bforartists (not compatible with standard Blender)",
    "category": "Animation",
}

from . import constants
from .core.logging import get_logger
from .core.registry import ClassRegistry
from .core import properties as prop_mod
from .core import cache as cache_mod
from .core import runtime as rts_mod
from .core import capabilities as cap_mod
from .core import hotkeys as hk_mod
from .core import migration as mig_mod
from .core import dispatch as dispatch_mod
# --- EXPLAINER SYSTEM EXTENSION ---
from .core import help_registry as help_reg_mod
from .core import help_phase1_entries as help_phase1_mod
# --- EXPLAINER HELP INTEGRATION ---
from .core import help_phase2_entries as help_phase2_mod
# --- PHASE 3 BREAKDOWN ---
from .core import help_phase3_entries as help_phase3_mod
from .core import p3_properties as p3_prop_mod
from .core import pose_compare as pose_compare_mod
from .core import breakdown_core as breakdown_core_mod
# --- PHASE 4 OFFSET ---
from .core import help_phase4_entries as help_phase4_mod
from .core import p4_properties as p4_prop_mod
from .core import p4_offset_math as p4_offset_math_mod
# --- PHASE 5 PREP ---
from .core import draw_registry as dreg_mod
from .core import app_handlers as app_handlers_mod
# --- PHASE 5 TRAJECTORY ---
from .core import help_phase5_entries as help_phase5_mod
from .core import p5_properties as p5_prop_mod
from .core import p5_path_cache as p5_cache_mod
# --- PHASE 6 RETIME ---
from .core import help_phase6_entries as help_phase6_mod
from .core import p6_properties as p6_prop_mod
# --- PHASE 7 CONTROLS ---
from .core import help_phase7_entries as help_phase7_mod
from .core import p7_properties as p7_prop_mod
from .core import p7_session as p7_session_mod
# --- PHASE 8 MATCHING ---
from .core import help_phase8_entries as help_phase8_mod
from .core import p8_properties as p8_prop_mod
from .core import p8_switch_history as p8_hist_mod
# --- PHASE 9 MIRRORING ---
from .core import help_phase9_entries as help_phase9_mod
from .core import p9_properties as p9_prop_mod
from .core import p9_pair_cache as p9_cache_mod
# --- PHASE 10 ORCHESTRATION ---
from .core import help_phase10_entries as help_phase10_mod
from .core import p10_properties as p10_prop_mod
from .core import p10_tool_registry as p10_tool_reg_mod
from .core import p10_audit as p10_audit_mod
from .core import p10_recovery as p10_recovery_mod
# --- PHASE 11 ANIMATION LAYERS ---
from .core import help_phase11_entries as help_phase11_mod
from .core import p11_properties as p11_prop_mod
# --- UI/UX FOUNDATION ---
from .core import ui_state as ui_state_mod
from .prefs import AA_AddonPreferences
from . import operators as ops_pkg
from . import ui as ui_pkg

_log = get_logger(__name__)
_registry: ClassRegistry | None = None


def _build_registry() -> ClassRegistry:
    reg = ClassRegistry()
    # Property groups must be registered before PointerProperty attachment
    # and before any class that references them.
    reg.extend(prop_mod.CLASSES)
    reg.add(AA_AddonPreferences)

    # Phase 1 foundation classes always register.
    reg.extend(ops_pkg.CLASSES)
    reg.extend(ui_pkg.CLASSES)

    # Future-phase module-gated registration hook:
    # from .prefs import get_prefs
    # prefs = get_prefs()
    # if prefs is None or prefs.enable_selection:
    #     reg.extend(selection_pkg.CLASSES)
    # if prefs is None or prefs.enable_keys:
    #     reg.extend(keys_pkg.CLASSES)
    # ... etc. for each module in constants.MODULE_KEYS

    return reg


def _is_bforartists() -> bool:
    """Return True when running inside Bforartists, False for standard Blender."""
    import bpy as _bpy

    # 1. Dedicated boolean attribute (may be added by future Bforartists builds).
    if getattr(_bpy.app, "bforartists", False):
        return True

    # 2. Build branch starts with "Bfa" (e.g. b'Bfa5v5.1.0 (modified)').
    build_branch = getattr(_bpy.app, "build_branch", b"")
    if isinstance(build_branch, bytes):
        build_branch = build_branch.decode("utf-8", errors="ignore")
    if build_branch.lower().startswith("bfa"):
        return True

    # 3. Binary path contains "bforartists" (e.g. F:\5.1.0\bforartists.exe).
    binary_path = getattr(_bpy.app, "binary_path", "")
    if "bforartists" in binary_path.lower():
        return True

    # 4. Version string contains "bforartists" (fallback for other builds).
    version_str = getattr(_bpy.app, "version_string", "")
    if "bforartists" in version_str.lower():
        return True

    return False


def register() -> None:
    if not _is_bforartists():
        raise RuntimeError(
            "Anim Assist is exclusive to Bforartists and cannot be used with "
            "standard Blender. Please install Bforartists: https://www.bforartists.de"
        )

    global _registry
    _registry = _build_registry()
    try:
        _registry.register()
        prop_mod.register_properties()
        # --- PHASE 3 BREAKDOWN ---
        p3_prop_mod.register_properties()
        # --- PHASE 4 OFFSET ---
        p4_prop_mod.register_properties()
        # --- PHASE 5 TRAJECTORY ---
        p5_prop_mod.register_properties()
        # --- PHASE 6 RETIME ---
        p6_prop_mod.register_properties()
        # --- PHASE 7 CONTROLS ---
        p7_prop_mod.register_properties()
        # --- PHASE 8 MATCHING ---
        p8_prop_mod.register_properties()
        # --- PHASE 9 MIRRORING ---
        p9_prop_mod.register_properties()
        # --- PHASE 10 ORCHESTRATION ---
        p10_prop_mod.register_properties()
        # --- PHASE 11 ANIMATION LAYERS ---
        p11_prop_mod.register_properties()
        # --- UI/UX FOUNDATION ---
        # Attach the WindowManager-scoped UI state PointerProperty AFTER
        # the parent PropertyGroup classes have been registered above.
        ui_state_mod.register_properties()
        ui_pkg.headers.register()
        cache_mod.init()
        rts_mod.init()
        # --- PHASE 5 PREP ---
        # Draw handler registry must init after runtime (it logs) but
        # before any phase that might register draw handlers.
        dreg_mod.init()
        # App handlers (load_post, undo_post, redo_post) provide the
        # lifecycle events that keep draw handlers and caches in sync.
        app_handlers_mod.register()
        cap_mod.init()
        hk_mod.get_manager().register_defaults()

        # --- EXPLAINER SYSTEM EXTENSION ---
        # Seed Phase 1 help entries. Future phases call their own
        # ``help_phaseN_entries.register()`` from the same place.
        try:
            help_phase1_mod.register()
        except Exception:
            _log.exception("Help registry seed failed \u2013 continuing")

        # --- EXPLAINER HELP INTEGRATION ---
        try:
            help_phase2_mod.register()
        except Exception:
            _log.exception("Phase 2 help registry seed failed \u2013 continuing")

        # --- PHASE 3 BREAKDOWN ---
        try:
            help_phase3_mod.register()
        except Exception:
            _log.exception("Phase 3 help registry seed failed \u2013 continuing")

        # --- PHASE 4 OFFSET ---
        try:
            help_phase4_mod.register()
        except Exception:
            _log.exception("Phase 4 help registry seed failed \u2013 continuing")

        # --- PHASE 5 TRAJECTORY ---
        try:
            help_phase5_mod.register()
        except Exception:
            _log.exception("Phase 5 help registry seed failed \u2013 continuing")

        # --- PHASE 6 RETIME ---
        try:
            help_phase6_mod.register()
        except Exception:
            _log.exception("Phase 6 help registry seed failed \u2013 continuing")

        # --- PHASE 7 CONTROLS ---
        try:
            help_phase7_mod.register()
        except Exception:
            _log.exception("Phase 7 help registry seed failed \u2013 continuing")

        try:
            help_phase8_mod.register()
        except Exception:
            _log.exception("Phase 8 help registry seed failed \u2013 continuing")

        # --- PHASE 9 MIRRORING ---
        try:
            help_phase9_mod.register()
        except Exception:
            _log.exception("Phase 9 help registry seed failed \u2013 continuing")

        # --- PHASE 10 ORCHESTRATION ---
        try:
            help_phase10_mod.register()
        except Exception:
            _log.exception("Phase 10 help registry seed failed \u2013 continuing")

        # --- PHASE 11 ANIMATION LAYERS ---
        try:
            help_phase11_mod.register()
        except Exception:
            _log.exception("Phase 11 help registry seed failed \u2013 continuing")

        # Sync logging level from preferences if available.
        try:
            from .prefs import get_prefs
            from .core.logging import set_level

            prefs = get_prefs()
            if prefs is not None:
                set_level(bool(prefs.debug_mode))
        except Exception:
            _log.debug(
                "Could not sync logging level from preferences", exc_info=True
            )

        # Run scene migrations.
        try:
            mig_mod.migrate_all_scenes()
        except Exception:
            _log.exception("Migration failed \u2013 continuing")

        _log.info("Anim Assist %s registered", constants.ADDON_VERSION_STRING)

    except Exception:
        _log.exception("Registration failed; attempting rollback")
        # --- EXPLAINER SYSTEM EXTENSION ---
        try:
            # --- PHASE 11 ANIMATION LAYERS ---
            help_phase11_mod.unregister()
            # --- PHASE 10 ORCHESTRATION ---
            help_phase10_mod.unregister()
            # --- PHASE 9 MIRRORING ---
            help_phase9_mod.unregister()
            # --- PHASE 8 MATCHING ---
            help_phase8_mod.unregister()
            # --- PHASE 7 CONTROLS ---
            help_phase7_mod.unregister()
            # --- PHASE 6 RETIME ---
            help_phase6_mod.unregister()
            # --- PHASE 5 TRAJECTORY ---
            help_phase5_mod.unregister()
            # --- PHASE 4 OFFSET ---
            help_phase4_mod.unregister()
            # --- PHASE 3 BREAKDOWN ---
            help_phase3_mod.unregister()
            # --- EXPLAINER HELP INTEGRATION ---
            help_phase2_mod.unregister()
            help_phase1_mod.unregister()
            help_reg_mod.clear_all_help()
        except Exception:
            _log.debug("Help rollback failed", exc_info=True)
        try:
            p11_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 11 property rollback failed", exc_info=True)
        try:
            p10_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 10 property rollback failed", exc_info=True)
        try:
            p9_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 9 property rollback failed", exc_info=True)
        try:
            p8_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 8 property rollback failed", exc_info=True)
        try:
            p7_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 7 property rollback failed", exc_info=True)
        try:
            p6_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 6 property rollback failed", exc_info=True)
        try:
            p5_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 5 property rollback failed", exc_info=True)
        try:
            p4_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 4 property rollback failed", exc_info=True)
        try:
            p3_prop_mod.unregister_properties()
        except Exception:
            _log.debug("Phase 3 property rollback failed", exc_info=True)
        for cleanup in (
            ui_pkg.headers.unregister,
            hk_mod.shutdown,
            cap_mod.shutdown,
            # --- PHASE 5 PREP ---
            app_handlers_mod.unregister,
            dreg_mod.shutdown,
            rts_mod.shutdown,
            cache_mod.shutdown,
            # --- UI/UX FOUNDATION ---
            ui_state_mod.unregister_properties,
            prop_mod.unregister_properties,
        ):
            try:
                cleanup()
            except Exception:
                _log.debug(
                    "Rollback cleanup failed: %s", cleanup, exc_info=True
                )

        if _registry is not None:
            try:
                _registry.unregister()
            except Exception:
                _log.debug("Rollback class unregister failed", exc_info=True)
            _registry = None
        raise


def unregister() -> None:
    global _registry

    # --- EXPLAINER SYSTEM EXTENSION ---
    # Tear down help entries before classes so the popup operator can never
    # be invoked against a half-cleared registry. ``clear_all_help`` is the
    # defensive backstop in case a phase teardown left orphan rows behind.
    for help_cleanup in (
        # --- PHASE 11 ANIMATION LAYERS ---
        help_phase11_mod.unregister,
        # --- PHASE 10 ORCHESTRATION ---
        help_phase10_mod.unregister,
        # --- PHASE 9 MIRRORING ---
        help_phase9_mod.unregister,
        # --- PHASE 8 MATCHING ---
        help_phase8_mod.unregister,
        # --- PHASE 7 CONTROLS ---
        help_phase7_mod.unregister,
        # --- PHASE 6 RETIME ---
        help_phase6_mod.unregister,
        # --- PHASE 5 TRAJECTORY ---
        help_phase5_mod.unregister,
        # --- PHASE 4 OFFSET ---
        help_phase4_mod.unregister,
        # --- PHASE 3 BREAKDOWN ---
        help_phase3_mod.unregister,
        # --- EXPLAINER HELP INTEGRATION ---
        help_phase2_mod.unregister,
        help_phase1_mod.unregister,
        help_reg_mod.clear_all_help,
    ):
        try:
            help_cleanup()
        except Exception:
            _log.exception("Help teardown failed: %s", help_cleanup)

    def _p6_clear_singletons() -> None:
        # Wipe the three Phase 6 module-level caches so a disable/enable
        # cycle does not expose stale timing snapshots or gap/diag data
        # from a prior scene to the newly loaded one.
        try:
            from .operators.p6_retime_ops import clear_last_backup
            clear_last_backup()
        except Exception:
            pass
        try:
            from .operators.p6_gap_ops import clear_cached_gaps
            clear_cached_gaps()
        except Exception:
            pass
        try:
            from .operators.p6_diag_ops import clear_cached_diag
            clear_cached_diag()
        except Exception:
            pass

    def _p4_clear_singletons() -> None:
        try:
            p4_offset_math_mod.clear_last()
        except Exception:
            pass

    def _p3_clear_singletons() -> None:
        # Module-level Phase 3 state must be wiped so a disable/enable
        # cycle does not replay stale pose snapshots or "repeat last"
        # options that reference a prior scene.
        try:
            pose_compare_mod.clear()
        except Exception:
            pass
        try:
            breakdown_core_mod._LAST_OPTIONS = None  # type: ignore[attr-defined]
        except Exception:
            pass

    for cleanup in (
        ui_pkg.headers.unregister,
        hk_mod.shutdown,
        dispatch_mod.clear,
        cap_mod.shutdown,
        # --- PHASE 5 PREP ---
        # App handlers first (they reference draw_registry, cache, runtime),
        # then draw registry (removes all viewport handlers), then runtime
        # and cache last.
        app_handlers_mod.unregister,
        dreg_mod.shutdown,
        rts_mod.shutdown,
        cache_mod.shutdown,
        # --- PHASE 11 ANIMATION LAYERS ---
        p11_prop_mod.unregister_properties,
        # --- PHASE 10 ORCHESTRATION ---
        p10_audit_mod.clear_all,
        p10_recovery_mod.clear_snapshots,
        p10_tool_reg_mod.clear,
        p10_prop_mod.unregister_properties,
        # --- PHASE 9 MIRRORING ---
        p9_cache_mod.clear_cache,
        p9_prop_mod.unregister_properties,
        # --- PHASE 8 MATCHING ---
        p8_hist_mod.clear_history,
        p8_prop_mod.unregister_properties,
        # --- PHASE 7 CONTROLS ---
        p7_session_mod.clear_all_sessions,
        p7_prop_mod.unregister_properties,
        # --- PHASE 6 RETIME ---
        _p6_clear_singletons,
        p6_prop_mod.unregister_properties,
        # --- PHASE 5 TRAJECTORY ---
        p5_cache_mod.invalidate_all,
        p5_prop_mod.unregister_properties,
        # --- PHASE 4 OFFSET ---
        _p4_clear_singletons,
        p4_prop_mod.unregister_properties,
        # --- PHASE 3 BREAKDOWN ---
        _p3_clear_singletons,
        p3_prop_mod.unregister_properties,
        # --- UI/UX FOUNDATION ---
        ui_state_mod.unregister_properties,
        prop_mod.unregister_properties,
    ):
        try:
            cleanup()
        except Exception:
            _log.exception("Cleanup failed during unregister: %s", cleanup)

    if _registry is not None:
        try:
            _registry.unregister()
        except Exception:
            _log.exception("Class registry unregister failed")
        finally:
            _registry = None

    _log.info("Anim Assist %s unregistered", constants.ADDON_VERSION_STRING)