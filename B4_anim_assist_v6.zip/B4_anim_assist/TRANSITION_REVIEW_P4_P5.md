# ANIM_ASSIST — TRANSITION READINESS REVIEW
## Gateway: Phase 4 → Phase 5

---

## 1. TRANSITION DECISION

**READY WITH PREP WORK**

The codebase is architecturally sound for Phases 1–4 but lacks the runtime infrastructure that Phase 5's persistent viewport drawing demands. The prep work is surgical — one new core module plus minor extensions to existing modules — not a rewrite.

---

## 2. WHY THIS TRANSITION IS DIFFERENT

- **Phases 1–4 are operator-scoped**: every pipeline starts in `execute()` or `invoke()`, does work, and returns `{"FINISHED"}`. State dies with the operator. Phase 5 installs draw callbacks that persist across frames, across redraws, and across undo steps — they are lifecycle-alien to everything the addon currently does.

- **Draw callbacks run outside operator context**: `bpy.types.SpaceView3D.draw_handler_add` callbacks receive zero `context` argument in `POST_VIEW` mode. They cannot call `context.evaluated_depsgraph_get()`, cannot safely read `context.scene.frame_current`, and must not trigger depsgraph evaluation. Every pattern that Phases 3–4 use for live data (resolve_targets, delta_to_basis) is structurally unusable inside a draw callback without pre-computation.

- **Handler leaks are silent and cumulative**: a draw handler that fails to unregister on addon disable, file load, or exception will continue firing every redraw until Blender restarts. Unlike a leaked Python object (garbage-collected) or a stale PropertyGroup (ignored after unregister), a leaked draw handler actively crashes or corrupts the viewport.

- **Undo/redo invalidates cached animation data**: Phase 5 must cache sampled trajectory points. Blender's undo system replaces the entire depsgraph state, so cached samples become stale on every `bpy.app.handlers.undo_post`. No existing module in the addon handles post-undo invalidation.

- **Multiple 3D viewports multiply handler instances**: a single call to `draw_handler_add` on one `SpaceView3D` only draws in that space. If the user splits viewports, the overlay either must register in every space or use the `WINDOW` region type with proper per-space state. Neither pattern exists in the codebase.

- **Phase 10 diagnostics need to enumerate live handlers**: the planned diagnostic/health system cannot detect leaks if handlers are registered ad-hoc from operator code. A central registry is the only path to runtime introspection.

---

## 3. REQUIRED PRE-PHASE-5 ARCHITECTURE

### 3a. `core/draw_registry.py` — Draw Handler Lifecycle Manager (NEW FILE)

A centralized singleton that owns every draw handler the addon installs. Must provide:

| Capability | Rationale |
|---|---|
| `register_handler(space_type, region_type, callback, draw_mode, tag)` → handle_id | Single entry point; `tag` is a human-readable string for diagnostics. |
| `unregister_handler(handle_id)` | Remove one handler by its tracked ID. |
| `unregister_all()` | Bulk teardown called from `__init__.unregister()` and from app handlers on file-load. |
| `is_registered(handle_id) → bool` | Stale-entry query for operators and diagnostics. |
| `enumerate() → list[HandlerInfo]` | Phase 10 diagnostics: list every active handler with tag, space, callback ref. |
| `init()` / `shutdown()` | Lifecycle pair matching `runtime.init()` / `shutdown()`. |

Implementation notes:
- Internally wraps `bpy.types.SpaceView3D.draw_handler_add/remove`.
- Stores a `dict[int, HandlerEntry]` keyed by an auto-incrementing `_next_id`.
- `HandlerEntry` is a frozen dataclass: `(handle, space_type, region_type, callback, draw_mode, tag, created_at)`.
- `shutdown()` calls `unregister_all()` then clears the dict — defense against addon disable without explicit teardown.
- Must be added to the `__init__.py` register/unregister cleanup chain.

### 3b. App handler registration for invalidation events (NEW or extend `__init__.py`)

Phase 5 needs the addon to respond to:
- `bpy.app.handlers.undo_post` — invalidate trajectory caches
- `bpy.app.handlers.redo_post` — same
- `bpy.app.handlers.load_post` — tear down all draw handlers (the SpaceView3D references are dead after file load)
- `bpy.app.handlers.depsgraph_update_post` — optional, for live cache refresh

These must be registered/unregistered centrally, not scattered across Phase 5 operator code. The pattern should follow the existing `ui/headers.py` tracked-append model but for `bpy.app.handlers.*`.

**Recommendation**: add an `_app_handlers` tracked list in `__init__.py` (or a small `core/app_handlers.py` module) that mirrors the `_appended` pattern in `ui/headers.py`.

### 3c. Extend `RuntimeState` with overlay-awareness fields

Add to `core/runtime.py`:
```python
self.overlay_enabled: bool = False        # master toggle
self.active_overlay_tags: set[str] = set()  # which overlays are live
```

This costs zero if Phase 5 is disabled, and gives operators and panels a single-source truth for "is an overlay currently drawing?"

### 3d. Cache invalidation contract on `SessionCache`

Add a `generation: int` counter to `SessionCache` that increments on every invalidation event (undo, redo, load, action change). Phase 5 caches compare their stored generation against `get_cache().generation` — if mismatched, the cache is stale.

This avoids Phase 5 inventing its own invalidation tracking.

---

## 4. HANDLER REGISTRY RECOMMENDATION

### Where it should live
`core/draw_registry.py` — a new core module, peer to `registry.py`, `runtime.py`, `cache.py`.

### What it should track
```python
@dataclass(frozen=True)
class HandlerEntry:
    handle: object          # opaque handle returned by draw_handler_add
    space_type: str         # e.g. "VIEW_3D"
    region_type: str        # e.g. "WINDOW"
    callback: Callable      # the draw function
    draw_mode: str          # "POST_VIEW", "POST_PIXEL", "PRE_VIEW"
    tag: str                # human-readable, e.g. "p5_trajectory_overlay"
    created_at: float       # time.monotonic() for leak-age detection
```

Plus a module-level:
```python
_entries: dict[int, HandlerEntry] = {}
_next_id: int = 0
```

### How it should register/unregister

**Register**:
```python
def register_handler(space_type, region_type, callback, draw_mode, tag) -> int:
    global _next_id
    space_cls = getattr(bpy.types, f"Space{_SPACE_MAP[space_type]}", None)
    handle = space_cls.draw_handler_add(callback, (), region_type, draw_mode)
    hid = _next_id; _next_id += 1
    _entries[hid] = HandlerEntry(handle, space_type, region_type, callback, draw_mode, tag, time.monotonic())
    return hid
```

**Unregister single**:
```python
def unregister_handler(hid: int) -> bool:
    entry = _entries.pop(hid, None)
    if entry is None: return False
    space_cls = getattr(bpy.types, f"Space{_SPACE_MAP[entry.space_type]}", None)
    space_cls.draw_handler_remove(entry.handle, entry.region_type)
    return True
```

**Unregister all** (called from `__init__.unregister()` and `load_post`):
```python
def unregister_all() -> int:
    count = 0
    for hid in list(_entries):
        if unregister_handler(hid): count += 1
    return count
```

### How stale entries should be detected
- `enumerate()` returns all entries; diagnostics check `created_at` age.
- A `validate()` method attempts a no-op on each entry; if the space type or handle is dead (post file-load), the entry is pruned.
- The `load_post` app handler calls `unregister_all()` unconditionally — this is the primary staleness defense.

---

## 5. CACHE / DEPSGRAPH STRATEGY

### What should be cached
- **Trajectory sample points**: per-bone or per-object, a list of `(frame, world_position)` tuples sampled across the playback range. This is the expensive part — fcurve evaluation + matrix chain per frame per target.
- **Active action identity**: `(action.name, action.as_pointer())` — if either changes, the cache is invalid.
- **Cache generation**: integer matching `SessionCache.generation`.

### What should NEVER be queried in a draw callback
- `bpy.context.evaluated_depsgraph_get()` — crashes or returns stale data depending on Blender version.
- `bpy.context.scene.frame_current` — may not reflect the visible frame during playback scrub.
- `context.active_object` / `context.selected_pose_bones` — the draw callback has no reliable `context`.
- Any RNA property read that triggers a depsgraph update (e.g. reading `obj.matrix_world` on an unevaluated object).

### What should be queried live (guarded)
- The object's `matrix_world` can be read from the **evaluated** object passed at cache-build time, never at draw time.
- GPU state (shader uniforms, line width, color) is set at draw time — this is safe.

### Invalidation events Phase 5 must recognize

| Event | Source | Required Action |
|---|---|---|
| Undo / Redo | `undo_post` / `redo_post` app handler | Invalidate all trajectory caches |
| File Load | `load_post` app handler | `draw_registry.unregister_all()` + clear all caches |
| Action Change | Cache generation mismatch (already in `cache.py`) | Rebuild affected caches |
| Object Deletion | `depsgraph_update_post` with `update.is_updated_geometry` | Remove orphan cache entries |
| Scene Switch | `depsgraph_update_post` or explicit check | Rebuild caches for new scene |
| Frame Change | `frame_change_post` (only if live-updating ghost tail) | Optional partial cache update |
| Addon Disable | `__init__.unregister()` | `draw_registry.shutdown()` |

---

## 6. NON-OBVIOUS FAILURE MODES TO PREVENT

1. **Double-register on F8 reload**: if `register()` is called without a prior `unregister()` (common during addon development), every draw handler is orphaned. The registry's `init()` must call `unregister_all()` defensively before resetting.

2. **Draw callback after action deletion**: if the user deletes the action while a trajectory overlay is active, the cached fcurve `id()` references are dead. The draw callback must validate cache freshness before dereferencing any Blender RNA pointer.

3. **GPU shader compile in draw callback**: Blender's GPU module can raise on first shader compile. A `try/except` in the draw callback that disables the overlay on failure is essential — an unhandled exception in a draw handler freezes the viewport.

4. **`POST_VIEW` vs `POST_PIXEL` coordinate mismatch**: trajectory lines must use `POST_VIEW` (3D world space). If any helper accidentally draws in `POST_PIXEL` (screen space), the overlay appears to "stick" to the camera. The registry's `draw_mode` field makes this auditable.

5. **Modal + overlay concurrent state**: Phase 4's modal offset (`modal_preview_active`) and Phase 5's overlay can coexist. If the overlay reads the same fcurves the modal is snapshot/restoring, the overlay will render the pre-commit intermediate state. The overlay must either skip drawing during modal preview or read from its own cache that is frozen during modal.

6. **Per-space-instance handler duplication**: if an operator calls `register_handler` for each 3D viewport area, splitting a viewport doubles the handlers but only one viewport gets the remove. The registry must either track per-region handles or use a single global callback with per-space filtering.

7. **Thread safety of cache writes**: Blender's `depsgraph_update_post` can fire from a background thread during playback. Any cache write triggered by this handler must be guarded (or deferred to main-thread via a flag) to avoid dict-mutation-during-iteration in the draw callback.

8. **Undo step across overlay toggle**: if the user enables the overlay, then undoes, the PropertyGroup toggle reverts but the draw handler remains registered. The `undo_post` handler must reconcile the registry state with the property state, not just invalidate caches.

---

## 7. PRE-PHASE-5 ACTION LIST

1. **REQUIRED BEFORE PHASE 5** — Create `core/draw_registry.py` with the `HandlerEntry` / `register_handler` / `unregister_handler` / `unregister_all` / `enumerate` / `init` / `shutdown` API described in Section 4.

2. **REQUIRED BEFORE PHASE 5** — Wire `draw_registry.init()` and `draw_registry.shutdown()` into `__init__.py`'s `register()` / `unregister()` flows, including the exception-rollback path. `shutdown()` must call `unregister_all()`.

3. **REQUIRED BEFORE PHASE 5** — Register `load_post` and `undo_post` / `redo_post` app handlers in `__init__.py` (or a dedicated `core/app_handlers.py`) that call `draw_registry.unregister_all()` on load and increment `SessionCache.generation` on undo/redo. Use the tracked-append pattern from `ui/headers.py`.

4. **REQUIRED BEFORE PHASE 5** — Add a `generation: int` counter to `SessionCache` with an `invalidate_generation()` method. This is the single invalidation signal for all Phase 5 caches.

5. **STRONGLY RECOMMENDED** — Add `overlay_enabled: bool` and `active_overlay_tags: set[str]` to `RuntimeState`. This lets Phase 4's modal operator check `runtime.get_state().overlay_enabled` to coordinate with the overlay, and lets panels conditionally show overlay controls.

6. **STRONGLY RECOMMENDED** — Add a `validate()` method to the draw registry that iterates entries and prunes any whose space type class no longer exists (defense against file-load edge cases that slip past the app handler).

7. **OPTIONAL** — Refactor the `ui/headers.py` tracked-append pattern into a small reusable `TrackedAppendList` helper in `core/`, since the same pattern will be needed for app handlers. This avoids duplicating the `_appended` / `register` / `unregister` boilerplate.

---

## 8. PROMPT ADDITIONS FOR PHASE 5

The following text should be appended verbatim to the Phase 5 generation prompt:

```
PHASE 5 ARCHITECTURAL CONSTRAINTS
──────────────────────────────────
The following infrastructure exists and MUST be used. Do not create parallel
systems.

1. DRAW HANDLER LIFECYCLE
   - All draw handlers MUST be registered through `core.draw_registry.register_handler()`.
   - Never call `bpy.types.SpaceView3D.draw_handler_add()` directly.
   - Every handler registration must include a human-readable `tag` string
     (e.g. "p5_trajectory_overlay") for diagnostics.
   - On operator cancel, exception, or explicit disable, call
     `draw_registry.unregister_handler(handle_id)`.
   - `draw_registry.unregister_all()` is called automatically on addon
     unregister and on `load_post`.

2. DEPSGRAPH / CONTEXT RULES FOR DRAW CALLBACKS
   - Draw callbacks receive NO operator context. Never call
     `bpy.context.evaluated_depsgraph_get()` from inside a draw callback.
   - All animation data (trajectory samples, bone positions, fcurve values)
     must be pre-computed outside the draw callback and stored in a cache.
   - The cache must store `SessionCache.generation` at build time and
     compare it on every draw; if stale, skip drawing (do not rebuild
     inside the draw callback).
   - Cache rebuilds happen in operator `execute()`, `invoke()`, or in an
     app handler callback — never in the draw callback itself.

3. CACHE INVALIDATION
   - Use `cache.get_cache().generation` as the single staleness signal.
   - Generation is incremented automatically on undo, redo, and action change.
   - On `load_post`, all caches are destroyed along with all draw handlers.
   - Phase 5 caches must be stored in a module-level dict keyed by
     `(action.as_pointer(), target_data_path)` and cleared in a
     `_p5_clear_singletons()` function wired into `__init__.unregister()`.

4. MODAL / OVERLAY COORDINATION
   - If `runtime.get_state().get("p4_modal_active")` is truthy, the overlay
     must either freeze its display or skip drawing entirely. The Phase 4
     modal snapshot/restore cycle will corrupt the overlay's cached data
     if it reads live fcurve state during modal preview.
   - Conversely, Phase 5 must set `runtime.get_state().set("p5_overlay_active", True)`
     while overlays are drawing so future phases can detect overlay presence.

5. GPU ERROR RESILIENCE
   - Every draw callback must be wrapped in try/except. On GPU shader
     compile failure or any exception, the callback must:
     (a) log the error,
     (b) call `draw_registry.unregister_handler(self_handle_id)`,
     (c) set `runtime.get_state().overlay_enabled = False`.
   - Never let an unhandled exception propagate from a draw callback.

6. CLEANUP CONTRACT
   - Operator finish: unregister any per-operator draw handler.
   - Operator cancel: restore state, then unregister.
   - Exception: the draw callback's try/except handles this.
   - Addon reload (F8): `draw_registry.shutdown()` in `__init__.unregister()`
     removes all handlers.
   - File reload: `load_post` app handler calls `draw_registry.unregister_all()`.
   - Scene switch: `depsgraph_update_post` increments cache generation.
   - Object deletion: stale cache entries detected by pointer comparison
     at next cache validation pass.
   - Undo/redo: `undo_post`/`redo_post` increment cache generation;
     overlay skips drawing until cache is rebuilt.

7. REGISTRATION PATTERN
   - Phase 5 PropertyGroup: `Scene.anim_assist_p5` following the P3/P4 pattern.
   - Phase 5 classes: added to `operators/__init__.py` and `ui/__init__.py`
     CLASSES tuples following existing aggregation order.
   - Phase 5 singletons: cleared in `_p5_clear_singletons()` added to
     `__init__.unregister()`.
   - Phase 5 help entries: `help_phase5_entries.py` following Phase 4 pattern.
```

---

*Review completed. The codebase is structurally healthy through Phase 4. The four REQUIRED items (draw registry, init wiring, app handlers, cache generation) are each small, focused additions that slot into existing patterns without restructuring. Once they are in place, Phase 5 can be generated with full lifecycle safety.*
