# PHASE 8 — SYSTEMS INTEGRITY AUDIT GATE

**Addon:** Anim Assist v1.0.0  
**Phase:** 8 — Matching, Space Switching, and Compensation  
**Audit date:** 2026-04-10  
**Auditor:** Automated 4-pass review (structural, semantic, integration, regression)

---

## 1. GATE DECISION

### REWORK

Two blocking defects prevent PASS: one crash-level missing function (`match_to_targets`) and one systemic missing-poll pattern across all 9 switch operators. Both are localized and fixable without architectural change. No HALT-level issues (no data-loss vectors, no registration chain corruption, no security concerns).

---

## 2. EXECUTIVE SUMMARY

Phase 8 delivers 45 operators across four modules (match, switch, detect, batch), one core math library, one detection engine, one history stack, one PropertyGroup with 24 properties, 54 help entries, and three panel variants (Dope Sheet, Graph Editor, View 3D). The implementation correctly follows the addon's established patterns: callable-items enums, PanelAnatomyMixin sections, ClassRegistry rollback, and the `_H()` help factory.

Two defects block release. First, `AA_OT_p8_contact_preserve_match` and `AA_OT_p8_quick_match` both call `mm.match_to_targets()`, a function that does not exist in `p8_match_math.py`. These operators will raise `AttributeError` at runtime. Second, all 9 operators in `p8_switch_ops.py` lack `poll()` classmethods, meaning they can be invoked from any editor context without a valid active object, armature, or scene — leading to `NoneType` attribute errors or silent no-ops.

Four medium-severity issues round out the findings: an unused variable in the match math, un-scoped module-level globals in two operator files, and an incorrect `old_value` assignment in the repeat-last-switch event recorder.

All 30 pure-Python unit tests pass. Core module syntax checks pass. Registration wiring (operators/__init__.py, ui/__init__.py, root __init__.py) is correctly ordered and includes rollback teardown.

---

## 3. SPEC COVERAGE MAP

| Spec Feature Category | Specified | Implemented | Covered | Notes |
|---|---|---|---|---|
| Transform Matching operators | 15 | 15 | 15/15 | All have poll(), all call verified functions |
| Space Switch operators | 9 | 9 | 9/9 | All lack poll() (Finding F-02) |
| Rig Detection operators | 12 | 12 | 12/12 | All have poll(), _cached_patterns global (F-05) |
| Batch / History / Contact operators | 9 | 9 | 7/9 | 2 crash on match_to_targets (F-01) |
| Core math library | 1 module | 1 module | Complete | Unused var (F-03) |
| Switch detection engine | 1 module | 1 module | Complete | 4 detectors + keyword scorer |
| Switch history stack | 1 module | 1 module | Complete | Ephemeral, no persistence |
| PropertyGroup (Scene-scoped) | 24 props | 24 props | Complete | Callable-items enums, GC-safe |
| Help entries | 45+ | 54 | Complete | 45 operator + 9 conceptual entries |
| Panels (DS + GE + V3D) | 3 | 3 | Complete | PanelAnatomyMixin, make_editor_variants |
| Unit tests (pure Python) | - | 30 | 30/30 pass | No Blender-dependent tests |

**Operator Census (45 total):**

- `p8_match_ops.py` — 15 operators (all have poll)
- `p8_switch_ops.py` — 9 operators (none have poll)
- `p8_detect_ops.py` — 12 operators (all have poll)
- `p8_batch_ops.py` — 9 operators (all have poll)

---

## 4. SCORECARD

Scoring: Impact (1-5) x Likelihood (1-5) = Risk. Threshold: any single risk >= 15 blocks PASS.

| ID | Dimension | Score | Rating | Notes |
|---|---|---|---|---|
| S1 | Syntax / import correctness | 9/10 | PASS | All 8 modules compile cleanly; one unused variable |
| S2 | Blender registration chain | 10/10 | PASS | PropertyGroups before operators, CLASSES tuple correct, rollback teardown wired |
| S3 | Operator poll() guards | 4/10 | FAIL | 9/45 operators lack poll() — systemic in p8_switch_ops.py |
| S4 | API surface consistency | 3/10 | FAIL | match_to_targets() called but not defined; will crash 2 operators |
| S5 | Enum GC safety | 10/10 | PASS | All enums use callable-items with default=0 |
| S6 | UI/UX directive compliance | 9/10 | PASS | PanelAnatomyMixin sections, explained_op/prop, section_header — all 8 rules met |
| S7 | Help entry coverage | 9/10 | PASS | 54 entries for 45 operators + concepts; IDs match bl_idnames |
| S8 | State management | 6/10 | WARN | 3 module-level globals not scene-scoped (preview state, cached patterns) |
| S9 | Error handling / safety | 7/10 | WARN | try/except around path_resolve, but repeat_last_switch records wrong old_value |
| S10 | Test coverage | 7/10 | PASS | 30/30 pure tests pass; no Blender-context integration tests |

**Aggregate: 74/100 — REWORK required (threshold for PASS: 80, no FAIL dimensions)**

---

## 5. RISK REGISTER

### F-01 — CRITICAL: `match_to_targets()` does not exist

- **Impact:** 5 | **Likelihood:** 5 | **Risk:** 25 (BLOCKER)
- **Location:** `operators/p8_batch_ops.py` lines 286, 390
- **Affected operators:** `AA_OT_p8_contact_preserve_match`, `AA_OT_p8_quick_match`
- **Symptom:** `AttributeError: module 'core.p8_match_math' has no attribute 'match_to_targets'` on execute
- **Root cause:** The function was planned but never implemented in `p8_match_math.py`. The module exposes `compute_match()` which operates on a single source-world matrix and single target object — not a multi-target signature.
- **Fix:** Replace both call sites with the existing `compute_match()` API. For `quick_match`, match active to the first selected target's world matrix. For `contact_preserve_match`, iterate targets and use `compute_match()` per target, then apply contact offset restoration.

### F-02 — HIGH: Missing poll() on all 9 switch operators

- **Impact:** 4 | **Likelihood:** 4 | **Risk:** 16 (BLOCKER)
- **Location:** `operators/p8_switch_ops.py` — all 9 classes
- **Affected operators:** compensate_single, compensate_multi, bake_switch_range, bake_switch_preview, switch_enum, switch_bool, switch_influence, restore_switch, toggle_preview
- **Symptom:** Operators callable from any context; will produce `NoneType` errors when `context.active_object` is None or when no armature is active.
- **Fix:** Add `@classmethod def poll(cls, context)` to each operator. Most need `context.active_object is not None`; compensation operators additionally need armature or pose-bone context.

### F-03 — MEDIUM: Unused variable `parent_combined`

- **Impact:** 2 | **Likelihood:** 3 | **Risk:** 6
- **Location:** `core/p8_match_math.py` line 263
- **Detail:** `parent_combined = p_world @ target_obj.matrix_parent_inverse.inverted_safe()` is computed but never read. The correct variable `effective_parent` is computed on line 266.
- **Fix:** Delete line 263.

### F-04 — MEDIUM: Un-scoped module-level globals in switch ops

- **Impact:** 3 | **Likelihood:** 3 | **Risk:** 9
- **Location:** `operators/p8_switch_ops.py` lines 16-17 (`_preview_state`, `_preview_obj_name`)
- **Detail:** Preview state persists across scenes and file loads. If user switches .blend files, stale state could reference non-existent objects.
- **Fix:** Clear both globals in `app_handlers.load_post` callback, or move to a session-scoped dict keyed by scene name.

### F-05 — MEDIUM: Un-scoped cached patterns in detect ops

- **Impact:** 3 | **Likelihood:** 3 | **Risk:** 9
- **Location:** `operators/p8_detect_ops.py` line 19 (`_cached_patterns`)
- **Detail:** Detected rig patterns persist across file loads. Existing `clear_cached_patterns()` function exists (line 29) but is not wired into any load_post handler.
- **Fix:** Wire `clear_cached_patterns()` into `app_handlers.load_post`, or call it from the unregister teardown chain (partially done via `p8_hist_mod.clear_history` pattern).

### F-06 — MEDIUM: Wrong old_value in repeat_last_switch

- **Impact:** 3 | **Likelihood:** 2 | **Risk:** 6
- **Location:** `operators/p8_batch_ops.py` line 467
- **Detail:** `SwitchEvent` is created with `old_value=event.new_value` instead of the current property value before re-applying. The history entry will show incorrect before/after values.
- **Fix:** Read the current property value via `path_resolve` before applying, and use that as `old_value`.

### F-07 — LOW: Help entry count docstring inaccuracy

- **Impact:** 1 | **Likelihood:** 1 | **Risk:** 1
- **Location:** `core/help_phase8_entries.py` line 3
- **Detail:** Docstring says "45+ HelpEntry records" but there are 54 `_H()` calls. Not a functional issue.
- **Fix:** Update docstring to "54 HelpEntry records".

---

## 6. MANUAL QA ESCALATION PLAN

These tests require a running Blender 4.2+ instance with the addon installed.

### QA-1: Registration smoke test
1. Install addon via Edit > Preferences > Add-ons
2. Verify no console errors on enable
3. Open Dope Sheet sidebar — confirm "Match & Switch" panel appears
4. Open Graph Editor sidebar — confirm Graph Editor variant appears
5. Open View 3D sidebar — confirm V3D match panel appears
6. Disable and re-enable addon — verify clean cycle with no orphan properties

### QA-2: Transform matching (requires scene with parented objects)
1. Create Cube parented to Empty; move Empty to (3, 0, 0); move Cube locally to (1, 1, 0)
2. Select Cube, run Match to World — Cube should snap to world origin
3. Undo, run Match to Parent — Cube should sit at Empty's position
4. Add second Empty at (0, 5, 0); select both Cube and second Empty, run Match Selected to Active
5. Verify Cube matches second Empty's world position
6. Test axis-filtered match: match location X only, verify Y/Z unchanged

### QA-3: Space-switch compensation (requires rigged armature with space-switch enum)
1. Load rig with `["space"]` custom property on a bone (enum: 0=World, 1=Parent, 2=Head)
2. Pose the hand bone, run Compensate Single — change space from 0 to 1
3. Verify hand bone stays visually in the same position after compensation
4. Test Compensate Multi across frames 1-24 with space change at frame 12

### QA-4: Batch switch baking
1. Set up 3 switch events at frames 10, 20, 30 (mark with Switch Marker)
2. Run Bake Switch Range for frames 1-40
3. Verify keyframes inserted at switch frames with correct compensation
4. Navigate with Nav Next / Nav Prev — confirm timeline jumps to switch frames

### QA-5: Rig detection
1. Load a Rigify-generated armature
2. Run Detect All — verify patterns found for IK/FK switch properties
3. Run Apply Detected Pattern — verify switch settings populated
4. Run Save Switch Preset, then Load Switch Preset — verify round-trip

### QA-6: Contact preservation (BLOCKED by F-01)
1. Cannot test until `match_to_targets` crash is fixed
2. After fix: match with contact mask, verify foot bone stays planted

### QA-7: Quick match (BLOCKED by F-01)
1. Cannot test until `match_to_targets` crash is fixed
2. After fix: select two objects, run Quick Match, verify transform snap

### QA-8: Crash resistance for switch ops (tests F-02 fix)
1. Deselect all objects, invoke each switch operator from search menu
2. Verify each returns `{'CANCELLED'}` or is greyed out — never crashes

---

## 7. CUMULATIVE HEALTH NOTE

| Phase | Gate Result | Open Defects | Tests |
|---|---|---|---|
| 1 — Foundation | PASS | 0 | 53/53 |
| 2 — Key Workflows | PASS | 0 | 53/53 |
| 3 — Breakdown | PASS | 0 | 53/53 |
| 4 — Offset | PASS | 0 | 53/53 |
| 5 — Trajectory | PASS | 0 | 53/53 |
| 6 — Retime | PASS | 0 | 53/53 |
| 7 — Controls | PASS (after rework) | 0 | 53/53 |
| **8 — Matching** | **REWORK** | **7 (2 blocking)** | **30/30 (phase) + 53/53 (cumulative)** |

Registration chain integrity is maintained — Phase 8 classes register after Phase 7, unregister before Phase 7, and rollback teardown is correctly wired. The root `__init__.py` follows the established pattern. No regression to earlier phases detected.

The two blocking defects (F-01, F-02) are isolated to `p8_batch_ops.py` and `p8_switch_ops.py` respectively. Fixing them does not require changes to core math, properties, panels, help entries, or the registration chain.

---

## 8. FINAL VERDICT

**REWORK.** Fix F-01 and F-02 (blockers), then address F-03 through F-06 (medium). Re-run this audit gate after fixes. Expected effort: the two blockers require approximately 60 lines of code changes total. The medium findings require approximately 40 additional lines. No architectural changes needed.

Recommended fix order:
1. **F-01** — Replace `match_to_targets()` calls with `compute_match()` (unblocks QA-6, QA-7)
2. **F-02** — Add `poll()` to all 9 switch operators (unblocks QA-8)
3. **F-03** — Delete unused variable
4. **F-04** — Clear preview globals on file load
5. **F-05** — Wire cached pattern clearing into load_post
6. **F-06** — Fix old_value in repeat_last_switch
7. **F-07** — Update docstring count
