# Phase 5 Systems Integrity Audit

## 1. GATE DECISION

# REWORK

---

## 2. EXECUTIVE SUMMARY

- **Import-time crash**: `operators/p5_overlay_ops.py` imports `get_palette` from `core.p5_colors`, but that function does not exist. The actual function is `palette_by_id`. This is a **deterministic ImportError** that prevents the addon from loading.
- **Blender 4.x shader API usage is correct**: `SMOOTH_COLOR` and `FLAT_COLOR` are valid Blender 4.x built-in shader names (the 3D/2D prefix was dropped in 4.0).
- **`run_all_detectors` parameter mismatch**: The overlay operator does not pass `flat_threshold`, `zigzag_count`, or `stop_threshold`, leaving them at hardcoded defaults. These should either be exposed as p5 properties or explicitly wired.
- **Module-level `_draw_issues` accessed via private attribute** in `p5_nav_ops.py` (`p5_draw_mod._draw_issues`). While functional, this is fragile coupling to an internal name.
- **draw_paths_3d does not honour `p5.path_width`**: The property exists but is ignored; line width is hardcoded to 2.0 in the draw callback.
- **`_on_load_post` does not clear `p5_draw` state**: After file load, `draw_registry.unregister_all()` removes handler registrations, but `_draw_paths`, `_draw_issues`, `_draw_score` are never cleared. The stale data persists until the next enable/refresh cycle, and since the handler IDs in `p5_draw` are also not reset, `get_handler_ids()` returns stale IDs that no longer correspond to live handlers.
- **Registration order places `_p5_property_classes` inside the operators CLASSES tuple** rather than before all operator classes. This works because `operators/__init__.py` places them in the tuple before the operator entries, but the comment pattern is inconsistent with Phase 3/4 where property classes came first at the import-block level.
- **Phase 5 is structurally well-integrated** with draw_registry, app_handlers, and the existing lifecycle. The architecture is sound once the critical import bug is fixed.

---

## 3. SPEC COVERAGE MAP

| # | Feature | Status | Evidence |
|---|---------|--------|----------|
| 1 | Enable trajectory overlay | Full | `AA_OT_p5_enable_overlay` in p5_overlay_ops.py |
| 2 | Disable trajectory overlay | Full | `AA_OT_p5_disable_overlay` |
| 3 | Refresh trajectory overlay | Full | `AA_OT_p5_refresh_overlay` |
| 4 | Display mode (Active/Multi/Isolate) | Full | `display_mode` EnumProperty + operator logic |
| 5 | Isolate target | Full | `AA_OT_p5_isolate_target` |
| 6 | Mute unselected | Full | `AA_OT_p5_mute_unselected` |
| 7 | Palette presets (3) | Full | `TrajectoryPalette` + 3 instances in p5_colors.py |
| 8 | Scope mode (Around/Full/Custom) | Full | `scope_mode` EnumProperty + _resolve_frame_range |
| 9 | Window before/after | Full | IntProperty pair |
| 10 | Custom start/end | Full | FloatProperty pair |
| 11 | Sample step | Full | FloatProperty |
| 12 | Max samples | Full | IntProperty |
| 13 | Subframe sampling toggle | Full | BoolProperty (UI toggle exists) |
| 14 | Constraint evaluation toggle | Full | BoolProperty + `sample_path_constraints` |
| 15 | Fast fcurve sampler | Full | `sample_path_fast` in p5_sampling.py |
| 16 | Constraint-evaluated sampler | Full | `sample_path_constraints` |
| 17 | Velocity derivation | Full | `derive_velocity` |
| 18 | Segment lengths | Full | `segment_lengths` |
| 19 | Frame ticks | Full | draw_paths_3d + show_frame_ticks property |
| 20 | Keyframe ticks | Full | draw_paths_3d + show_keyframe_ticks property |
| 21 | Frame number labels | Partial | Property exists; `draw_labels_2d` draws them but only at keyframes, not gated on `show_frame_numbers` |
| 22 | Velocity vectors | Full | draw_paths_3d + show_velocity property |
| 23 | Tangent lines | Full | draw_paths_3d + show_tangent property |
| 24 | Ghost points | Full | draw_paths_3d + show_ghost_points property |
| 25 | Spacing colorization | Full | spacing_color + show_spacing_color |
| 26 | Deviation heatmap | Full | deviation_heatmap_color + show_deviation_heatmap |
| 27 | Space mode (World/Camera/Local) | Partial | Property exists but sampling always uses world_pos; Camera/Local modes have no effect |
| 28 | Path width | Partial | Property exists but draw callback ignores it (hardcoded 2.0) |
| 29 | Max display targets | Full | Capped in _resolve_targets |
| 30 | Arc drift detector | Full | detect_arc_drift |
| 31 | Flat arc detector | Full | detect_flat_arc |
| 32 | Zig-zag detector | Full | detect_zigzag |
| 33 | Pop detector | Full | detect_pop |
| 34 | Spacing issue detector | Full | detect_spacing_issues |
| 35 | Direction reversal detector | Full | detect_direction_reversal |
| 36 | Stop detector | Full | detect_stops |
| 37 | Apex/contact detector | Full | detect_apex_and_contacts |
| 38 | Run diagnostics operator | Full | `AA_OT_p5_run_diagnostics` |
| 39 | Jump next issue | Full | `AA_OT_p5_jump_next_issue` |
| 40 | Jump previous issue | Full | `AA_OT_p5_jump_prev_issue` |
| 41 | Select bad-arc keys | Full | `AA_OT_p5_select_bad_arc_keys` |
| 42 | Suggest candidate keys | Full | `AA_OT_p5_suggest_candidates` |
| 43 | Arc quality score | Full | `arc_quality_score` + badge in draw_labels_2d |
| 44 | Comparison mode | Partial | Properties exist (comparison_enabled, comparison_target) but no draw logic renders a second trajectory |
| 45 | Help entries (45) | Full | 45 HelpEntry records in help_phase5_entries.py |

---

## 4. SCORECARD

| Dimension | Rating | Notes |
|-----------|--------|-------|
| S1. Blender API Correctness | WARN | Shader names valid for 4.x; `blf.size` signature correct for 4.x (2 args). `SMOOTH_COLOR` returns a shader with `pos` + `color` attributes — correct. |
| S2. Animation Math / Data Correctness | PASS | Circumradius fit, velocity derivation, median calculations all correct. |
| S3. Registration & Load/Unload Safety | WARN | Import crash from `get_palette`; load_post does not clear p5_draw state or handler IDs. |
| S4. Context Safety & Defensive Coding | WARN | No poll() on any operator; `context.screen.areas` access can fail in background mode. |
| S5. Undo/Redo & State Hygiene | PASS | undo/redo bumps generation; overlay data is ephemeral (non-RNA module state). |
| S6. Cross-Phase Contract Integrity | PASS | Clean delegation to draw_registry, cache, runtime. No undeclared Phase 4 dependencies. |
| S7. UI/UX Foundation Compliance | PASS | Uses PanelAnatomyMixin, View3DSidebarPanel, ui_helpers correctly. Parent-before-child order. |
| S8. Spec Fidelity & Completeness | WARN | Comparison mode stub-only; space_mode and path_width not wired to draw; frame_numbers not gated on property. |
| S9. Performance & Scalability | WARN | derive_velocity called 3 times per target (issues + velocity + tangent), could be cached. |
| S10. Project Rule Compliance | PASS | No "animbot"; relative imports only; no Animaide overlap; anim_assist root maintained. |

---

## 5. RISK REGISTER

### R1. `get_palette` ImportError — CRITICAL

| Field | Value |
|-------|-------|
| Sev | CRITICAL |
| Dim | S3 |
| File | `operators/p5_overlay_ops.py` |
| Line(s) | 45 |
| Impact | 4 |
| Likelihood | 4 |
| Risk | 16 |

**Description**: Line 45 reads `from ..core.p5_colors import get_palette`. The function `get_palette` does not exist in `p5_colors.py`. The actual function is `palette_by_id`. This causes an `ImportError` at addon load time, which propagates through `operators/__init__.py` and prevents the entire addon from registering.

**Why it matters**: The addon will not load at all. Every feature in every phase is inaccessible.

**Before**:
```python
from ..core.p5_colors import get_palette
```

**After**:
```python
from ..core.p5_colors import palette_by_id as get_palette
```

---

### R2. `_on_load_post` does not clear `p5_draw` module state — HIGH

| Field | Value |
|-------|-------|
| Sev | HIGH |
| Dim | S3, S5 |
| File | `core/app_handlers.py` |
| Line(s) | 38–69 |
| Impact | 3 |
| Likelihood | 3 |
| Risk | 9 |

**Description**: When a new .blend file is loaded, `_on_load_post` calls `dreg.unregister_all()` which removes the draw handlers from Blender, but does not call `p5_draw.clear_draw_data()` or `p5_draw.clear_handler_ids()`. This leaves `_handler_3d` and `_handler_2d` holding stale IDs, and `_draw_paths` holding stale data. If the user then clicks "Disable Overlay", it will call `dreg.unregister_handler()` with IDs that were already removed, which returns False silently — benign. But `get_handler_ids()` returns stale positive IDs, so `AA_OT_p5_enable_overlay.execute()` sees `h3d >= 0` and reports "Overlay already active" — **blocking re-enable after file load**.

**Why it matters**: After loading a new .blend, the overlay is dead and the user sees "Overlay already active" with no visible overlay. Only an addon restart fixes it.

**Before**: `_on_load_post` does not touch `p5_draw`.

**After**: Add to `_on_load_post`:
```python
try:
    from . import p5_draw as p5_draw_mod
    p5_draw_mod.clear_draw_data()
    p5_draw_mod.clear_handler_ids()
except Exception:
    _log.debug("load_post: p5_draw state reset failed", exc_info=True)
```

---

### R3. `show_frame_numbers` property not checked in `draw_labels_2d` — MEDIUM

| Field | Value |
|-------|-------|
| Sev | MEDIUM |
| Dim | S8 |
| File | `core/p5_draw.py` |
| Line(s) | 377–385 |
| Impact | 2 |
| Likelihood | 3 |
| Risk | 6 |

**Description**: The frame-number labels at keyframe positions are always drawn in `draw_labels_2d` when `key_coords` and `key_frames` are populated, regardless of whether `show_frame_numbers` is enabled. The property exists in `p5_properties.py` but `build_draw_data()` does not accept it, and the draw callback has no conditional.

**Why it matters**: Frame number labels are drawn even when the user has turned them off, creating viewport clutter.

**Before**: `build_draw_data()` always populates `key_frames` when `show_keyframe_ticks` is True.

**After**: Add `show_frame_numbers: bool` parameter to `build_draw_data()`. Only populate `key_frames` when both `show_keyframe_ticks` and `show_frame_numbers` are True. Or alternatively, gate the blf draw loop in `draw_labels_2d` on a flag stored in `_PathDrawData`.

---

### R4. `path_width` property ignored in draw callback — MEDIUM

| Field | Value |
|-------|-------|
| Sev | MEDIUM |
| Dim | S8 |
| File | `core/p5_draw.py` |
| Line(s) | 276 |
| Impact | 2 |
| Likelihood | 3 |
| Risk | 6 |

**Description**: `p5_properties.path_width` exists (default 2.0, range 0.5–6.0) but `draw_paths_3d()` hardcodes `gpu.state.line_width_set(2.0)`. The property value never reaches the draw callback.

**Why it matters**: Animator cannot adjust path thickness despite the UI control being visible and adjustable.

**Before**: `gpu.state.line_width_set(2.0)` hardcoded.

**After**: Store `path_width` in `_PathDrawData` or pass it through to the draw module:
```python
# In build or set_draw_data, store the width
# In draw_paths_3d:
width = dd.path_width if hasattr(dd, 'path_width') else 2.0
gpu.state.line_width_set(width)
```

---

### R5. `space_mode` property has no effect — MEDIUM

| Field | Value |
|-------|-------|
| Sev | MEDIUM |
| Dim | S8 |
| File | `operators/p5_overlay_ops.py`, `core/p5_sampling.py` |
| Line(s) | Various |
| Impact | 2 |
| Likelihood | 3 |
| Risk | 6 |

**Description**: The `space_mode` property (WORLD/CAMERA/LOCAL) is stored and passed to `store_entry()` as part of the config hash, but neither sampler nor draw callback uses it to transform coordinates. Both samplers always produce world-space positions, and `draw_paths_3d` always draws those world-space positions. Selecting "Camera" or "Local" does nothing.

**Why it matters**: UI promises 3 coordinate spaces but only one works. Animator confusion.

**Before**: `space_mode` has no implementation.

**After**: For WORLD, current behavior is correct. For LOCAL, use `local_pos` from samples. For CAMERA, project through camera matrix. This may be acceptable as a Phase 5.1 item if documented, but should at minimum be disabled in the UI or shown as "World (others coming soon)".

---

### R6. No `poll()` on any Phase 5 operator — MEDIUM

| Field | Value |
|-------|-------|
| Sev | MEDIUM |
| Dim | S4 |
| File | `operators/p5_overlay_ops.py`, `operators/p5_nav_ops.py` |
| Line(s) | All operator classes |
| Impact | 2 |
| Likelihood | 3 |
| Risk | 6 |

**Description**: None of the 10 Phase 5 operators define a `poll()` classmethod. This means they appear as clickable in all contexts — even in the Image Editor, NLA, or when no scene/object exists. While the operators handle missing data with early returns, the buttons appear as functional when they should be greyed out.

**Why it matters**: Poor UX — buttons appear active when they cannot work. Risk of confusing error messages instead of a clean disabled state.

**Before**: No poll methods.

**After**: Add at minimum:
```python
@classmethod
def poll(cls, context):
    return (context.area and context.area.type == 'VIEW_3D'
            and getattr(context, "scene", None) is not None)
```

---

### R7. `derive_velocity` called up to 3 times per target — LOW

| Field | Value |
|-------|-------|
| Sev | LOW |
| Dim | S9 |
| File | `core/p5_draw.py` |
| Line(s) | 200, 213–216 |
| Impact | 1 |
| Likelihood | 3 |
| Risk | 3 |

**Description**: In `build_draw_data()`, `derive_velocity` is called when `show_velocity` is True (line 201), and again when `show_tangent` is True (lines 213–216 — note the incorrect double-call). Additionally, the issue detectors `detect_zigzag`, `detect_pop`, `detect_direction_reversal`, and `detect_stops` each call `derive_velocity` independently. For a 500-sample path, this is 6 redundant O(n) passes.

**Why it matters**: Performance drag on large frame ranges, proportional to the number of enabled visual options.

**Before**: Multiple independent `derive_velocity()` calls.

**After**: Compute velocity once in `build_draw_data` and pass the result to consumers, or cache at the `_build_all_draw_data` level.

---

### R8. Comparison mode has no draw implementation — LOW

| Field | Value |
|-------|-------|
| Sev | LOW |
| Dim | S8 |
| File | `core/p5_draw.py`, `operators/p5_overlay_ops.py` |
| Line(s) | N/A |
| Impact | 2 |
| Likelihood | 2 |
| Risk | 4 |

**Description**: `comparison_enabled` and `comparison_target` properties exist and are exposed in the Arc Diagnostics panel, but `_build_all_draw_data` never samples a comparison target and the draw callback has no logic to render a second trajectory with `comparison_a`/`comparison_b` palette colours.

**Why it matters**: The UI toggle does nothing. Animator expects a side-by-side trajectory but gets no visible change.

**Before**: No implementation.

**After**: Either implement comparison sampling + drawing, or remove/disable the UI controls with a "Coming Soon" annotation.

---

### R9. `_draw_issues` accessed as private attribute — LOW

| Field | Value |
|-------|-------|
| Sev | LOW |
| Dim | S6 |
| File | `operators/p5_nav_ops.py` |
| Line(s) | 39 |
| Impact | 1 |
| Likelihood | 2 |
| Risk | 2 |

**Description**: `p5_nav_ops._get_issues()` accesses `p5_draw_mod._draw_issues` directly. This couples the navigation operators to an internal implementation detail of the draw module.

**Why it matters**: Any refactor of the draw module's data structure will silently break navigation.

**Before**: `return p5_draw_mod._draw_issues`

**After**: Add a public accessor to `p5_draw`:
```python
def get_issues() -> list:
    return _draw_issues
```

---

## 6. MANUAL QA ESCALATION PLAN

### Tier 1 — Must test before merge (after R1/R2 fixes)

1. **Addon load/unload cycle**: Enable addon, verify Phase 5 panel appears in VIEW_3D sidebar. Disable addon, re-enable — verify no duplicate handlers or stale registrations.
2. **File load with overlay active**: Enable overlay, save file, open a different .blend, verify overlay is cleanly disabled and can be re-enabled on the new file.
3. **Undo/redo with overlay active**: Enable overlay, edit a keyframe, undo, verify trajectory updates (path reflects undo state, no stale data).
4. **Empty scene / no active object**: Open Phase 5 panel with no object selected. Press Enable Overlay. Verify graceful no-op, not a crash or traceback.
5. **Armature in Pose Mode with multiple bones selected**: Enable overlay in MULTI mode with 4+ bones. Verify each bone gets a trajectory. Switch to Object Mode — verify no crash (mode switch invalidates pose bone references).

### Tier 2 — Nice to test if time allows

1. **F8 script reload**: Edit the addon source, press F8 to reload scripts. Verify the overlay recovers cleanly (no double handlers, no stale draw data).
2. **Long frame range performance**: Set scope to Full Range on a 1000-frame scene with constraint evaluation. Verify viewport remains responsive (or times out gracefully).
3. **Issue navigation wraparound**: Run diagnostics, jump to last issue, press Next Issue — verify it wraps to the first issue.
4. **Select Bad-Arc Keys**: Run diagnostics on a scene with known bad arcs. Verify the correct keyframes are selected in the Graph Editor/Dope Sheet.
5. **Panel visibility in non-VIEW_3D editors**: Open Dope Sheet, Graph Editor — verify Phase 5 panels do not appear there (they should only be in VIEW_3D).

---

## 7. CUMULATIVE HEALTH NOTE

### New module dependencies
Phase 5 adds 10 new Python modules (6 core, 2 operator, 1 UI, 1 help) plus modifications to 3 existing files. The dependency graph is acyclic: `p5_colors` ← `p5_properties` ← `p5_overlay_ops`, `p5_sampling` ← `p5_issues` ← `p5_overlay_ops`, `p5_draw` ← `p5_overlay_ops`. No circular imports detected.

### Registration changes
- `operators/__init__.py`: 3 new import lines, 3 new tuple entries
- `ui/__init__.py`: 1 new import line, 1 new tuple entry
- `__init__.py`: 3 new imports, property registration, help registration, rollback/unregister entries
All changes follow established Phase 3/4 patterns.

### Probable regression surface
- `_on_load_post` handler now has a broader responsibility (must also clean p5_draw state). Any future overlay phase must add similar cleanup.
- The `operators/__init__.py` CLASSES tuple now has Phase 5 PropertyGroups listed after Phase 4 operators (they appear mid-tuple before Phase 5 operators). This works but deviates from the "all PropertyGroups first" comment pattern.
- The `generation`-based cache invalidation is sound but any module that stores samples must check generation or risk serving stale data.

### Maintenance burden
Moderate increase. The draw callback is the highest-maintenance surface — any GPU API change in future Blender versions will require updates here. The detector functions are pure math and low-maintenance. The 45 help entries will need updating if features are renamed. Overall, the phase is well-modularized and each concern has a single owner.

---

## 8. FINAL VERDICT

**REWORK** — Not ready for merge. Resolve listed findings first.

**Blocking items (must fix before re-audit):**
- R1: `get_palette` ImportError (addon won't load)
- R2: `_on_load_post` stale state (overlay dead after file load)

**Recommended fixes (should fix before merge):**
- R3: `show_frame_numbers` not gated
- R4: `path_width` not wired to draw
- R5: `space_mode` non-functional (at minimum disable UI)
- R6: No `poll()` methods

**Acceptable deferrals (document as Phase 5.1):**
- R7: `derive_velocity` redundancy
- R8: Comparison mode stub
- R9: Private attribute access
