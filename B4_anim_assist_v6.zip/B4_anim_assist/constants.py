"""Addon-wide constants and configuration."""

from __future__ import annotations

# Hardcoded for stable preferences lookup across legacy and extension loading.
ADDON_PACKAGE: str = "anim_assist"

ADDON_VERSION: tuple[int, int, int] = (1, 0, 0)
ADDON_VERSION_STRING: str = "1.0.0"

# RNA property attribute names attached to Blender types.
SCENE_PROP_ATTR: str = "anim_assist"
WM_PROP_ATTR: str = "anim_assist_wm"
OBJECT_META_ATTR: str = "anim_assist_meta"

# Module keys for preference-level enable/disable toggles (future phases).
MODULE_KEYS: tuple[str, ...] = (
    "selection",
    "keys",
    "transform",
    "breakdown",
    "trajectory",
    "retime",
    "controls",
    "matching",
    "orchestration",
    "layers",
)

# Migration system.
MIGRATION_CURRENT_VERSION: int = 1

# --- EXPLAINER SYSTEM EXTENSION ---
# Help / explainer subsystem constants.
HELP_ICON: str = "QUESTION"
HELP_POPUP_WIDTH: int = 400
HELP_DEFAULT_CATEGORY: str = "General"

# --- UI/UX FOUNDATION ---
# WindowManager attribute that hosts the transient UI state PropertyGroup
# defined in ``core/ui_state.py``. Future-phase panels read collapse/expand
# state through this attribute. The name is intentionally namespaced so it
# never collides with the existing ``WM_PROP_ATTR`` PointerProperty.
UI_STATE_ATTR: str = "anim_assist_ui"

# Sidebar category every Anim Assist panel docks under across all editors.
# Centralised so future phases never repeat the literal string.
ANIMASSIST_CATEGORY: str = "AnimAssist"

# --- PHASE 7 PREP ---
# Tagging constants for temporary scene artifacts (objects, collections,
# constraints) created by proxy / bake workflows.  All Phase 7 operators
# reference these rather than hard-coding tag strings.
P7_TAG_TEMP: str = "anim_assist_temp"
P7_TAG_SESSION_ID: str = "anim_assist_session_id"
P7_TAG_ARTIFACT_ROLE: str = "anim_assist_artifact_role"
P7_TAG_OWNER_OBJ: str = "anim_assist_owner_obj"
P7_CONSTRAINT_PREFIX: str = "AA_P7_"
P7_SCENE_SESSION_KEY: str = "anim_assist_p7_session"
P7_TEMP_COLLECTION_TEMPLATE: str = "AA_P7_Temp_{short_id}"

# Blender 4.x.