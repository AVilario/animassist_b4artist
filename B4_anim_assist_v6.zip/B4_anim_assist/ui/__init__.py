"""UI subpackage, class collection for registration, and Bforartists detection."""

from __future__ import annotations

import bpy

# ---------------------------------------------------------------------------
# Bforartists detection – defined FIRST so that headers.py can safely do
# ``from . import is_bforartists`` without hitting a circular import.
# ---------------------------------------------------------------------------

IS_BFORARTISTS: bool = False


def is_bforartists() -> bool:
    return IS_BFORARTISTS


def init_detection() -> None:
    global IS_BFORARTISTS
    IS_BFORARTISTS = "bforartists" in bpy.app.version_string.lower()


# ---------------------------------------------------------------------------
# Import submodules *after* is_bforartists is defined.
# ---------------------------------------------------------------------------

from .diagnostics_panel import AA_PT_diagnostics  # noqa: E402
from .panels import classes as _panel_classes       # noqa: E402
from .menus import classes as _menu_classes         # noqa: E402
from .p2_panels import classes as _p2_panel_classes  # noqa: E402
# --- PHASE 3 BREAKDOWN ---
from .p3_panels import CLASSES as _p3_panel_classes  # noqa: E402
# --- PHASE 4 OFFSET ---
from .p4_panels import CLASSES as _p4_panel_classes
# --- PHASE 5 TRAJECTORY ---
from .p5_panels import CLASSES as _p5_panel_classes  # noqa: E402
# --- PHASE 6 RETIME ---
from .p6_panels import CLASSES as _p6_panel_classes  # noqa: E402
# --- PHASE 7 CONTROLS ---
from .p7_panels import CLASSES as _p7_panel_classes  # noqa: E402
# --- PHASE 8 MATCHING ---
from .p8_panels import CLASSES as _p8_panel_classes  # noqa: E402
# --- PHASE 9 MIRRORING ---
from .p9_panels import CLASSES as _p9_panel_classes  # noqa: E402
# --- PHASE 10 ORCHESTRATION ---
from .p10_panels import CLASSES as _p10_panel_classes  # noqa: E402
from .p10_pie_menus import CLASSES as _p10_pie_menu_classes  # noqa: E402
# --- PHASE 11 ANIMATION LAYERS ---
from .p11_panels import CLASSES as _p11_panel_classes  # noqa: E402
from . import headers                               # noqa: E402
# --- EXPLAINER SYSTEM EXTENSION ---
from .help_browser import classes as _help_browser_classes  # noqa: E402
# --- UI/UX FOUNDATION ---
# UI state PropertyGroup classes are sourced from core.ui_state and
# registered through this package's CLASSES tuple so they participate
# in the existing ClassRegistry rollback machinery.
from ..core import ui_state as _ui_state_mod        # noqa: E402
# Re-export the shared drawing helpers and editor placement mixins so
# future-phase panels can ``from ..ui import ui_helpers, scope_ui,
# editor_placement, panel_anatomy`` from a single namespace.
from . import ui_helpers as ui_helpers              # noqa: E402, F401
from . import panel_anatomy as panel_anatomy        # noqa: E402, F401
from . import editor_placement as editor_placement  # noqa: E402, F401
from . import scope_ui as scope_ui                  # noqa: E402, F401

# ---------------------------------------------------------------------------
# Master class list – everything that goes through bpy.utils.register_class.
# Panels must be listed parent-before-child where bl_parent_id is used.
# UI state PropertyGroups are listed FIRST so the PointerProperty on
# WindowManager can resolve cleanly during ``register_properties``.
# ---------------------------------------------------------------------------

CLASSES: tuple[type, ...] = (
    # --- UI/UX FOUNDATION ---
    *_ui_state_mod.CLASSES,
    AA_PT_diagnostics,
    *_panel_classes,
    *_menu_classes,
    *_p2_panel_classes,
    # --- PHASE 3 BREAKDOWN ---
    *_p3_panel_classes,
    # --- PHASE 4 OFFSET ---
    *_p4_panel_classes,
    # --- PHASE 5 TRAJECTORY ---
    *_p5_panel_classes,
    # --- PHASE 6 RETIME ---
    *_p6_panel_classes,
    # --- PHASE 7 CONTROLS ---
    *_p7_panel_classes,
    # --- PHASE 8 MATCHING ---
    *_p8_panel_classes,
    # --- PHASE 9 MIRRORING ---
    *_p9_panel_classes,
    # --- PHASE 10 ORCHESTRATION ---
    *_p10_panel_classes,
    *_p10_pie_menu_classes,
    # --- PHASE 11 ANIMATION LAYERS ---
    *_p11_panel_classes,
    # --- EXPLAINER SYSTEM EXTENSION ---
    *_help_browser_classes,
)
