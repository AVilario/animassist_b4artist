"""Header appends for Graph Editor and Dope Sheet."""

from __future__ import annotations

from typing import Callable

import bpy
from . import is_bforartists

_appended: list[tuple[type, Callable]] = []


def _draw_graph_header(self, context: bpy.types.Context) -> None:
    layout = self.layout
    row = layout.row(align=True)
    row.separator()

    # Keep Bforartists lighter
    if not is_bforartists():
        for itype, label in (("CONSTANT", "C"), ("LINEAR", "L"), ("BEZIER", "B")):
            op = row.operator("animassist.batch_interpolation", text=label)
            op.interp_type = itype
        row.separator()
        row.menu("ANIMASSIST_MT_handle_type", text="", icon="HANDLE_AUTO")

    row.operator("animassist.blend_neighbor", text="", icon="TRACKING_FORWARDS_SINGLE")
    row.operator("animassist.blend_frame", text="", icon="IPO_BEZIER")
    row.operator("animassist.push_pull", text="", icon="FULLSCREEN_EXIT")
    row.operator("animassist.ease_to_ease", text="", icon="IPO_EASE_IN_OUT")
    row.operator("animassist.smooth_keys", text="", icon="SMOOTHCURVE")
    row.operator("animassist.blend_offset", text="", icon="ARROW_LEFTRIGHT")


def _draw_dopesheet_header(self, context: bpy.types.Context) -> None:
    layout = self.layout
    row = layout.row(align=True)
    row.separator()

    s = context.scene.anim_assist
    active = s.anim_offset_active
    row.operator("animassist.anim_offset", text="", icon="PAUSE" if active else "PLAY", depress=active)

    if not is_bforartists():
        row.separator()
        row.menu("ANIMASSIST_MT_key_type", text="", icon="KEYTYPE_KEYFRAME_VEC")
        row.menu("ANIMASSIST_MT_interpolation", text="", icon="IPO_BEZIER")


def register() -> None:
    bpy.types.GRAPH_HT_header.append(_draw_graph_header)
    _appended.append((bpy.types.GRAPH_HT_header, _draw_graph_header))

    bpy.types.DOPESHEET_HT_header.append(_draw_dopesheet_header)
    _appended.append((bpy.types.DOPESHEET_HT_header, _draw_dopesheet_header))


def unregister() -> None:
    for header_cls, func in reversed(_appended):
        header_cls.remove(func)
    _appended.clear()


classes: list[type] = []