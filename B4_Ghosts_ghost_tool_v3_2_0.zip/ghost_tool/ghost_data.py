"""
ghost_data.py — Ghost dataclass and GhostStore for the Ghost Tool addon.

This module defines the core data structures used throughout Ghost Tool:

- ``Ghost``: a dataclass representing a single interpolated marker
  between keyframes.
- ``GhostStore``: a scene-level container managing all Ghost instances
  with O(1) uid lookups and level/bone/channel filtering.
- ``generate_ghosts()``: recursive subdivision generator that creates
  ghosts from f-curves.
- ``generate_ghosts_frame_step()``: frame-by-frame generator for
  Cascadeur-style even-step ghosting.
- ``generate_ghosts_at_keyframes()``: keyframe-only generator.

All persistent ghost data is stored via Blender PropertyGroups attached
to ``bpy.types.Scene``, ensuring compatibility with undo/redo and file
save/load. The actual Ghost objects live in-memory in ``GhostStore``
and are persisted across sessions through JSON export/import.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Optional

import bpy
from mathutils import Vector

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_SUBDIVISION_LEVEL: int = 5
"""Maximum allowed recursive subdivision depth."""

KEYFRAME_SNAP_THRESHOLD: float = 0.5
"""Frames within this distance of an existing keyframe are skipped during generation."""

# Channel name mappings for common transform paths
CHANNEL_MAP: dict[str, str] = {
    "location": "location",
    "rotation_euler": "rotation_euler",
    "rotation_quaternion": "rotation_quaternion",
    "scale": "scale",
}


# ---------------------------------------------------------------------------
# Ghost Dataclass
# ---------------------------------------------------------------------------

@dataclass
class Ghost:
    """A single ghost marker representing an interpolated f-curve position.

    Ghosts sit between keyframes and visualize the in-between motion.
    They can be dragged to reshape the f-curve, pinned to act as
    constraints, or subdivided further for fine-grained control.

    Attributes:
        frame: The frame number this ghost represents (can be fractional).
        world_position: 3D world-space position for viewport display.
        local_value: The raw f-curve value at this frame.
        channel: The data path component, e.g. "location.x", "rotation_euler.z".
        bone_name: Name of the pose bone, or empty string for object channels.
        object_name: Name of the Blender object owning this channel.
        parent_frame_a: Frame number of the left parent keyframe.
        parent_frame_b: Frame number of the right parent keyframe.
        generation_level: Subdivision depth (1 = first midpoints, 2 = midpoints of midpoints).
        is_pinned: If True, this ghost acts as a soft constraint during recalculation.
        is_selected: If True, this ghost is currently selected for operations.
        uid: Unique identifier string (8-char hex from uuid4).
    """

    frame: float
    world_position: Vector = field(default_factory=lambda: Vector((0.0, 0.0, 0.0)))
    local_value: float = 0.0
    channel: str = ""
    bone_name: str = ""
    object_name: str = ""
    parent_frame_a: float = 0.0
    parent_frame_b: float = 0.0
    generation_level: int = 1
    is_pinned: bool = False
    is_selected: bool = False
    uid: str = field(default_factory=lambda: uuid.uuid4().hex[:8])

    def to_dict(self) -> dict:
        """Serialize this ghost to a plain dictionary for JSON export.

        Returns:
            dict: All ghost fields as JSON-serializable types.
        """
        return {
            "frame": self.frame,
            "world_position": list(self.world_position),
            "local_value": self.local_value,
            "channel": self.channel,
            "bone_name": self.bone_name,
            "object_name": self.object_name,
            "parent_frame_a": self.parent_frame_a,
            "parent_frame_b": self.parent_frame_b,
            "generation_level": self.generation_level,
            "is_pinned": self.is_pinned,
            "is_selected": self.is_selected,
            "uid": self.uid,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Ghost:
        """Deserialize a ghost from a dictionary (JSON import).

        Args:
            data: Dictionary with ghost field values.

        Returns:
            Ghost: Reconstructed ghost instance.
        """
        return cls(
            frame=data["frame"],
            world_position=Vector(data.get("world_position", (0.0, 0.0, 0.0))),
            local_value=data.get("local_value", 0.0),
            channel=data.get("channel", ""),
            bone_name=data.get("bone_name", ""),
            object_name=data.get("object_name", ""),
            parent_frame_a=data.get("parent_frame_a", 0.0),
            parent_frame_b=data.get("parent_frame_b", 0.0),
            generation_level=data.get("generation_level", 1),
            is_pinned=data.get("is_pinned", False),
            is_selected=data.get("is_selected", False),
            uid=data.get("uid", uuid.uuid4().hex[:8]),
        )


# ---------------------------------------------------------------------------
# GhostStore — In-memory container for all active ghosts
# ---------------------------------------------------------------------------

class GhostStore:
    """Scene-level container for all Ghost instances.

    GhostStore is accessed via the scene's custom property system.  Internally
    it keeps a flat list plus a uid-keyed index for O(1) lookups.

    Design note: Blender PropertyGroups cannot store arbitrary Python objects,
    so GhostStore maintains an in-memory dict that is rebuilt on file load
    via the export/import system.  The canonical truth for a running session
    lives here; serialization to JSON handles persistence across sessions.

    Usage:
        store = GhostStore.get(context.scene)
        store.add(ghost)
        store.get_by_uid("a1b2c3d4")
        store.filter_by_level(2)
    """

    # Class-level dict mapping scene names to GhostStore instances.
    # This avoids polluting bpy.types with complex Python objects.
    _instances: dict[str, GhostStore] = {}

    def __init__(self) -> None:
        """Initialize an empty ghost store."""
        self._ghosts: list[Ghost] = []
        self._index: dict[str, Ghost] = {}

    # --- Singleton access per scene ---

    @classmethod
    def get(cls, scene: bpy.types.Scene) -> GhostStore:
        """Retrieve or create the GhostStore for the given scene.

        Args:
            scene: The Blender scene to look up.

        Returns:
            GhostStore: The store associated with this scene.
        """
        key = scene.name
        if key not in cls._instances:
            cls._instances[key] = cls()
        return cls._instances[key]

    @classmethod
    def clear_instance(cls, scene_name: str) -> None:
        """Remove the GhostStore instance for a scene (used on unregister).

        Args:
            scene_name: Name of the scene whose store should be removed.
        """
        cls._instances.pop(scene_name, None)

    @classmethod
    def clear_all_instances(cls) -> None:
        """Remove all GhostStore instances (used during addon unregistration)."""
        cls._instances.clear()

    # --- CRUD operations ---

    def add(self, ghost: Ghost) -> None:
        """Add a ghost to the store.

        Args:
            ghost: The Ghost instance to add.

        Raises:
            ValueError: If a ghost with the same uid already exists.
        """
        if ghost.uid in self._index:
            raise ValueError(
                f"[Ghost Tool] Ghost with uid '{ghost.uid}' already exists in store."
            )
        self._ghosts.append(ghost)
        self._index[ghost.uid] = ghost

    def remove(self, uid: str) -> bool:
        """Remove a ghost by its unique identifier.

        Args:
            uid: The unique identifier of the ghost to remove.

        Returns:
            bool: True if the ghost was found and removed, False otherwise.
        """
        ghost = self._index.pop(uid, None)
        if ghost is None:
            return False
        self._ghosts.remove(ghost)
        return True

    def get_by_uid(self, uid: str) -> Optional[Ghost]:
        """Look up a ghost by its unique identifier.

        Args:
            uid: The unique identifier to search for.

        Returns:
            Ghost or None: The matching ghost, or None if not found.
        """
        return self._index.get(uid)

    def clear(self) -> None:
        """Remove all ghosts from the store."""
        self._ghosts.clear()
        self._index.clear()

    def replace_all(self, ghosts: list[Ghost]) -> None:
        """Atomically replace all ghosts in the store.

        Clears the current contents and adds all provided ghosts in one
        operation.  This is used by the pipeline to swap in a fresh set
        of evaluated ghosts without leaving the store in a partially
        empty state between clear() and add() calls.

        Args:
            ghosts: The new list of Ghost objects to store.
        """
        self._ghosts.clear()
        self._index.clear()
        for ghost in ghosts:
            if ghost.uid not in self._index:
                self._ghosts.append(ghost)
                self._index[ghost.uid] = ghost
            else:
                # Duplicate uid — skip with warning
                from .utils import warn
                warn(f"Duplicate uid '{ghost.uid}' during replace_all, skipping.")

    def clear_level(self, level: int) -> int:
        """Remove all ghosts at a specific generation level.

        Args:
            level: The generation level to remove.

        Returns:
            int: Number of ghosts removed.
        """
        to_remove = [g for g in self._ghosts if g.generation_level == level]
        for g in to_remove:
            self._index.pop(g.uid, None)
        self._ghosts = [g for g in self._ghosts if g.generation_level != level]
        return len(to_remove)

    # --- Query / filter operations ---

    @property
    def all_ghosts(self) -> list[Ghost]:
        """Return a shallow copy of the full ghost list.

        Returns:
            list[Ghost]: All ghosts currently in the store.
        """
        return list(self._ghosts)

    def __len__(self) -> int:
        """Return the number of ghosts in the store."""
        return len(self._ghosts)

    def __iter__(self):
        """Iterate over all ghosts."""
        return iter(self._ghosts)

    def filter_by_level(self, level: int) -> list[Ghost]:
        """Return ghosts matching a given generation level.

        Args:
            level: The generation level to filter by.

        Returns:
            list[Ghost]: Ghosts at the requested level.
        """
        return [g for g in self._ghosts if g.generation_level == level]

    def filter_by_bone(self, bone_name: str) -> list[Ghost]:
        """Return ghosts belonging to a specific bone.

        Args:
            bone_name: The pose bone name to filter by.

        Returns:
            list[Ghost]: Ghosts associated with that bone.
        """
        return [g for g in self._ghosts if g.bone_name == bone_name]

    def filter_by_channel(self, channel: str) -> list[Ghost]:
        """Return ghosts belonging to a specific channel.

        Args:
            channel: The channel identifier to filter by (e.g. "location.x").

        Returns:
            list[Ghost]: Ghosts associated with that channel.
        """
        return [g for g in self._ghosts if g.channel == channel]

    def filter_by_object(self, object_name: str) -> list[Ghost]:
        """Return ghosts belonging to a specific object.

        Args:
            object_name: The Blender object name to filter by.

        Returns:
            list[Ghost]: Ghosts associated with that object.
        """
        return [g for g in self._ghosts if g.object_name == object_name]

    def get_selected(self) -> list[Ghost]:
        """Return all currently selected ghosts.

        Returns:
            list[Ghost]: Ghosts with is_selected == True.
        """
        return [g for g in self._ghosts if g.is_selected]

    def get_pinned(self) -> list[Ghost]:
        """Return all pinned ghosts.

        Returns:
            list[Ghost]: Ghosts with is_pinned == True.
        """
        return [g for g in self._ghosts if g.is_pinned]

    def get_chain(self, object_name: str, bone_name: str, channel: str) -> list[Ghost]:
        """Return the ordered ghost chain for a specific object/bone/channel.

        Ghosts are sorted by frame number so they form a sequential chain
        suitable for drawing a motion arc.

        Args:
            object_name: The Blender object name.
            bone_name: The pose bone name (empty string for object channels).
            channel: The channel identifier (e.g. "location.x").

        Returns:
            list[Ghost]: Sorted ghosts matching all three criteria.
        """
        matches = [
            g for g in self._ghosts
            if g.object_name == object_name
            and g.bone_name == bone_name
            and g.channel == channel
        ]
        matches.sort(key=lambda g: g.frame)
        return matches

    def to_dict_list(self) -> list[dict]:
        """Serialize all ghosts to a list of dictionaries.

        Returns:
            list[dict]: Each ghost as a JSON-serializable dict.
        """
        return [g.to_dict() for g in self._ghosts]

    def load_from_dict_list(self, data: list[dict]) -> None:
        """Replace current store contents from a list of ghost dicts.

        Existing ghosts are cleared before loading.

        Args:
            data: List of ghost dictionaries (from JSON import).
        """
        self.clear()
        for item in data:
            try:
                ghost = Ghost.from_dict(item)
                self.add(ghost)
            except (KeyError, TypeError, ValueError) as exc:
                from .utils import warn
                warn(f"Skipping invalid ghost data during load: {exc}")


# ---------------------------------------------------------------------------
# Blender PropertyGroup — lightweight scene-level settings
# ---------------------------------------------------------------------------

class GhostToolSceneSettings(bpy.types.PropertyGroup):
    """Scene-level settings stored as a Blender PropertyGroup.

    These are the properties that survive undo/redo and file save/load.
    The actual Ghost objects live in GhostStore (in memory) and are
    persisted via JSON export for cross-session use.
    """

    is_active: bpy.props.BoolProperty(
        name="Ghost Display Active",
        description="Toggle ghost display in the viewport",
        default=False,
    )  # type: ignore[assignment]

    subdivision_level: bpy.props.IntProperty(
        name="Subdivision Level",
        description="Number of recursive subdivision passes (1 = midpoints only)",
        default=1,
        min=1,
        max=MAX_SUBDIVISION_LEVEL,
    )  # type: ignore[assignment]

    show_level_1: bpy.props.BoolProperty(name="Show Level 1", default=True)  # type: ignore[assignment]
    show_level_2: bpy.props.BoolProperty(name="Show Level 2", default=True)  # type: ignore[assignment]
    show_level_3: bpy.props.BoolProperty(name="Show Level 3", default=True)  # type: ignore[assignment]
    show_level_4: bpy.props.BoolProperty(name="Show Level 4", default=True)  # type: ignore[assignment]
    show_level_5: bpy.props.BoolProperty(name="Show Level 5", default=True)  # type: ignore[assignment]

    show_motion_arc: bpy.props.BoolProperty(
        name="Show Motion Arc",
        description="Draw a line connecting ghosts and keyframes",
        default=True,
    )  # type: ignore[assignment]

    show_spacing_ticks: bpy.props.BoolProperty(
        name="Show Spacing Ticks",
        description="Draw tick marks along the arc showing frame spacing",
        default=False,
    )  # type: ignore[assignment]

    curve_mode: bpy.props.EnumProperty(
        name="Curve Shape Mode",
        description="How f-curve handles behave when a ghost is moved",
        items=[
            ("FREE", "Free", "Handles adjust freely to pass through new position"),
            ("LOCKED", "Locked", "Handle angle is preserved, only length changes"),
            ("SMOOTH", "Smooth", "Handle influence is redistributed across the segment"),
        ],
        default="FREE",
    )  # type: ignore[assignment]

    grab_radius: bpy.props.IntProperty(
        name="Grab Radius",
        description="Screen-space pixel radius for ghost picking",
        default=20,
        min=5,
        max=100,
    )  # type: ignore[assignment]

    # Custom frame range for ghost generation
    use_custom_range: bpy.props.BoolProperty(
        name="Use Custom Range",
        description="Limit ghost generation to a custom frame range",
        default=False,
    )  # type: ignore[assignment]

    custom_range_start: bpy.props.IntProperty(
        name="Range Start",
        description="Start frame for ghost generation",
        default=1,
    )  # type: ignore[assignment]

    custom_range_end: bpy.props.IntProperty(
        name="Range End",
        description="End frame for ghost generation",
        default=250,
    )  # type: ignore[assignment]

    # ── Mesh Onion Skinning ──────────────────────────────────────────────
    # Controls for the transparent mesh duplicate system that renders
    # full character silhouettes at nearby frames (onion skinning).

    show_mesh_ghosts: bpy.props.BoolProperty(
        name="Show Mesh Ghosts",
        description="Display transparent mesh duplicates at ghost frames (onion skinning)",
        default=False,
    )  # type: ignore[assignment]

    mesh_ghost_past_count: bpy.props.IntProperty(
        name="Past Ghosts",
        description="Number of mesh ghosts to show before the current frame",
        default=3,
        min=0,
        max=16,
    )  # type: ignore[assignment]

    mesh_ghost_future_count: bpy.props.IntProperty(
        name="Future Ghosts",
        description="Number of mesh ghosts to show after the current frame",
        default=3,
        min=0,
        max=16,
    )  # type: ignore[assignment]

    mesh_ghost_step: bpy.props.IntProperty(
        name="Frame Step",
        description="Frame interval between mesh ghosts",
        default=2,
        min=1,
        max=24,
    )  # type: ignore[assignment]

    mesh_ghost_mode: bpy.props.EnumProperty(
        name="Mesh Ghost Mode",
        description="How mesh ghosts are displayed in the viewport",
        items=[
            ("SOLID", "Solid", "Semi-transparent shaded mesh"),
            ("WIRE", "Wireframe", "Wireframe silhouette only"),
        ],
        default="SOLID",
    )  # type: ignore[assignment]

    mesh_ghost_opacity: bpy.props.FloatProperty(
        name="Mesh Opacity",
        description="Maximum opacity for the closest mesh ghosts",
        default=0.35,
        min=0.05,
        max=0.8,
        subtype='FACTOR',
    )  # type: ignore[assignment]

    show_mesh_past: bpy.props.BoolProperty(
        name="Show Past Meshes",
        description="Show mesh ghosts from before the current frame",
        default=True,
    )  # type: ignore[assignment]

    show_mesh_future: bpy.props.BoolProperty(
        name="Show Future Meshes",
        description="Show mesh ghosts from after the current frame",
        default=True,
    )  # type: ignore[assignment]

    # ── Ghost Mode & Range ──────────────────────────────────────────────
    # How ghost frames are selected (subdivision vs frame-step vs
    # keyframes-only) and which frame range they cover.

    ghost_mode: bpy.props.EnumProperty(
        name="Ghost Mode",
        description="How ghost frames are selected",
        items=[
            ("SUBDIVISION", "Subdivision", "Recursive midpoint subdivision between keyframes (original mode)"),
            ("FRAME_STEP", "Frame Step", "Ghost at every Nth frame — like Cascadeur's frame-by-frame ghosting"),
            ("KEYFRAMES_ONLY", "Keyframes Only", "Ghost only at keyframe positions"),
        ],
        default="FRAME_STEP",
    )  # type: ignore[assignment]

    ghost_range_mode: bpy.props.EnumProperty(
        name="Range Mode",
        description="Which frames to generate ghosts across",
        items=[
            ("AROUND_CURSOR", "Around Cursor", "Show N ghosts before/after the current frame"),
            ("FULL_TIMELINE", "Full Timeline", "Show ghosts across the entire action or scene range"),
            ("BETWEEN_KEYS", "Between Keys", "Only between adjacent keyframes (like subdivision)"),
            ("CUSTOM", "Custom Range", "User-specified start/end frame"),
        ],
        default="AROUND_CURSOR",
    )  # type: ignore[assignment]

    frame_step: bpy.props.IntProperty(
        name="Frame Step",
        description="Generate a ghost every N frames",
        default=2,
        min=1,
        max=24,
    )  # type: ignore[assignment]

    ghosts_before: bpy.props.IntProperty(
        name="Before",
        description="Number of ghost frames before the current frame (Around Cursor mode)",
        default=8,
        min=0,
        max=64,
    )  # type: ignore[assignment]

    ghosts_after: bpy.props.IntProperty(
        name="After",
        description="Number of ghost frames after the current frame (Around Cursor mode)",
        default=8,
        min=0,
        max=64,
    )  # type: ignore[assignment]

    ghost_color_mode: bpy.props.EnumProperty(
        name="Color Mode",
        description="How ghosts are colored in the viewport",
        items=[
            ("LEVEL", "By Level", "Color by subdivision level (original mode)"),
            ("TIME", "Past/Future", "Blue for past frames, orange for future — Cascadeur style"),
            ("FADE", "Proximity Fade", "Bright near cursor, fading with distance"),
            ("RAINBOW", "Rainbow", "Full spectrum spread across the frame range"),
            ("KEY_INBETWEEN", "Key/Inbetween", "Distinct colors for keyframe vs in-between ghosts"),
        ],
        default="TIME",
    )  # type: ignore[assignment]

    ghost_fade_factor: bpy.props.FloatProperty(
        name="Fade Factor",
        description="How quickly ghost opacity fades with distance from the current frame",
        default=0.7,
        min=0.0,
        max=1.0,
        subtype='FACTOR',
    )  # type: ignore[assignment]

    # ── User-Configurable Colors ────────────────────────────────────────
    # Per-mode color overrides for ghost markers. Each color mode
    # (TIME, KEY_INBETWEEN, etc.) reads from these properties.

    ghost_past_color: bpy.props.FloatVectorProperty(
        name="Past Color",
        description="Color for ghosts before the current frame (Past/Future mode)",
        subtype='COLOR',
        size=3,
        default=(0.25, 0.55, 1.0),
        min=0.0,
        max=1.0,
    )  # type: ignore[assignment]

    ghost_future_color: bpy.props.FloatVectorProperty(
        name="Future Color",
        description="Color for ghosts after the current frame (Past/Future mode)",
        subtype='COLOR',
        size=3,
        default=(1.0, 0.55, 0.15),
        min=0.0,
        max=1.0,
    )  # type: ignore[assignment]

    ghost_key_color: bpy.props.FloatVectorProperty(
        name="Key Color",
        description="Color for ghosts at keyframe positions (Key/Inbetween mode)",
        subtype='COLOR',
        size=3,
        default=(1.0, 0.85, 0.0),
        min=0.0,
        max=1.0,
    )  # type: ignore[assignment]

    ghost_inbetween_color: bpy.props.FloatVectorProperty(
        name="Inbetween Color",
        description="Color for ghosts between keyframes (Key/Inbetween mode)",
        subtype='COLOR',
        size=3,
        default=(0.4, 0.75, 1.0),
        min=0.0,
        max=1.0,
    )  # type: ignore[assignment]

    ghost_label_color: bpy.props.FloatVectorProperty(
        name="Label Color",
        description="Color for frame number labels displayed next to ghosts",
        subtype='COLOR',
        size=3,
        default=(0.9, 0.9, 0.9),
        min=0.0,
        max=1.0,
    )  # type: ignore[assignment]

    ghost_min_alpha: bpy.props.FloatProperty(
        name="Min Alpha",
        description=(
            "Minimum opacity for the most distant ghosts. "
            "Higher values keep far ghosts more visible"
        ),
        default=0.15,
        min=0.0,
        max=0.5,
        subtype='FACTOR',
    )  # type: ignore[assignment]

    ghost_falloff_curve: bpy.props.EnumProperty(
        name="Falloff Curve",
        description="How ghost opacity falls off with distance from the current frame",
        items=[
            ("LINEAR", "Linear", "Straight-line fade — even reduction across the range"),
            ("SMOOTH", "Smooth", "Ease-in-out fade — gentle start and end, faster middle"),
            ("EXPONENTIAL", "Exponential", "Quick fade near cursor, slow tail — emphasis on close ghosts"),
            ("CONSTANT", "Constant", "No fade — all ghosts at full opacity"),
        ],
        default="LINEAR",
    )  # type: ignore[assignment]

    # ── Outline Rendering ──────────────────────────────────────────────
    # Inverted-hull outline via Solidify modifier on mesh ghosts.

    ghost_outline_enabled: bpy.props.BoolProperty(
        name="Ghost Outline",
        description="Add a solid outline (Solidify modifier) to mesh ghosts for silhouette clarity",
        default=False,
    )  # type: ignore[assignment]

    ghost_outline_width: bpy.props.FloatProperty(
        name="Outline Width",
        description="Thickness of the mesh ghost outline in scene units",
        default=0.002,
        min=0.0005,
        max=0.05,
        precision=4,
    )  # type: ignore[assignment]

    ghost_outline_color: bpy.props.FloatVectorProperty(
        name="Outline Color",
        description="Color of the mesh ghost outline edges",
        subtype='COLOR',
        size=3,
        default=(0.0, 0.0, 0.0),
        min=0.0,
        max=1.0,
    )  # type: ignore[assignment]

    # ── Ballistic Preview ──────────────────────────────────────────────
    # Physics-informed arc preview showing where ghosts would land
    # under gravity. Non-destructive overlay for motion planning.

    show_ballistic_preview: bpy.props.BoolProperty(
        name="Ballistic Preview",
        description="Show a physics-informed arc preview of where ghosts would land under gravity",
        default=False,
    )  # type: ignore[assignment]

    ballistic_offset: bpy.props.FloatVectorProperty(
        name="Ballistic Offset",
        description="Manual offset applied to ballistic preview positions (scene units)",
        size=3,
        default=(0.0, 0.0, 0.0),
    )  # type: ignore[assignment]

    ballistic_gravity: bpy.props.FloatProperty(
        name="Ballistic Gravity",
        description="Gravity strength for ballistic preview (m/s²)",
        default=9.81,
        min=0.0,
        max=100.0,
    )  # type: ignore[assignment]

    ballistic_gravity_axis: bpy.props.EnumProperty(
        name="Gravity Axis",
        description="Axis along which gravity acts for ballistic preview",
        items=[
            ("X", "X", "Gravity along -X"),
            ("Y", "Y", "Gravity along -Y"),
            ("Z", "Z", "Gravity along -Z"),
        ],
        default="Z",
    )  # type: ignore[assignment]

    show_arc_lines: bpy.props.BoolProperty(
        name="Show Arc Lines",
        description="Draw continuous trajectory lines through ghost positions across the timeline",
        default=True,
    )  # type: ignore[assignment]

    arc_line_style: bpy.props.EnumProperty(
        name="Arc Style",
        description="Visual style for the trajectory arc lines",
        items=[
            ("SOLID", "Solid", "Solid colored line"),
            ("SPEED", "Speed Colored", "Blue where slow, red where fast"),
            ("FADE", "Fade", "Line fades with distance from the cursor"),
        ],
        default="SPEED",
    )  # type: ignore[assignment]

    show_frame_numbers: bpy.props.BoolProperty(
        name="Show Frame Numbers",
        description="Display frame numbers next to each ghost marker",
        default=False,
    )  # type: ignore[assignment]

    # ── Live Generation ────────────────────────────────────────────────
    # Auto-regeneration settings that update ghosts whenever the
    # playhead moves. Throttling prevents CPU overload.

    live_point_ghosts: bpy.props.BoolProperty(
        name="Live Point Ghosts",
        description=(
            "Automatically regenerate point ghosts when the frame changes. "
            "Disable during heavy scenes for better performance"
        ),
        default=False,
    )  # type: ignore[assignment]

    live_mesh_ghosts: bpy.props.BoolProperty(
        name="Live Mesh Ghosts",
        description=(
            "Automatically update mesh onion skin when the frame changes. "
            "Uses incremental vertex update for speed — heavier than point ghosts"
        ),
        default=False,
    )  # type: ignore[assignment]

    live_throttle_ms: bpy.props.IntProperty(
        name="Throttle (ms)",
        description=(
            "Minimum milliseconds between live updates. "
            "Lower = more responsive but heavier on CPU. "
            "50ms ≈ 20 updates/sec, 100ms ≈ 10 updates/sec"
        ),
        default=50,
        min=16,
        max=500,
    )  # type: ignore[assignment]

    live_freeze: bpy.props.BoolProperty(
        name="Freeze",
        description=(
            "Temporarily pause all live ghost updates without disabling the feature. "
            "Useful during playback scrubbing or heavy scene operations"
        ),
        default=False,
    )  # type: ignore[assignment]

    def is_level_visible(self, level: int) -> bool:
        """Check whether a given subdivision level should be displayed.

        Args:
            level: The generation level to check (1–5).

        Returns:
            bool: True if that level's visibility toggle is on.
        """
        if level < 1 or level > MAX_SUBDIVISION_LEVEL:
            return False
        return getattr(self, f"show_level_{level}", True)


# ---------------------------------------------------------------------------
# Ghost generation — recursive subdivision of f-curves
# ---------------------------------------------------------------------------

def _get_fcurve_for_channel(
    action: bpy.types.Action,
    bone_name: str,
    channel: str,
    obj: Optional[bpy.types.Object] = None,
) -> Optional[bpy.types.FCurve]:
    """Locate the FCurve in an Action matching a bone and channel path.

    Compatible with both legacy (Blender < 4.4) and slotted (5.x+) Actions.

    Args:
        action: The Blender Action containing f-curves.
        bone_name: Pose bone name, or empty string for object channels.
        channel: Channel identifier like "location.x" or "rotation_euler.z".
        obj: The owning Blender object (needed for Blender 5.x slot resolution).

    Returns:
        FCurve or None: The matching f-curve, or None if not found.
    """
    from .utils import find_fcurve_in_action

    # Parse channel into data_path and array_index
    # e.g. "location.x" -> data_path="location", array_index=0
    axis_map = {"x": 0, "y": 1, "z": 2, "w": 3}

    parts = channel.rsplit(".", 1)
    if len(parts) == 2:
        prop_name = parts[0]
        axis = parts[1].lower()
        array_index = axis_map.get(axis, 0)
    else:
        prop_name = channel
        array_index = 0

    # Build the full data path
    if bone_name:
        data_path = f'pose.bones["{bone_name}"].{prop_name}'
    else:
        data_path = prop_name

    # Use the compatibility helper that handles both legacy and slotted APIs
    return find_fcurve_in_action(action, data_path, array_index, obj=obj)


def _get_keyframe_frames(fcurve: bpy.types.FCurve) -> list[float]:
    """Extract sorted frame numbers from an f-curve's keyframe points.

    Args:
        fcurve: The f-curve to inspect.

    Returns:
        list[float]: Sorted list of frame numbers where keyframes exist.
    """
    return sorted(kp.co.x for kp in fcurve.keyframe_points)


def _frame_has_keyframe(fcurve: bpy.types.FCurve, frame: float) -> bool:
    """Check whether a frame is within KEYFRAME_SNAP_THRESHOLD of an existing keyframe.

    Args:
        fcurve: The f-curve to check against.
        frame: The frame number to test.

    Returns:
        bool: True if a real keyframe exists within the threshold.
    """
    for kp in fcurve.keyframe_points:
        if abs(kp.co.x - frame) < KEYFRAME_SNAP_THRESHOLD:
            return True
    return False


def _get_world_position_cached(
    depsgraph: bpy.types.Depsgraph,
    scene: bpy.types.Scene,
    obj: bpy.types.Object,
    bone_name: str,
    frame: float,
    cache: dict[tuple[str, str, float], Vector],
) -> Vector:
    """Evaluate the world-space position of an object or bone at a given frame.

    Uses a cache keyed on (object_name, bone_name, frame) to avoid
    redundant scene.frame_set() calls, which are expensive.

    Args:
        depsgraph: The current dependency graph.
        scene: The active scene.
        obj: The Blender object.
        bone_name: Pose bone name, or empty string for object origin.
        frame: The frame to evaluate at.
        cache: Mutable dict used for caching results.

    Returns:
        Vector: The world-space position (copy).
    """
    cache_key = (obj.name, bone_name, frame)
    if cache_key in cache:
        return cache[cache_key].copy()

    # Set the frame and update the dependency graph
    scene.frame_set(int(frame), subframe=frame - int(frame))
    depsgraph.update()

    if bone_name and obj.type == 'ARMATURE':
        pose_bone = obj.pose.bones.get(bone_name)
        if pose_bone:
            # World-space position of the bone head
            world_pos = obj.matrix_world @ pose_bone.head.copy()
        else:
            from .utils import warn
            warn(f"Bone '{bone_name}' not found on '{obj.name}'")
            world_pos = obj.matrix_world.translation.copy()
    else:
        world_pos = obj.matrix_world.translation.copy()

    cache[cache_key] = world_pos.copy()
    return world_pos.copy()


def _find_surrounding_keyframes(
    keyframes: list[float],
    frame: float,
) -> tuple[float, float]:
    """Find the two keyframes that bracket a given frame.

    Scans the sorted keyframe list and returns the pair (left, right)
    where ``left <= frame < right``. If the frame is beyond all
    keyframes, both values default to the nearest endpoint.

    Args:
        keyframes: Sorted list of keyframe frame numbers.
        frame: The frame to locate within the keyframe list.

    Returns:
        tuple[float, float]: (left_keyframe, right_keyframe).
    """
    if not keyframes:
        return (0.0, 0.0)

    for index, keyframe_time in enumerate(keyframes):
        if keyframe_time > frame:
            left = keyframes[index - 1] if index > 0 else keyframe_time
            return (left, keyframe_time)

    # Frame is at or beyond the last keyframe.
    return (keyframes[-1], keyframes[-1])


def _subdivide_segment(
    fcurve: bpy.types.FCurve,
    frame_a: float,
    frame_b: float,
    level: int,
    max_level: int,
    obj: bpy.types.Object,
    bone_name: str,
    channel: str,
    scene: bpy.types.Scene,
    depsgraph: bpy.types.Depsgraph,
    cache: dict[tuple[str, str, float], Vector],
    results: list[Ghost],
) -> None:
    """Recursively generate ghosts between two parent frames.

    At each level, a midpoint ghost is created. If the current level is
    below max_level, the function recurses into the left and right
    sub-segments created by the new midpoint.

    Args:
        fcurve: The f-curve being subdivided.
        frame_a: Left parent frame number.
        frame_b: Right parent frame number.
        level: Current subdivision depth (starts at 1).
        max_level: Maximum subdivision depth to reach.
        obj: The Blender object owning this channel.
        bone_name: Pose bone name or empty string.
        channel: Channel identifier (e.g. "location.x").
        scene: The active scene (for frame_set).
        depsgraph: The dependency graph (for evaluation).
        cache: Position cache dict to reuse across calls.
        results: Accumulator list for generated Ghost objects.
    """
    if level > max_level:
        return

    mid_frame = (frame_a + frame_b) / 2.0

    # Skip if a real keyframe already exists at or near this frame
    if _frame_has_keyframe(fcurve, mid_frame):
        return

    # Sample the f-curve value at the midpoint
    local_value = fcurve.evaluate(mid_frame)

    # Get world position for viewport display
    world_pos = _get_world_position_cached(
        depsgraph, scene, obj, bone_name, mid_frame, cache
    )

    ghost = Ghost(
        frame=mid_frame,
        world_position=world_pos,
        local_value=local_value,
        channel=channel,
        bone_name=bone_name,
        object_name=obj.name,
        parent_frame_a=frame_a,
        parent_frame_b=frame_b,
        generation_level=level,
    )
    results.append(ghost)

    # Recurse into sub-segments for deeper subdivision levels
    if level < max_level:
        _subdivide_segment(
            fcurve, frame_a, mid_frame, level + 1, max_level,
            obj, bone_name, channel, scene, depsgraph, cache, results,
        )
        _subdivide_segment(
            fcurve, mid_frame, frame_b, level + 1, max_level,
            obj, bone_name, channel, scene, depsgraph, cache, results,
        )


def generate_ghosts(
    obj: bpy.types.Object,
    armature: Optional[bpy.types.Object],
    bones: list[str],
    channels: list[str],
    level: int,
    frame_range: Optional[tuple[int, int]] = None,
) -> list[Ghost]:
    """Generate ghosts for the specified object, bones, and channels.

    This is the main entry point for ghost generation.  It iterates over
    each requested channel, finds adjacent keyframe pairs, and recursively
    subdivides each segment up to the requested level.

    Args:
        obj: The Blender object whose f-curves to sample.  For armatures,
             this should be the armature object itself.
        armature: The armature object (same as obj for armature channels,
                  None for plain object channels).  Kept as a separate
                  param for clarity in multi-object workflows.
        bones: List of pose bone names to generate ghosts for.  Pass an
               empty list for object-level channels.
        channels: List of channel identifiers to process, e.g.
                  ["location.x", "location.y", "location.z"].
        level: Maximum subdivision depth (1–5).
        frame_range: Optional (start, end) frame range.  If None, the
                     full f-curve range is used.

    Returns:
        list[Ghost]: All generated Ghost objects across all bones/channels.
    """
    level = max(1, min(level, MAX_SUBDIVISION_LEVEL))

    # Determine which object holds the action
    target_obj = armature if armature else obj
    if not target_obj:
        from .utils import warn
        warn("No valid object provided for ghost generation.")
        return []

    action = None
    if target_obj.animation_data:
        action = target_obj.animation_data.action

    if not action:
        from .utils import warn
        warn(f"No action found on '{target_obj.name}'.")
        return []

    scene = bpy.context.scene
    depsgraph = bpy.context.evaluated_depsgraph_get()

    # Save the current frame so we can restore it after sampling
    original_frame = scene.frame_current

    # Position cache to minimize redundant frame_set calls
    position_cache: dict[tuple[str, str, float], Vector] = {}

    all_ghosts: list[Ghost] = []

    # If no bones specified, process as object-level channels
    bone_list = bones if bones else [""]

    for bone_name in bone_list:
        for channel in channels:
            fcurve = _get_fcurve_for_channel(action, bone_name, channel, obj=target_obj)
            if fcurve is None:
                # No f-curve for this bone/channel combo — skip silently
                continue

            keyframes = _get_keyframe_frames(fcurve)
            if len(keyframes) < 2:
                # Need at least two keyframes to create midpoints
                continue

            # Apply frame range filter if specified
            for i in range(len(keyframes) - 1):
                frame_a = keyframes[i]
                frame_b = keyframes[i + 1]

                # Skip segments entirely outside the requested range
                if frame_range:
                    if frame_b < frame_range[0] or frame_a > frame_range[1]:
                        continue

                _subdivide_segment(
                    fcurve=fcurve,
                    frame_a=frame_a,
                    frame_b=frame_b,
                    level=1,
                    max_level=level,
                    obj=target_obj,
                    bone_name=bone_name,
                    channel=channel,
                    scene=scene,
                    depsgraph=depsgraph,
                    cache=position_cache,
                    results=all_ghosts,
                )

    # Restore the original frame to avoid disrupting the user's timeline position
    scene.frame_set(original_frame)

    return all_ghosts


def generate_ghosts_frame_step(
    obj: bpy.types.Object,
    armature: Optional[bpy.types.Object],
    bones: list[str],
    channels: list[str],
    frame_list: list[float],
) -> list[Ghost]:
    """Generate ghosts at explicit frame positions (frame-by-frame mode).

    Unlike subdivision mode, this creates a ghost at every specified frame
    regardless of where keyframes are.  This is the Cascadeur-style
    "every Nth frame" mode.

    Args:
        obj: The Blender object.
        armature: The armature object (or None).
        bones: List of pose bone names.
        channels: List of channel identifiers.
        frame_list: Explicit list of frame numbers to generate ghosts at.

    Returns:
        list[Ghost]: All generated ghosts.
    """
    target_obj = armature if armature else obj
    if not target_obj:
        return []

    action = None
    if target_obj.animation_data:
        action = target_obj.animation_data.action
    if not action:
        return []

    scene = bpy.context.scene
    depsgraph = bpy.context.evaluated_depsgraph_get()
    original_frame = scene.frame_current
    position_cache: dict[tuple[str, str, float], Vector] = {}
    all_ghosts: list[Ghost] = []

    bone_list = bones if bones else [""]

    for bone_name in bone_list:
        for channel in channels:
            fcurve = _get_fcurve_for_channel(action, bone_name, channel, obj=target_obj)
            if fcurve is None:
                continue

            keyframes = _get_keyframe_frames(fcurve)

            for frame in frame_list:
                # Skip if this frame IS a keyframe (we only want in-betweens)
                if _frame_has_keyframe(fcurve, frame):
                    continue

                local_value = fcurve.evaluate(frame)
                world_pos = _get_world_position_cached(
                    depsgraph, scene, target_obj, bone_name, frame, position_cache
                )

                # Determine which two keyframes this frame sits between.
                parent_a, parent_b = _find_surrounding_keyframes(keyframes, frame)

                ghost = Ghost(
                    frame=frame,
                    world_position=world_pos,
                    local_value=local_value,
                    channel=channel,
                    bone_name=bone_name,
                    object_name=target_obj.name,
                    parent_frame_a=parent_a,
                    parent_frame_b=parent_b,
                    generation_level=1,
                )
                all_ghosts.append(ghost)

    scene.frame_set(original_frame)
    return all_ghosts


def generate_ghosts_at_keyframes(
    obj: bpy.types.Object,
    armature: Optional[bpy.types.Object],
    bones: list[str],
    channels: list[str],
    frame_range: Optional[tuple[int, int]] = None,
) -> list[Ghost]:
    """Generate ghosts at keyframe positions only.

    Useful for seeing poses at key positions without in-betweens.

    Args:
        obj: The Blender object.
        armature: The armature object (or None).
        bones: Pose bone names.
        channels: Channel identifiers.
        frame_range: Optional frame range.

    Returns:
        list[Ghost]: Ghosts at keyframe positions.
    """
    target_obj = armature if armature else obj
    if not target_obj:
        return []

    action = None
    if target_obj.animation_data:
        action = target_obj.animation_data.action
    if not action:
        return []

    scene = bpy.context.scene
    depsgraph = bpy.context.evaluated_depsgraph_get()
    original_frame = scene.frame_current
    position_cache: dict[tuple[str, str, float], Vector] = {}
    all_ghosts: list[Ghost] = []

    bone_list = bones if bones else [""]

    for bone_name in bone_list:
        for channel in channels:
            fcurve = _get_fcurve_for_channel(action, bone_name, channel, obj=target_obj)
            if fcurve is None:
                continue

            keyframes = _get_keyframe_frames(fcurve)

            for frame in keyframes:
                if frame_range and (frame < frame_range[0] or frame > frame_range[1]):
                    continue

                local_value = fcurve.evaluate(frame)
                world_pos = _get_world_position_cached(
                    depsgraph, scene, target_obj, bone_name, frame, position_cache
                )

                ghost = Ghost(
                    frame=frame,
                    world_position=world_pos,
                    local_value=local_value,
                    channel=channel,
                    bone_name=bone_name,
                    object_name=target_obj.name,
                    parent_frame_a=frame,
                    parent_frame_b=frame,
                    generation_level=0,  # 0 = keyframe ghost
                )
                all_ghosts.append(ghost)

    scene.frame_set(original_frame)
    return all_ghosts


def build_frame_list_from_settings(
    settings,
    scene: bpy.types.Scene,
) -> list[float]:
    """Build the list of frames to ghost based on current settings.

    This centralises the frame-list logic for FRAME_STEP mode.

    Args:
        settings: GhostToolSceneSettings.
        scene: The Blender scene.

    Returns:
        list[float]: Frames to generate ghosts at.
    """
    current = scene.frame_current
    step = max(1, settings.frame_step)
    range_mode = settings.ghost_range_mode

    if range_mode == "AROUND_CURSOR":
        frames = []
        for i in range(1, settings.ghosts_before + 1):
            frames.append(current - i * step)
        for i in range(1, settings.ghosts_after + 1):
            frames.append(current + i * step)
        # Clamp to scene range
        start = scene.frame_start
        end = scene.frame_end
        frames = [f for f in frames if start <= f <= end]
        return sorted(frames)

    elif range_mode == "FULL_TIMELINE":
        start = scene.frame_start
        end = scene.frame_end
        frames = []
        f = start
        while f <= end:
            if f != current:  # skip current frame
                frames.append(float(f))
            f += step
        return frames

    elif range_mode == "BETWEEN_KEYS":
        # Will be handled by the subdivision generator
        return []

    elif range_mode == "CUSTOM":
        start = settings.custom_range_start
        end = settings.custom_range_end
        frames = []
        f = start
        while f <= end:
            if f != current:
                frames.append(float(f))
            f += step
        return frames

    return []


def generate_and_store_ghosts(
    context: bpy.types.Context,
    obj: bpy.types.Object,
    armature: Optional[bpy.types.Object],
    bones: list[str],
    channels: list[str],
    level: int,
    frame_range: Optional[tuple[int, int]] = None,
    clear_existing: bool = True,
) -> int:
    """Generate ghosts and add them to the scene's GhostStore.

    Reads ghost_mode from scene settings to choose between subdivision,
    frame-step, or keyframes-only generation.

    Args:
        context: The current Blender context.
        obj: The Blender object to generate ghosts for.
        armature: The armature object (or None).
        bones: List of pose bone names.
        channels: List of channel identifiers.
        level: Maximum subdivision depth (for SUBDIVISION mode).
        frame_range: Optional frame range constraint.
        clear_existing: If True, clear the store before adding new ghosts.

    Returns:
        int: Number of ghosts generated.
    """
    store = GhostStore.get(context.scene)

    if clear_existing:
        store.clear()

    settings = context.scene.ghost_tool
    mode = getattr(settings, 'ghost_mode', 'SUBDIVISION')

    if mode == "FRAME_STEP":
        frame_list = build_frame_list_from_settings(settings, context.scene)
        ghosts = generate_ghosts_frame_step(obj, armature, bones, channels, frame_list)
    elif mode == "KEYFRAMES_ONLY":
        ghosts = generate_ghosts_at_keyframes(obj, armature, bones, channels, frame_range)
    else:
        # SUBDIVISION — original mode
        ghosts = generate_ghosts(obj, armature, bones, channels, level, frame_range)

    for ghost in ghosts:
        store.add(ghost)

    return len(ghosts)


# ---------------------------------------------------------------------------
# Default channel lists for common animation workflows
# ---------------------------------------------------------------------------

LOCATION_CHANNELS: list[str] = ["location.x", "location.y", "location.z"]
ROTATION_EULER_CHANNELS: list[str] = [
    "rotation_euler.x", "rotation_euler.y", "rotation_euler.z"
]
ROTATION_QUAT_CHANNELS: list[str] = [
    "rotation_quaternion.w", "rotation_quaternion.x",
    "rotation_quaternion.y", "rotation_quaternion.z",
]
SCALE_CHANNELS: list[str] = ["scale.x", "scale.y", "scale.z"]
ALL_TRANSFORM_CHANNELS: list[str] = (
    LOCATION_CHANNELS + ROTATION_EULER_CHANNELS + SCALE_CHANNELS
)


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

CLASSES: tuple[type, ...] = (
    GhostToolSceneSettings,
)


def register() -> None:
    """Register ghost_data module classes and attach scene properties."""
    for cls in CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.ghost_tool = bpy.props.PointerProperty(
        type=GhostToolSceneSettings,
        name="Ghost Tool Settings",
        description="Scene-level settings for the Ghost Tool addon",
    )


def unregister() -> None:
    """Unregister ghost_data module classes and clean up scene properties."""
    # Clean up the in-memory store
    GhostStore.clear_all_instances()

    if hasattr(bpy.types.Scene, "ghost_tool"):
        del bpy.types.Scene.ghost_tool

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


# ---------------------------------------------------------------------------
# Test notes (for manual verification in Blender's Python console)
# ---------------------------------------------------------------------------
#
# >>> from ghost_tool.ghost_data import Ghost, GhostStore, generate_ghosts
#
# Test 1: Ghost creation and serialization
# >>> g = Ghost(frame=5.0, channel="location.x", object_name="Cube")
# >>> d = g.to_dict()
# >>> g2 = Ghost.from_dict(d)
# >>> assert g.frame == g2.frame and g.uid == g2.uid
#
# Test 2: GhostStore CRUD
# >>> store = GhostStore.get(bpy.context.scene)
# >>> store.clear()
# >>> store.add(Ghost(frame=1.0, generation_level=1))
# >>> store.add(Ghost(frame=2.0, generation_level=2))
# >>> assert len(store) == 2
# >>> assert len(store.filter_by_level(1)) == 1
# >>> store.clear_level(2)
# >>> assert len(store) == 1
#
# Test 3: Ghost generation on a cube with 3 keyframes at frames 1, 25, 50
# >>> obj = bpy.context.active_object  # must be a Cube with an action
# >>> ghosts = generate_ghosts(obj, None, [], ["location.x"], level=2)
# >>> print(f"Generated {len(ghosts)} ghosts")
# >>> # Level 1: 2 ghosts (midpoints of [1,25] and [25,50])
# >>> # Level 2: 4 more ghosts (midpoints of those sub-segments)
# >>> # Total: 6 ghosts
