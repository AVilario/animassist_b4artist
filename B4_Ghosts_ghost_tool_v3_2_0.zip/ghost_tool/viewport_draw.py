"""
viewport_draw.py — GPU draw handlers for ghost visualization in the 3D viewport.

This module registers persistent draw handlers that render:
- Ghost spheres at interpolated positions (color-coded by generation level)
- Motion arcs connecting ghosts and keyframes in sequence
- Spacing tick marks showing frame density along the arc
- Snapshot overlay ghosts in a desaturated style

All drawing uses Blender's gpu module with batched draw calls for performance.
Draw handlers are registered/unregistered cleanly to prevent crashes.
"""

from __future__ import annotations

import math
from typing import Optional

import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from .ghost_data import GhostStore, Ghost
from .utils import log, warn, debug


# ---------------------------------------------------------------------------
# Module-level draw handler references (must be stored for unregistration)
# ---------------------------------------------------------------------------

_draw_handler_3d: Optional[object] = None
_draw_handler_2d: Optional[object] = None


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Default colors per generation level (RGBA)
DEFAULT_LEVEL_COLORS: list[tuple[float, float, float, float]] = [
    (0.2, 0.7, 1.0, 0.85),   # Level 1: bright blue
    (0.3, 1.0, 0.5, 0.80),   # Level 2: green
    (1.0, 0.8, 0.2, 0.75),   # Level 3: gold
    (1.0, 0.4, 0.2, 0.70),   # Level 4: orange
    (0.9, 0.2, 0.8, 0.65),   # Level 5: magenta
]

KEYFRAME_MARKER_COLOR: tuple[float, float, float, float] = (1.0, 1.0, 1.0, 0.95)
SELECTED_HIGHLIGHT_COLOR: tuple[float, float, float, float] = (1.0, 1.0, 0.0, 1.0)
PINNED_RING_COLOR: tuple[float, float, float, float] = (1.0, 0.3, 0.3, 0.9)
ARC_COLOR: tuple[float, float, float, float] = (0.5, 0.5, 0.5, 0.6)

SPHERE_SEGMENTS: int = 16
"""Number of line segments used to approximate a circle for ghost markers."""

CIRCLE_SEGMENTS: int = 16
"""Number of segments for billboard circles."""

PINNED_RING_SEGMENTS: int = 8
"""Number of segments for pinned ghost ring markers."""

SELECTED_RING_SCALE: float = 1.4
"""Radius multiplier for selected ghost highlight ring."""

PINNED_RING_SCALE: float = 1.2
"""Radius multiplier for pinned ghost indicator ring."""

DEFAULT_GHOST_RADIUS: float = 0.05
"""Default world-space radius for ghost markers."""

DEFAULT_ARC_WIDTH: float = 2.0
"""Default line width for the motion arc."""


# ---------------------------------------------------------------------------
# Geometry generation helpers
# ---------------------------------------------------------------------------

def _generate_circle_verts(
    center: Vector,
    radius: float,
    segments: int = SPHERE_SEGMENTS,
) -> list[Vector]:
    """Generate vertices for a screen-facing circle (billboard).

    The circle is generated in the XY plane at the given center.
    For viewport rendering, these will be transformed by the view matrix.

    Args:
        center: Center point of the circle in world space.
        radius: Radius of the circle.
        segments: Number of segments for the polygon approximation.

    Returns:
        list[Vector]: Ordered vertices forming the circle outline.
    """
    verts = []
    for i in range(segments):
        angle = 2.0 * math.pi * i / segments
        x = center.x + radius * math.cos(angle)
        y = center.y + radius * math.sin(angle)
        z = center.z
        verts.append(Vector((x, y, z)))
    return verts


def _build_circle_line_indices(segments: int) -> list[tuple[int, int]]:
    """Build edge indices for a circle outline.

    Args:
        segments: Number of segments in the circle.

    Returns:
        list[tuple[int, int]]: Pairs of vertex indices forming line segments.
    """
    indices = []
    for i in range(segments):
        indices.append((i, (i + 1) % segments))
    return indices


def _build_3d_circle_verts(
    center: Vector,
    radius: float,
    view_matrix,
    segments: int = SPHERE_SEGMENTS,
) -> list[Vector]:
    """Generate a view-facing (billboard) circle in 3D space.

    The circle is oriented perpendicular to the view direction so it
    always faces the camera, like a billboard.

    Args:
        center: World-space center of the circle.
        radius: Radius in world-space units.
        view_matrix: The region's view matrix (rv3d.view_matrix).
        segments: Number of segments.

    Returns:
        list[Vector]: World-space vertices for the circle outline.
    """
    # Extract the right and up vectors from the view matrix
    # The view matrix's inverse gives us camera orientation in world space
    inv_view = view_matrix.inverted()
    right = Vector((inv_view[0][0], inv_view[0][1], inv_view[0][2])).normalized()
    up = Vector((inv_view[1][0], inv_view[1][1], inv_view[1][2])).normalized()

    verts = []
    for i in range(segments):
        angle = 2.0 * math.pi * i / segments
        offset = right * (radius * math.cos(angle)) + up * (radius * math.sin(angle))
        verts.append(center + offset)
    return verts


# ---------------------------------------------------------------------------
# Color utilities
# ---------------------------------------------------------------------------

def _get_level_color(level: int) -> tuple[float, float, float, float]:
    """Get the display color for a ghost generation level.

    Reads from addon preferences if available, otherwise uses defaults.

    Args:
        level: Generation level (1-based).

    Returns:
        tuple: RGBA color.
    """
    # Try to read from addon preferences
    try:
        prefs = bpy.context.preferences.addons.get("ghost_tool")
        if prefs and hasattr(prefs.preferences, f"level_{level}_color"):
            color = getattr(prefs.preferences, f"level_{level}_color")
            return (color[0], color[1], color[2], 0.85)
    except Exception as exc:
        warn(f"Error getting level color: {exc}")

    # Fall back to defaults
    idx = max(0, min(level - 1, len(DEFAULT_LEVEL_COLORS) - 1))
    return DEFAULT_LEVEL_COLORS[idx]


def _desaturate_color(
    color: tuple[float, float, float, float],
    factor: float = 0.5,
) -> tuple[float, float, float, float]:
    """Desaturate an RGBA color for snapshot overlay display.

    Args:
        color: Input RGBA color.
        factor: Desaturation amount (0 = no change, 1 = full grayscale).

    Returns:
        tuple: Desaturated RGBA color.
    """
    gray = 0.299 * color[0] + 0.587 * color[1] + 0.114 * color[2]
    r = color[0] + (gray - color[0]) * factor
    g = color[1] + (gray - color[1]) * factor
    b = color[2] + (gray - color[2]) * factor
    return (r, g, b, color[3] * 0.5)


def _lerp_color_hsv(
    slow_speed_color: tuple[float, float, float, float],
    fast_speed_color: tuple[float, float, float, float],
    t: float,
) -> tuple[float, float, float, float]:
    """Linearly interpolate between two RGBA colors.

    Args:
        slow_speed_color: Color for slow motion (dense spacing).
        fast_speed_color: Color for fast motion (sparse spacing).
        t: Interpolation factor (0.0 = slow_speed_color, 1.0 = fast_speed_color).

    Returns:
        tuple: Interpolated RGBA color.
    """
    t = max(0.0, min(1.0, t))
    return (
        slow_speed_color[0] + (fast_speed_color[0] - slow_speed_color[0]) * t,
        slow_speed_color[1] + (fast_speed_color[1] - slow_speed_color[1]) * t,
        slow_speed_color[2] + (fast_speed_color[2] - slow_speed_color[2]) * t,
        slow_speed_color[3] + (fast_speed_color[3] - slow_speed_color[3]) * t,
    )


# ---------------------------------------------------------------------------
# GPU Drawing Helpers
# ---------------------------------------------------------------------------

def _draw_batch(shader, batch, color):
    """Bind shader, set color uniform, and draw the batch.

    Args:
        shader: GPU shader instance.
        batch: GPU batch to draw.
        color: RGBA color tuple (r, g, b, a) each in 0–1 range.
    """
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)


# ---------------------------------------------------------------------------
# Main 3D Draw Handler
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Cascadeur-style ghost coloring helpers
# ---------------------------------------------------------------------------

# Time-based colors: past = blue, future = orange (like Cascadeur)
# These are fallback defaults; user-configurable colors are in scene settings.
PAST_GHOST_COLOR: tuple[float, float, float, float] = (0.25, 0.55, 1.0, 0.85)
FUTURE_GHOST_COLOR: tuple[float, float, float, float] = (1.0, 0.55, 0.15, 0.85)
CURRENT_GHOST_COLOR: tuple[float, float, float, float] = (0.2, 1.0, 0.4, 0.95)

# Key/Inbetween default colors (overridden by scene settings)
KEY_GHOST_COLOR: tuple[float, float, float, float] = (1.0, 0.85, 0.0, 0.90)
INBETWEEN_GHOST_COLOR: tuple[float, float, float, float] = (0.4, 0.75, 1.0, 0.80)

# Ballistic preview colors
BALLISTIC_ARC_COLOR: tuple[float, float, float, float] = (0.8, 0.3, 1.0, 0.5)
BALLISTIC_MARKER_COLOR: tuple[float, float, float, float] = (0.8, 0.3, 1.0, 0.35)

# Rainbow palette (12 stops) for rainbow color mode
RAINBOW_PALETTE: list[tuple[float, float, float, float]] = [
    (1.0, 0.0, 0.0, 0.85),    # Red
    (1.0, 0.5, 0.0, 0.85),    # Orange
    (1.0, 1.0, 0.0, 0.85),    # Yellow
    (0.5, 1.0, 0.0, 0.85),    # Lime
    (0.0, 1.0, 0.0, 0.85),    # Green
    (0.0, 1.0, 0.5, 0.85),    # Spring
    (0.0, 1.0, 1.0, 0.85),    # Cyan
    (0.0, 0.5, 1.0, 0.85),    # Azure
    (0.0, 0.0, 1.0, 0.85),    # Blue
    (0.5, 0.0, 1.0, 0.85),    # Violet
    (1.0, 0.0, 1.0, 0.85),    # Magenta
    (1.0, 0.0, 0.5, 0.85),    # Rose
]


def _apply_falloff(t: float, curve_type: str) -> float:
    """Apply a falloff curve to a normalised distance value.

    Args:
        t: Normalised distance (0 = at cursor, 1 = farthest).
        curve_type: One of "LINEAR", "SMOOTH", "EXPONENTIAL", "CONSTANT".
                    CONSTANT returns 0.0 (no distance-based fade applied).

    Returns:
        float: Adjusted distance factor (0–1), where 0 = no fade (ghosts full opacity),
               1 = maximum fade (ghosts fully transparent).
    """
    t = max(0.0, min(t, 1.0))
    if curve_type == "CONSTANT":
        return 0.0
    elif curve_type == "SMOOTH":
        # Smooth-step: 3t² - 2t³
        return t * t * (3.0 - 2.0 * t)
    elif curve_type == "EXPONENTIAL":
        # Quick initial fade, slow tail
        return 1.0 - math.pow(1.0 - t, 3.0)
    else:
        # LINEAR (default)
        return t


def _get_ghost_color_cascadeur(
    ghost: Ghost,
    current_frame: float,
    frame_range: tuple[float, float],
    color_mode: str,
    fade_factor: float,
    settings=None,
) -> tuple[float, float, float, float]:
    """Compute the color for a ghost based on Cascadeur-style coloring modes.

    Args:
        ghost: The ghost to color.
        current_frame: The scene's current frame.
        frame_range: (min_frame, max_frame) of all ghosts for normalizing.
        color_mode: One of "LEVEL", "TIME", "FADE", "RAINBOW", "KEY_INBETWEEN".
        fade_factor: How aggressively alpha fades with distance (0-1).
        settings: Optional GhostToolSceneSettings for user colors and falloff.

    Returns:
        RGBA color tuple.
    """
    if color_mode == "LEVEL":
        return _get_level_color(ghost.generation_level)

    # Read user-configurable values from settings, with safe fallbacks
    min_alpha = getattr(settings, 'ghost_min_alpha', 0.15) if settings else 0.15
    falloff_curve = getattr(settings, 'ghost_falloff_curve', 'LINEAR') if settings else 'LINEAR'

    delta = ghost.frame - current_frame
    range_width = max(frame_range[1] - frame_range[0], 1.0)
    normalized_distance = min(abs(delta) / range_width, 1.0)  # 0 = at cursor, 1 = farthest
    falloff_distance = _apply_falloff(normalized_distance, falloff_curve)

    if color_mode == "TIME":
        # User-configurable past/future colors
        if settings:
            past_rgb = tuple(getattr(settings, 'ghost_past_color', (0.25, 0.55, 1.0)))
            future_rgb = tuple(getattr(settings, 'ghost_future_color', (1.0, 0.55, 0.15)))
            base = (*past_rgb, 0.85) if delta < 0 else (*future_rgb, 0.85)
        else:
            base = PAST_GHOST_COLOR if delta < 0 else FUTURE_GHOST_COLOR
        alpha = base[3] * (1.0 - falloff_distance * fade_factor)
        return (base[0], base[1], base[2], max(alpha, min_alpha))

    elif color_mode == "FADE":
        # White/bright near cursor, fading to dim with distance
        brightness = 1.0 - falloff_distance * fade_factor * 0.7
        alpha = 0.9 * (1.0 - falloff_distance * fade_factor)
        return (brightness, brightness, brightness, max(alpha, min_alpha))

    elif color_mode == "RAINBOW":
        # Position on rainbow based on normalized time position
        t_norm = (ghost.frame - frame_range[0]) / range_width
        idx_f = t_norm * (len(RAINBOW_PALETTE) - 1)
        idx = int(idx_f)
        frac = idx_f - idx
        idx = max(0, min(idx, len(RAINBOW_PALETTE) - 2))
        c1 = RAINBOW_PALETTE[idx]
        c2 = RAINBOW_PALETTE[idx + 1]
        r = c1[0] + (c2[0] - c1[0]) * frac
        g = c1[1] + (c2[1] - c1[1]) * frac
        b = c1[2] + (c2[2] - c1[2]) * frac
        alpha = 0.85 * (1.0 - falloff_distance * fade_factor * 0.3)
        return (r, g, b, max(alpha, min_alpha))

    elif color_mode == "KEY_INBETWEEN":
        # Keyframe ghosts (level 0) get key_color, all others get inbetween_color
        is_key = (ghost.generation_level == 0)
        if settings:
            if is_key:
                rgb = tuple(getattr(settings, 'ghost_key_color', (1.0, 0.85, 0.0)))
            else:
                rgb = tuple(getattr(settings, 'ghost_inbetween_color', (0.4, 0.75, 1.0)))
        else:
            rgb = KEY_GHOST_COLOR[:3] if is_key else INBETWEEN_GHOST_COLOR[:3]
        base_alpha = 0.90 if is_key else 0.80
        alpha = base_alpha * (1.0 - falloff_distance * fade_factor)
        return (rgb[0], rgb[1], rgb[2], max(alpha, min_alpha))

    # Fallback
    return _get_level_color(ghost.generation_level)


def draw_ghosts_3d(context: bpy.types.Context) -> None:
    """Main 3D viewport draw callback for all ghost visualization.

    Supports multiple coloring modes (level, time, fade, rainbow),
    proximity-based alpha falloff, full-timeline arc lines, and
    speed-colored trajectory trails — Cascadeur style.

    When live mode is enabled, this function also triggers the pipeline
    to regenerate ghosts before drawing (throttled to avoid perf issues).

    Args:
        context: The current Blender context.
    """
    scene = context.scene

    # Check if ghost display is active
    if not hasattr(scene, 'ghost_tool') or not scene.ghost_tool.is_active:
        return

    settings = scene.ghost_tool

    # ── Live update hook ──
    # If any live mode is enabled, check if the pipeline needs to
    # regenerate before we draw.  This is the main entry point for live mode.
    live_points = getattr(settings, 'live_point_ghosts', False)
    live_mesh = getattr(settings, 'live_mesh_ghosts', False)
    if live_points or live_mesh:
        try:
            from .ghost_pipeline import GhostPipeline
            pipeline = GhostPipeline.get(scene)
            pipeline.update_if_needed(context)
        except Exception as exc:
            # Pipeline not available — degrade gracefully to manual mode
            debug(f"Error in ghost pipeline update: {exc}")

    store = GhostStore.get(scene)

    if len(store) == 0:
        return

    # We need the 3D region's view data for billboard calculations
    region = context.region
    rv3d = context.region_data
    if not rv3d:
        return

    # Get the shader for 3D uniform color drawing
    try:
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    except Exception as exc:
        try:
            shader = gpu.shader.from_builtin('3D_UNIFORM_COLOR')
        except Exception as exc2:
            debug(f"Failed to load shader: {exc2}")
            return

    gpu.state.blend_set('ALPHA')
    gpu.state.depth_test_set('LESS_EQUAL')
    gpu.state.line_width_set(2.0)

    ghost_radius = DEFAULT_GHOST_RADIUS
    try:
        prefs = bpy.context.preferences.addons.get("ghost_tool")
        if prefs and hasattr(prefs.preferences, "ghost_radius"):
            ghost_radius = prefs.preferences.ghost_radius
    except Exception as exc:
        debug(f"Failed to read ghost radius preference: {exc}")

    view_matrix = rv3d.view_matrix
    current_frame = scene.frame_current
    color_mode = getattr(settings, 'ghost_color_mode', 'LEVEL')
    fade_factor = getattr(settings, 'ghost_fade_factor', 0.7)

    # Compute frame range across all ghosts for normalizing
    all_ghost_list = list(store)
    if all_ghost_list:
        all_frames = [g.frame for g in all_ghost_list]
        frame_range = (min(all_frames), max(all_frames))
    else:
        frame_range = (0.0, 1.0)

    # --- Draw ghost markers ---
    # For LEVEL mode, batch by level. For other modes, draw per-ghost for individual colors.
    if color_mode == "LEVEL":
        # Original level-based batching
        for level in range(0, 7):  # 0 = keyframe ghosts, 1-5 = subdivision
            if level > 0 and not settings.is_level_visible(level):
                continue

            ghosts_at_level = store.filter_by_level(level) if level > 0 else [
                g for g in all_ghost_list if g.generation_level == 0
            ]
            if not ghosts_at_level:
                continue

            color = _get_level_color(max(level, 1))

            all_verts: list[Vector] = []
            all_indices: list[tuple[int, int]] = []

            for ghost in ghosts_at_level:
                offset = len(all_verts)
                circle_verts = _build_3d_circle_verts(
                    ghost.world_position, ghost_radius, view_matrix
                )
                all_verts.extend(circle_verts)
                for i in range(SPHERE_SEGMENTS):
                    all_indices.append((offset + i, offset + (i + 1) % SPHERE_SEGMENTS))

            if all_verts:
                batch = batch_for_shader(
                    shader, 'LINES',
                    {"pos": [tuple(v) for v in all_verts]},
                    indices=all_indices,
                )
                _draw_batch(shader, batch, color)

    else:
        # Per-ghost coloring (TIME, FADE, RAINBOW, KEY_INBETWEEN) — each ghost gets its own color
        for ghost in all_ghost_list:
            color = _get_ghost_color_cascadeur(
                ghost, current_frame, frame_range, color_mode, fade_factor,
                settings=settings,
            )

            # Adjust radius: ghosts closer to cursor are slightly larger
            range_width = max(frame_range[1] - frame_range[0], 1.0)
            t_abs = min(abs(ghost.frame - current_frame) / range_width, 1.0)
            radius = ghost_radius * (1.0 + 0.5 * (1.0 - t_abs))

            circle_verts = _build_3d_circle_verts(
                ghost.world_position, radius, view_matrix
            )
            indices = [(i, (i + 1) % SPHERE_SEGMENTS) for i in range(SPHERE_SEGMENTS)]

            batch = batch_for_shader(
                shader, 'LINES',
                {"pos": [tuple(v) for v in circle_verts]},
                indices=indices,
            )
            _draw_batch(shader, batch, color)

    # --- Draw selected ghost highlights ---
    selected_ghosts = store.get_selected()
    if selected_ghosts:
        all_verts = []
        all_indices = []
        for ghost in selected_ghosts:
            offset = len(all_verts)
            circle_verts = _build_3d_circle_verts(
                ghost.world_position, ghost_radius * SELECTED_RING_SCALE, view_matrix
            )
            all_verts.extend(circle_verts)
            for i in range(SPHERE_SEGMENTS):
                all_indices.append((offset + i, offset + (i + 1) % SPHERE_SEGMENTS))

        if all_verts:
            batch = batch_for_shader(
                shader, 'LINES',
                {"pos": [tuple(v) for v in all_verts]},
                indices=all_indices,
            )
            _draw_batch(shader, batch, SELECTED_HIGHLIGHT_COLOR)

    # --- Draw pinned ghost indicators ---
    pinned_ghosts = store.get_pinned()
    if pinned_ghosts:
        all_verts = []
        all_indices = []
        for ghost in pinned_ghosts:
            offset = len(all_verts)
            circle_verts = _build_3d_circle_verts(
                ghost.world_position, ghost_radius * PINNED_RING_SCALE, view_matrix,
                segments=PINNED_RING_SEGMENTS,
            )
            all_verts.extend(circle_verts)
            for i in range(PINNED_RING_SEGMENTS):
                all_indices.append((offset + i, offset + (i + 1) % PINNED_RING_SEGMENTS))

        if all_verts:
            batch = batch_for_shader(
                shader, 'LINES',
                {"pos": [tuple(v) for v in all_verts]},
                indices=all_indices,
            )
            _draw_batch(shader, batch, PINNED_RING_COLOR)

    # --- Draw arc lines (Cascadeur-style trajectory trails) ---
    show_arcs = getattr(settings, 'show_arc_lines', False) or settings.show_motion_arc
    if show_arcs:
        arc_style = getattr(settings, 'arc_line_style', 'SOLID')
        _draw_arc_lines_cascadeur(
            store, shader, settings, current_frame, frame_range, arc_style, fade_factor
        )

    # --- Draw spacing ticks ---
    if settings.show_spacing_ticks:
        _draw_spacing_ticks_impl(store, shader, view_matrix, settings)

    # --- Draw snapshot overlays ---
    _draw_snapshot_overlays(context, shader, view_matrix, ghost_radius)

    # --- Draw ballistic preview ---
    if getattr(settings, 'show_ballistic_preview', False):
        _draw_ballistic_preview(
            store, shader, view_matrix, ghost_radius, settings, current_frame
        )

    # Restore GPU state
    gpu.state.blend_set('NONE')
    gpu.state.depth_test_set('NONE')
    gpu.state.line_width_set(1.0)


# ---------------------------------------------------------------------------
# Motion Arc Drawing
# ---------------------------------------------------------------------------

def _draw_motion_arcs(
    store: GhostStore,
    shader,
    settings,
) -> None:
    """Legacy motion arc drawing — delegates to Cascadeur-style arcs."""
    _draw_arc_lines_cascadeur(
        store, shader, settings,
        bpy.context.scene.frame_current,
        (0.0, 1.0), 'SOLID', 0.7,
    )


def _draw_arc_lines_cascadeur(
    store: GhostStore,
    shader,
    settings,
    current_frame: float,
    frame_range: tuple[float, float],
    arc_style: str,
    fade_factor: float,
) -> None:
    """Draw Cascadeur-style trajectory arc lines through ghost chains.

    Supports three styles:
      - SOLID:  Single color line
      - SPEED:  Segments colored by velocity (blue=slow, red=fast)
      - FADE:   Line fades with distance from the current frame

    Args:
        store: The GhostStore with active ghosts.
        shader: GPU shader.
        settings: Scene settings.
        current_frame: The playhead position.
        frame_range: Min/max frame of all ghosts.
        arc_style: "SOLID", "SPEED", or "FADE".
        fade_factor: Alpha falloff strength.
    """
    # Collect unique chains (object, bone combinations — merge channels for location)
    # Group by object+bone so we get one arc per bone, combining x/y/z
    bone_chains: dict[tuple[str, str], list[Ghost]] = {}

    for ghost in store:
        key = (ghost.object_name, ghost.bone_name)
        if key not in bone_chains:
            bone_chains[key] = []
        bone_chains[key].append(ghost)

    arc_width = DEFAULT_ARC_WIDTH
    try:
        prefs = bpy.context.preferences.addons.get("ghost_tool")
        if prefs and hasattr(prefs.preferences, "arc_line_width"):
            arc_width = prefs.preferences.arc_line_width
    except Exception as exc:
        debug(f"Failed to read arc line width preference: {exc}")

    gpu.state.line_width_set(arc_width)

    range_width = max(frame_range[1] - frame_range[0], 1.0)

    for chain_key, ghosts in bone_chains.items():
        # Deduplicate by frame (multiple channels at same frame = same world pos)
        frame_to_pos: dict[float, Vector] = {}
        for g in ghosts:
            if g.frame not in frame_to_pos:
                frame_to_pos[g.frame] = g.world_position

        sorted_frames = sorted(frame_to_pos.keys())
        if len(sorted_frames) < 2:
            continue

        positions = [frame_to_pos[f] for f in sorted_frames]

        if arc_style == "SOLID":
            # Single color, one batch
            verts = [tuple(p) for p in positions]
            indices = [(i, i + 1) for i in range(len(verts) - 1)]
            batch = batch_for_shader(
                shader, 'LINES', {"pos": verts}, indices=indices,
            )
            _draw_batch(shader, batch, ARC_COLOR)

        elif arc_style == "SPEED":
            # Each segment colored by velocity: blue=slow, red=fast
            slow_speed_color = (0.2, 0.4, 1.0, 0.8)
            fast_speed_color = (1.0, 0.3, 0.1, 0.8)

            distances = []
            for i in range(len(positions) - 1):
                d = (positions[i + 1] - positions[i]).length
                distances.append(d)

            max_d = max(distances) if distances else 1.0
            min_d = min(distances) if distances else 0.0

            for i in range(len(positions) - 1):
                d = distances[i]
                t = (d - min_d) / (max_d - min_d) if max_d > min_d else 0.5
                color = _lerp_color_hsv(slow_speed_color, fast_speed_color, t)

                batch = batch_for_shader(
                    shader, 'LINES',
                    {"pos": [tuple(positions[i]), tuple(positions[i + 1])]},
                    indices=[(0, 1)],
                )
                _draw_batch(shader, batch, color)

        elif arc_style == "FADE":
            # Segments fade with distance from cursor
            for i in range(len(sorted_frames) - 1):
                mid_frame = (sorted_frames[i] + sorted_frames[i + 1]) / 2.0
                normalized_distance = min(abs(mid_frame - current_frame) / range_width, 1.0)
                alpha = 0.8 * (1.0 - normalized_distance * fade_factor)
                color = (0.7, 0.7, 0.7, max(alpha, 0.05))

                batch = batch_for_shader(
                    shader, 'LINES',
                    {"pos": [tuple(positions[i]), tuple(positions[i + 1])]},
                    indices=[(0, 1)],
                )
                _draw_batch(shader, batch, color)

    gpu.state.line_width_set(2.0)


# ---------------------------------------------------------------------------
# Spacing Tick Drawing
# ---------------------------------------------------------------------------

def _draw_spacing_ticks_impl(
    store: GhostStore,
    shader,
    view_matrix,
    settings,
) -> None:
    """Draw tick marks along the motion arc showing frame spacing.

    Ticks are colored from slow_speed_color (dense/slow) to fast_speed_color (sparse/fast).

    Args:
        store: The GhostStore containing all active ghosts.
        shader: The GPU shader to use.
        view_matrix: The current view matrix for billboard orientation.
        settings: The GhostToolSceneSettings property group.
    """
    # Default spacing tick colors
    slow_speed_color = (0.2, 0.4, 1.0, 0.8)   # Blue = slow
    fast_speed_color = (1.0, 0.3, 0.1, 0.8)   # Red = fast

    tick_length = 0.03

    # Collect chains
    chains: dict[tuple[str, str, str], list[Ghost]] = {}
    for ghost in store:
        key = (ghost.object_name, ghost.bone_name, ghost.channel)
        if key not in chains:
            chains[key] = []
        chains[key].append(ghost)

    inv_view = view_matrix.inverted()
    up = Vector((inv_view[1][0], inv_view[1][1], inv_view[1][2])).normalized()

    for chain_key, ghosts in chains.items():
        ghosts.sort(key=lambda g: g.frame)
        if len(ghosts) < 2:
            continue

        # Compute spatial distances between consecutive ghosts
        distances = []
        for i in range(len(ghosts) - 1):
            d = (ghosts[i + 1].world_position - ghosts[i].world_position).length
            distances.append(d)

        if not distances:
            continue

        max_dist = max(distances) if max(distances) > 0 else 1.0
        min_dist = min(distances)

        # Draw a tick at each ghost position
        for i, ghost in enumerate(ghosts):
            # Determine speed factor: use average of adjacent distances
            if i == 0:
                speed = distances[0] if distances else 0
            elif i >= len(distances):
                speed = distances[-1] if distances else 0
            else:
                speed = (distances[i - 1] + distances[i]) / 2.0

            # Normalize to [0, 1] range for color mapping
            if max_dist > min_dist:
                t = (speed - min_dist) / (max_dist - min_dist)
            else:
                t = 0.5

            color = _lerp_color_hsv(slow_speed_color, fast_speed_color, t)

            # Tick is a short line perpendicular to the arc direction
            pos = ghost.world_position
            tick_top = pos + up * tick_length
            tick_bot = pos - up * tick_length

            batch = batch_for_shader(
                shader, 'LINES',
                {"pos": [tuple(tick_top), tuple(tick_bot)]},
                indices=[(0, 1)],
            )
            _draw_batch(shader, batch, color)


# ---------------------------------------------------------------------------
# Snapshot Overlay Drawing
# ---------------------------------------------------------------------------

def _draw_snapshot_overlays(
    context: bpy.types.Context,
    shader,
    view_matrix,
    ghost_radius: float,
) -> None:
    """Draw desaturated ghost markers for visible snapshots.

    Snapshot ghosts are non-interactive and drawn with reduced opacity.

    Args:
        context: The current Blender context.
        shader: The GPU shader to use.
        view_matrix: The current view matrix.
        ghost_radius: Base radius for ghost markers.
    """
    # Import here to avoid circular dependency
    try:
        from .snapshot import SnapshotStore
    except ImportError:
        return

    scene = context.scene
    snap_store = SnapshotStore.get(scene)

    for snapshot in snap_store.get_visible():
        for ghost_data in snapshot.ghost_data:
            pos = Vector(ghost_data.get("world_position", (0, 0, 0)))
            level = ghost_data.get("generation_level", 1)

            base_color = _get_level_color(level)
            color = _desaturate_color(base_color, factor=0.6)

            all_verts: list[tuple] = []
            all_indices: list[tuple[int, int]] = []

            circle_verts = _build_3d_circle_verts(
                pos, ghost_radius * 0.8, view_matrix
            )
            for v in circle_verts:
                all_verts.append(tuple(v))
            for i in range(SPHERE_SEGMENTS):
                all_indices.append((i, (i + 1) % SPHERE_SEGMENTS))

            if all_verts:
                batch = batch_for_shader(
                    shader, 'LINES',
                    {"pos": all_verts},
                    indices=all_indices,
                )
                _draw_batch(shader, batch, color)


# ---------------------------------------------------------------------------
# Public draw functions (referenced in the spec for clarity)
# ---------------------------------------------------------------------------

def draw_ghosts(context: bpy.types.Context) -> None:
    """Draw ghost markers in the viewport.

    Wrapper that delegates to draw_ghosts_3d.  Kept as a named function
    matching the spec for documentation purposes.

    Args:
        context: The current Blender context.
    """
    draw_ghosts_3d(context)


def draw_motion_arc(context: bpy.types.Context) -> None:
    """Draw motion arcs in the viewport.

    Note: Arc drawing is integrated into draw_ghosts_3d for batching
    efficiency.  This function is a no-op and exists for API compatibility.

    Args:
        context: The current Blender context.
    """
    # Integrated into draw_ghosts_3d
    pass


def draw_spacing_ticks(context: bpy.types.Context) -> None:
    """Draw spacing ticks in the viewport.

    Note: Tick drawing is integrated into draw_ghosts_3d for batching
    efficiency.  This function is a no-op and exists for API compatibility.

    Args:
        context: The current Blender context.
    """
    # Integrated into draw_ghosts_3d
    pass


def draw_snapshot_overlay(context: bpy.types.Context) -> None:
    """Draw snapshot overlays in the viewport.

    Note: Snapshot drawing is integrated into draw_ghosts_3d for batching
    efficiency.  This function is a no-op and exists for API compatibility.

    Args:
        context: The current Blender context.
    """
    # Integrated into draw_ghosts_3d
    pass


# ---------------------------------------------------------------------------
# Ballistic Preview Drawing
# ---------------------------------------------------------------------------

def _draw_ballistic_preview(
    store: GhostStore,
    shader,
    view_matrix,
    ghost_radius: float,
    settings,
    current_frame: float,
) -> None:
    """Draw a ballistic arc preview showing physics-influenced ghost trajectories.

    Renders a dashed arc and translucent markers at predicted positions
    assuming constant gravitational acceleration.

    Args:
        store: The GhostStore with current ghosts.
        shader: The GPU shader to draw with.
        view_matrix: The 3D view matrix for billboard calculations.
        ghost_radius: Base radius for ghost markers.
        settings: GhostToolSceneSettings with ballistic parameters.
        current_frame: The scene's current playhead frame.
    """
    all_ghosts = list(store)
    if len(all_ghosts) < 2:
        return

    gravity_strength = getattr(settings, 'ballistic_gravity', 9.81)
    gravity_axis = getattr(settings, 'ballistic_gravity_axis', 'Z')
    offset = Vector(getattr(settings, 'ballistic_offset', (0.0, 0.0, 0.0)))

    axis_idx = {"X": 0, "Y": 1, "Z": 2}.get(gravity_axis.upper(), 2)
    fps = bpy.context.scene.render.fps if bpy.context.scene else 24.0

    # Collect ghost positions sorted by frame
    sorted_ghosts = sorted(all_ghosts, key=lambda g: g.frame)

    if len(sorted_ghosts) < 2:
        return

    first_frame = sorted_ghosts[0].frame
    last_frame = sorted_ghosts[-1].frame
    total_frames = last_frame - first_frame
    if total_frames <= 0:
        return

    total_time = total_frames / fps

    # Compute ballistic preview positions for each ghost
    preview_positions: list[Vector] = []
    for g in sorted_ghosts:
        t_frames = g.frame - first_frame
        t_sec = t_frames / fps

        # Parabolic displacement: 0.5 * g * t * (T - t) peaks at midpoint
        displacement = 0.5 * gravity_strength * t_sec * (total_time - t_sec)

        pos = g.world_position.copy()
        pos[axis_idx] -= displacement * 0.01  # Scale down for visual clarity
        pos += offset
        preview_positions.append(pos)

    if not preview_positions:
        return

    # Draw the ballistic arc line (dashed effect via alternating segments)
    arc_verts: list[tuple] = []
    arc_indices: list[tuple[int, int]] = []
    for i in range(len(preview_positions) - 1):
        # Only draw every other segment for dashed effect
        if i % 2 == 0:
            base = len(arc_verts)
            arc_verts.append(tuple(preview_positions[i]))
            arc_verts.append(tuple(preview_positions[i + 1]))
            arc_indices.append((base, base + 1))

    if arc_verts:
        gpu.state.line_width_set(2.0)
        batch = batch_for_shader(
            shader, 'LINES',
            {"pos": arc_verts},
            indices=arc_indices,
        )
        _draw_batch(shader, batch, BALLISTIC_ARC_COLOR)

    # Draw translucent markers at predicted positions
    marker_radius = ghost_radius * 0.7
    for pos in preview_positions:
        circle_verts = _build_3d_circle_verts(pos, marker_radius, view_matrix)
        indices = [(i, (i + 1) % SPHERE_SEGMENTS) for i in range(SPHERE_SEGMENTS)]

        batch = batch_for_shader(
            shader, 'LINES',
            {"pos": [tuple(v) for v in circle_verts]},
            indices=indices,
        )
        _draw_batch(shader, batch, BALLISTIC_MARKER_COLOR)


# ---------------------------------------------------------------------------
# Registration / Unregistration
# ---------------------------------------------------------------------------

def register() -> None:
    """Register 3D viewport draw handlers.

    Adds a POST_VIEW draw handler for 3D geometry (ghosts, arcs, ticks).
    The handler reference is stored at module level for clean removal.
    """
    global _draw_handler_3d

    if _draw_handler_3d is not None:
        # Already registered — prevent duplicates
        return

    _draw_handler_3d = bpy.types.SpaceView3D.draw_handler_add(
        draw_ghosts_3d,
        (bpy.context,),  # Replaced at call time by Blender with the real context
        'WINDOW',
        'POST_VIEW',
    )
    log("Viewport draw handlers registered.")


def unregister() -> None:
    """Remove all viewport draw handlers.

    Must be called during addon unregistration to prevent Blender crashes
    from stale draw callbacks referencing unloaded code.
    """
    global _draw_handler_3d, _draw_handler_2d

    if _draw_handler_3d is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handler_3d, 'WINDOW')
        except Exception as exc:
            warn(f"Failed to remove 3D draw handler: {exc}")
        _draw_handler_3d = None

    if _draw_handler_2d is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handler_2d, 'WINDOW')
        except Exception as exc:
            warn(f"Failed to remove 2D draw handler: {exc}")
        _draw_handler_2d = None

    log("Viewport draw handlers unregistered.")


# ---------------------------------------------------------------------------
# Test notes
# ---------------------------------------------------------------------------
#
# Test 1: Draw handler registration
# >>> from ghost_tool import viewport_draw
# >>> viewport_draw.register()
# >>> # Verify no errors in the console
# >>> viewport_draw.unregister()
#
# Test 2: Ghost display after generation
# >>> # 1. Generate ghosts on an object with keyframes
# >>> # 2. Set scene.ghost_tool.is_active = True
# >>> # 3. Verify colored circles appear at ghost positions in viewport
# >>> # 4. Toggle show_level_1 off — level 1 ghosts should disappear
#
# Test 3: Motion arc visibility
# >>> # With ghosts generated, scene.ghost_tool.show_motion_arc = True
# >>> # A gray line should connect ghosts in sequence
#
# Test 4: Spacing ticks color gradient
# >>> # scene.ghost_tool.show_spacing_ticks = True
# >>> # Dense areas (slow motion) should be blue, sparse = red
