"""
ui_panel.py — Ghost Tool UI: header strip, floating toolbar, and settings popovers.

Design philosophy:
    The primary control surface is a compact ICON STRIP that can live:
      1. Docked in the 3D Viewport's N-panel as a single compact row
      2. Appended to the Timeline / Dopesheet header for always-on access
      3. Popped out as a floating toolbar via a dedicated operator

    Every feature has a one-click icon button WITH a friendly text label.
    Detailed settings (colors, radii, ranges) are tucked into popovers
    so the strip stays clean but nothing is hidden.

    The goal is Grease-Pencil-onion-skinning simplicity with Cascadeur power.
"""

from __future__ import annotations

import bpy

from .ghost_data import GhostStore
from .snapshot import SnapshotStore
from .easing_presets import PRESET_ENUM_ITEMS
from .utils import log, warn, debug


# ---------------------------------------------------------------------------
# Easing Settings PropertyGroup (needed by panels)
# ---------------------------------------------------------------------------

class GhostToolEasingSettings(bpy.types.PropertyGroup):
    """Scene-level state for the easing preset selector."""

    active_preset: bpy.props.EnumProperty(
        name="Easing Preset",
        description="Select an easing curve feel to apply between keyframes",
        items=PRESET_ENUM_ITEMS,
        default="EASE_IN_OUT",
    )  # type: ignore[assignment]

    custom_left_x: bpy.props.FloatProperty(
        name="Left Handle X", default=0.33, min=0.0, max=1.0,
    )  # type: ignore[assignment]
    custom_left_y: bpy.props.FloatProperty(
        name="Left Handle Y", default=0.0, min=-2.0, max=2.0,
    )  # type: ignore[assignment]
    custom_right_x: bpy.props.FloatProperty(
        name="Right Handle X", default=-0.33, min=-1.0, max=0.0,
    )  # type: ignore[assignment]
    custom_right_y: bpy.props.FloatProperty(
        name="Right Handle Y", default=0.0, min=-2.0, max=2.0,
    )  # type: ignore[assignment]


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  SECTION 1 — THE GHOST STRIP  (compact icon + label toolbar)          ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class GHOST_PT_strip(bpy.types.Panel):
    """Primary Ghost Tool strip — one-click access to every feature.

    This panel renders as a compact, icon-rich toolbar inside the
    N-panel sidebar.  It is designed to feel like a dedicated timeline
    tab for ghosting, not a buried settings menu.
    """

    bl_idname = "GHOST_PT_strip"
    bl_label = "Ghost Tool"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Ghost Tool"

    def draw_header(self, context: bpy.types.Context) -> None:
        """Draw the panel header with the master on/off toggle.

        Args:
            context: The current Blender context.
        """
        layout = self.layout
        scene = context.scene
        if hasattr(scene, 'ghost_tool'):
            layout.prop(scene.ghost_tool, "is_active", text="", icon='GHOST_ENABLED')

    def draw(self, context: bpy.types.Context) -> None:
        """Draw the full ghost strip UI.

        Args:
            context: The current Blender context.
        """
        layout = self.layout
        scene = context.scene

        if not hasattr(scene, 'ghost_tool'):
            layout.label(text="Ghost Tool not initialized", icon='ERROR')
            return

        settings = scene.ghost_tool
        store = GhostStore.get(scene)

        # Master toggle: activates/deactivates all ghost visualization and tools.
        # ──────────────────────────────────────────────────────
        #  ROW 1 — MASTER TOGGLE  (big, impossible to miss)
        # ──────────────────────────────────────────────────────
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.6

        icon = 'GHOST_ENABLED' if settings.is_active else 'GHOST_DISABLED'
        row.prop(
            settings, "is_active",
            text="  Ghosts ON" if settings.is_active else "  Ghosts OFF",
            icon=icon,
            toggle=True,
        )

        # Ghost count badge
        if len(store) > 0:
            row.label(text=f"  {len(store)}")

        # Onion skin mode: displays semi-transparent copies of the mesh at nearby frames.
        # Provides quick visual feedback of mesh deformation, sliding, or overlaps.
        # ══════════════════════════════════════════════════════
        #  MESH ONION SKIN — transparent pose silhouettes
        #  The primary visual tool for character animation.
        # ══════════════════════════════════════════════════════
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.4
        icon_mesh = 'GHOST_ENABLED' if settings.show_mesh_ghosts else 'GHOST_DISABLED'
        row.prop(
            settings, "show_mesh_ghosts",
            text="  Onion Skin" if settings.show_mesh_ghosts else "  Onion Skin OFF",
            icon=icon_mesh,
            toggle=True,
        )

        # Always show Generate/Clear when section is enabled
        if settings.show_mesh_ghosts:
            box.label(text="Shows transparent copies of your mesh at nearby frames",
                      icon='INFO')

            row2 = box.row(align=True)
            row2.scale_y = 1.3
            row2.operator(
                "ghost_tool.generate_mesh_ghosts",
                text="Generate Meshes",
                icon='MESH_DATA',
            )
            row2.operator(
                "ghost_tool.clear_mesh_ghosts",
                text="Clear",
                icon='TRASH',
            )

            # Display mode toggle
            row2 = box.row(align=True)
            row2.prop(settings, "mesh_ghost_mode", expand=True)

            # Past / Future counts
            row2 = box.row(align=True)
            row2.prop(settings, "mesh_ghost_past_count", text="Past")
            row2.prop(settings, "mesh_ghost_future_count", text="Future")

            # Step and opacity
            row2 = box.row(align=True)
            row2.prop(settings, "mesh_ghost_step", text="Step")
            row2.prop(settings, "mesh_ghost_opacity", text="Opacity", slider=True)

            # Past / Future visibility
            row2 = box.row(align=True)
            row2.prop(settings, "show_mesh_past", text="Past", toggle=True,
                      icon='REW' if settings.show_mesh_past else 'BLANK1')
            row2.prop(settings, "show_mesh_future", text="Future", toggle=True,
                      icon='FF' if settings.show_mesh_future else 'BLANK1')

            # Outline controls
            row2 = box.row(align=True)
            row2.prop(
                settings, "ghost_outline_enabled",
                text="Outline",
                toggle=True,
                icon='MOD_SOLIDIFY',
            )
            if settings.ghost_outline_enabled:
                row2.prop(settings, "ghost_outline_width", text="Width")
                row3 = box.row(align=True)
                row3.prop(settings, "ghost_outline_color", text="Outline Color")

            # Live mesh toggle
            row2 = box.row(align=True)
            row2.prop(
                settings, "live_mesh_ghosts",
                text="Auto-Update on Frame Change",
                toggle=True,
                icon='PLAY' if settings.live_mesh_ghosts else 'PAUSE',
            )

        layout.separator(factor=0.5)

        # Bone trajectory markers: point clouds showing where selected bones move.
        # Essential for analyzing motion arcs, motion timing, and spacing issues.
        # ══════════════════════════════════════════════════════
        #  BONE TRAJECTORY MARKERS — dots tracking bone paths
        #  Shows where individual bones travel through space.
        #  Useful for analyzing arcs, spacing, and timing.
        # ══════════════════════════════════════════════════════
        box = layout.box()
        row = box.row(align=True)
        row.label(text="Bone Trajectory Markers", icon='BONE_DATA')
        box.label(text="Dots on bones showing motion paths & spacing",
                  icon='INFO')

        # Generate / Clear point ghosts
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator(
            "ghost_tool.generate_ghosts",
            text="Generate Markers",
            icon='ADD',
        )
        row.operator(
            "ghost_tool.clear_ghosts",
            text="Clear",
            icon='TRASH',
        )

        # Live point toggle
        row = box.row(align=True)
        row.prop(
            settings, "live_point_ghosts",
            text="Auto-Update on Frame Change",
            toggle=True,
            icon='PLAY' if settings.live_point_ghosts else 'PAUSE',
        )

        # Show freeze + throttle when any live mode is active
        if settings.live_point_ghosts or settings.live_mesh_ghosts:
            row2 = box.row(align=True)
            row2.prop(
                settings, "live_freeze",
                text="Freeze Updates",
                toggle=True,
                icon='SNAP_ON' if settings.live_freeze else 'SNAP_OFF',
            )
            row2.prop(settings, "live_throttle_ms", text="Delay")

        layout.separator(factor=0.3)

        # Marker placement configuration: choose distribution (subdivision, frame step, keyframes)
        # and temporal range (around playhead, custom range, or specific frame set).
        # ──────────────────────────────────────────────────────
        #  GHOST MODE & RANGE — how markers are placed
        # ──────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Marker Placement", icon='ONIONSKIN_ON')

        # Mode selector (subdivision vs frame-step vs keyframes only)
        row = box.row(align=True)
        row.prop(settings, "ghost_mode", expand=True)

        # Mode-specific controls
        if settings.ghost_mode == "SUBDIVISION":
            row = box.row(align=True)
            row.label(text="", icon='MOD_SUBSURF')
            row.prop(settings, "subdivision_level", text="Detail Level", slider=True)

        elif settings.ghost_mode == "FRAME_STEP":
            row = box.row(align=True)
            row.prop(settings, "frame_step", text="Every N Frames")

        # Range mode
        box2 = box.box()
        row = box2.row(align=True)
        row.label(text="Range:", icon='PREVIEW_RANGE')
        row.prop(settings, "ghost_range_mode", text="")

        if settings.ghost_range_mode == "AROUND_CURSOR":
            row = box2.row(align=True)
            row.prop(settings, "ghosts_before", text="Before")
            row.prop(settings, "ghosts_after", text="After")

        elif settings.ghost_range_mode == "CUSTOM":
            row = box2.row(align=True)
            row.prop(settings, "custom_range_start", text="Start")
            row.prop(settings, "custom_range_end", text="End")

        layout.separator(factor=0.3)

        # Visual styling for markers: colors, opacity, arc lines, frame labels, spacing ticks.
        # Customize appearance to match animation style (past/future distinction, key/inbetween contrast).
        # ──────────────────────────────────────────────────────
        #  DISPLAY OPTIONS — Colors, arcs, fading
        #  Controls how bone markers and arcs look.
        # ──────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Marker Display", icon='RESTRICT_VIEW_OFF')

        # Color mode
        row = box.row(align=True)
        row.label(text="Color:")
        row.prop(settings, "ghost_color_mode", text="")

        # Fade factor (for non-LEVEL modes)
        if settings.ghost_color_mode != "LEVEL":
            row = box.row(align=True)
            row.prop(settings, "ghost_fade_factor", text="Fade Distance", slider=True)

            # Falloff curve
            row = box.row(align=True)
            row.label(text="Falloff:")
            row.prop(settings, "ghost_falloff_curve", text="")

            # Min alpha
            row = box.row(align=True)
            row.prop(settings, "ghost_min_alpha", text="Min Opacity", slider=True)

        # User-configurable colors per mode
        if settings.ghost_color_mode == "TIME":
            col = box.column(align=True)
            col.prop(settings, "ghost_past_color", text="Past")
            col.prop(settings, "ghost_future_color", text="Future")
        elif settings.ghost_color_mode == "KEY_INBETWEEN":
            col = box.column(align=True)
            col.prop(settings, "ghost_key_color", text="Key")
            col.prop(settings, "ghost_inbetween_color", text="Inbetween")

        # Label color (when frame numbers are shown)
        if settings.show_frame_numbers:
            row = box.row(align=True)
            row.prop(settings, "ghost_label_color", text="Label Color")

        # Arc lines
        row = box.row(align=True)
        row.prop(settings, "show_arc_lines", text="Arc Lines", toggle=True, icon='CURVE_PATH')
        if settings.show_arc_lines:
            row.prop(settings, "arc_line_style", text="")

        # Spacing ticks + frame numbers
        row = box.row(align=True)
        row.prop(settings, "show_spacing_ticks", text="Spacing", toggle=True, icon='TIME')
        row.prop(settings, "show_frame_numbers", text="Frame #", toggle=True, icon='FONT_DATA')

        # Per-level visibility (only relevant for subdivision mode)
        if settings.ghost_mode == "SUBDIVISION":
            row = box.row(align=True)
            row.label(text="Levels:")
            for level in range(1, 6):
                count = len(store.filter_by_level(level))
                icon_lv = 'LAYER_ACTIVE' if settings.is_level_visible(level) else 'LAYER_USED'
                row.prop(
                    settings, f"show_level_{level}",
                    text=str(level), toggle=True,
                    icon=icon_lv if count > 0 else 'BLANK1',
                )

        layout.separator(factor=0.5)

        # Interactive marker editing: drag to adjust timing/spacing, pin key poses, apply easing curves.
        # Also includes snapshot capture, ballistic preview, and physics arc suggestion tools.
        # ──────────────────────────────────────────────────────
        #  TOOLS — Editing tools for bone trajectory markers.
        #  Drag markers to reshape animation curves, apply
        #  easing presets, pin poses, take snapshots.
        # ──────────────────────────────────────────────────────
        box = layout.box()
        box.label(text="Marker Tools", icon='TOOL_SETTINGS')

        # -- Drag Mode --
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator(
            "ghost_tool.drag_ghost",
            text="Drag Marker",
            icon='ORIENTATION_CURSOR',
        )
        # Curve mode selector right next to it
        row.prop(settings, "curve_mode", text="")

        # -- Easing --
        row = box.row(align=True)
        row.scale_y = 1.2
        if hasattr(scene, 'ghost_tool_easing'):
            row.prop(scene.ghost_tool_easing, "active_preset", text="")
            op = row.operator(
                "ghost_tool.apply_easing",
                text="Apply Easing",
                icon='IPO_EASE_IN_OUT',
            )
            op.preset = scene.ghost_tool_easing.active_preset
        else:
            row.operator(
                "ghost_tool.apply_easing",
                text="Apply Easing",
                icon='IPO_EASE_IN_OUT',
            )

        # -- Pin / Unpin --
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator(
            "ghost_tool.pin_ghost",
            text="Pin Marker",
            icon='PINNED',
        )
        row.operator(
            "ghost_tool.unpin_all",
            text="Unpin All",
            icon='UNPINNED',
        )
        pinned_count = len(store.get_pinned())
        if pinned_count > 0:
            row.label(text=f"({pinned_count})")

        # -- Snapshot --
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator(
            "ghost_tool.take_snapshot",
            text="Snapshot",
            icon='CAMERA_DATA',
        )
        snap_store = SnapshotStore.get(scene)
        snap_count = len(snap_store.get_all())
        if snap_count > 0:
            row.label(text=f"({snap_count} saved)")

        # -- Physics Suggest --
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator(
            "ghost_tool.physics_suggest",
            text="Physics Arc",
            icon='FORCE_FORCE',
        )

        # -- Ballistic Preview --
        row = box.row(align=True)
        row.prop(
            settings, "show_ballistic_preview",
            text="Ballistic Preview",
            toggle=True,
            icon='FORCE_HARMONIC',
        )

        if settings.show_ballistic_preview:
            col = box.column(align=True)
            row2 = col.row(align=True)
            row2.prop(settings, "ballistic_gravity", text="Gravity")
            row2.prop(settings, "ballistic_gravity_axis", text="")
            col.prop(settings, "ballistic_offset", text="Offset")

        layout.separator(factor=0.5)

        # Data persistence: export ghost sets to JSON for sharing or backup,
        # import previously saved configurations to quickly restore setups.
        # ──────────────────────────────────────────────────────
        #  EXPORT / IMPORT  (file operations)
        # ──────────────────────────────────────────────────────
        row = layout.row(align=True)
        row.operator(
            "ghost_tool.export_ghosts",
            text="Export",
            icon='EXPORT',
        )
        row.operator(
            "ghost_tool.import_ghosts",
            text="Import",
            icon='IMPORT',
        )


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  SECTION 2 — SETTINGS POPOVER  (detailed tuning, opened from strip)   ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class GHOST_PT_settings(bpy.types.Panel):
    """Detailed settings panel — frame range, grab radius, custom easing.

    This sub-panel holds the "deep" controls that don't need to be
    visible all the time but should be one click away.
    """

    bl_idname = "GHOST_PT_settings"
    bl_label = "Settings"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Ghost Tool"
    bl_parent_id = "GHOST_PT_strip"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: bpy.types.Context) -> None:
        """Draw the detailed settings sub-panel.

        Args:
            context: The current Blender context.
        """
        layout = self.layout
        scene = context.scene

        if not hasattr(scene, 'ghost_tool'):
            return

        settings = scene.ghost_tool

        # Grab radius
        layout.prop(settings, "grab_radius", text="Grab Radius (px)", icon='CURSOR')

        layout.separator()

        # Frame range
        box = layout.box()
        box.label(text="Frame Range", icon='PREVIEW_RANGE')
        box.prop(settings, "use_custom_range", text="Use Custom Range")
        if settings.use_custom_range:
            row = box.row(align=True)
            row.prop(settings, "custom_range_start", text="Start")
            row.prop(settings, "custom_range_end", text="End")

        layout.separator()

        # Custom easing tangent inputs
        if hasattr(scene, 'ghost_tool_easing'):
            easing = scene.ghost_tool_easing
            if easing.active_preset == "CUSTOM":
                box = layout.box()
                box.label(text="Custom Tangent Handles", icon='HANDLETYPE_FREE_VEC')
                row = box.row(align=True)
                row.prop(easing, "custom_left_x", text="L.X")
                row.prop(easing, "custom_left_y", text="L.Y")
                row = box.row(align=True)
                row.prop(easing, "custom_right_x", text="R.X")
                row.prop(easing, "custom_right_y", text="R.Y")


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  SECTION 3 — SNAPSHOT MANAGER  (sub-panel with list)                   ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class GHOST_PT_snapshot_manager(bpy.types.Panel):
    """Snapshot management sub-panel — list, toggle, restore, delete."""

    bl_idname = "GHOST_PT_snapshot_manager"
    bl_label = "Saved Snapshots"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Ghost Tool"
    bl_parent_id = "GHOST_PT_strip"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context: bpy.types.Context) -> None:
        """Draw the snapshot list.

        Args:
            context: The current Blender context.
        """
        layout = self.layout
        scene = context.scene
        snap_store = SnapshotStore.get(scene)
        snapshots = snap_store.get_all()

        if not snapshots:
            layout.label(text="No snapshots yet — click Snapshot above")
            return

        for snap in snapshots:
            box = layout.box()
            row = box.row(align=True)

            # Visibility eye icon
            icon = 'HIDE_OFF' if snap.is_visible else 'HIDE_ON'
            op = row.operator("ghost_tool.toggle_snapshot", text="", icon=icon)
            op.snapshot_uid = snap.uid

            # Name and ghost count
            row.label(text=f"{snap.name}  ({len(snap.ghost_data)})")

            # Restore and delete
            op = row.operator("ghost_tool.restore_snapshot", text="", icon='LOOP_BACK')
            op.snapshot_uid = snap.uid
            op = row.operator("ghost_tool.delete_snapshot", text="", icon='X')
            op.snapshot_uid = snap.uid


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  SECTION 4 — FLOATING TOOLBAR OPERATOR                                ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class GHOST_OT_floating_toolbar(bpy.types.Operator):
    """Pop out the Ghost Tool strip as a floating toolbar dialog.

    This creates a detached popup containing the full icon strip.
    Useful for animators who want the ghost controls floating over
    the viewport without the N-panel open.
    """

    bl_idname = "ghost_tool.floating_toolbar"
    bl_label = "Ghost Tool — Floating Toolbar"
    bl_options = {'REGISTER'}

    def execute(self, context: bpy.types.Context) -> set[str]:
        """Show the floating toolbar.

        Args:
            context: The current Blender context.

        Returns:
            set[str]: {'FINISHED'}.
        """
        return context.window_manager.invoke_popup(self, width=320)

    def draw(self, context: bpy.types.Context) -> None:
        """Draw the floating toolbar contents (mirrors the strip).

        Args:
            context: The current Blender context.
        """
        layout = self.layout
        scene = context.scene

        if not hasattr(scene, 'ghost_tool'):
            layout.label(text="Ghost Tool not initialized", icon='ERROR')
            return

        settings = scene.ghost_tool
        store = GhostStore.get(scene)

        # ── Master toggle ──
        row = layout.row(align=True)
        row.scale_y = 1.8
        icon = 'GHOST_ENABLED' if settings.is_active else 'GHOST_DISABLED'
        row.prop(
            settings, "is_active",
            text="  GHOSTS ON" if settings.is_active else "  GHOSTS OFF",
            icon=icon,
            toggle=True,
        )
        if len(store) > 0:
            row.label(text=f" {len(store)}")

        layout.separator()

        # ── Generate / Clear ──
        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator("ghost_tool.generate_ghosts", text="Generate", icon='ADD')
        row.operator("ghost_tool.clear_ghosts", text="Clear", icon='TRASH')

        # ── Subdivision slider ──
        row = layout.row(align=True)
        row.prop(settings, "subdivision_level", text="Detail Level", slider=True)

        layout.separator()

        # ── Tool buttons (2 columns) ──
        grid = layout.grid_flow(columns=2, align=True, even_columns=True)
        grid.scale_y = 1.2

        grid.operator("ghost_tool.drag_ghost", text="Drag Marker", icon='ORIENTATION_CURSOR')
        grid.operator("ghost_tool.pin_ghost", text="Pin Marker", icon='PINNED')
        grid.operator("ghost_tool.take_snapshot", text="Snapshot", icon='CAMERA_DATA')
        grid.operator("ghost_tool.unpin_all", text="Unpin All", icon='UNPINNED')
        grid.operator("ghost_tool.physics_suggest", text="Physics Arc", icon='FORCE_FORCE')

        if hasattr(scene, 'ghost_tool_easing'):
            op = grid.operator("ghost_tool.apply_easing", text="Apply Easing", icon='IPO_EASE_IN_OUT')
            op.preset = scene.ghost_tool_easing.active_preset

        layout.separator()

        # ── Display toggles ──
        row = layout.row(align=True)
        row.prop(settings, "show_motion_arc", text="Arc", toggle=True, icon='CURVE_PATH')
        row.prop(settings, "show_spacing_ticks", text="Spacing", toggle=True, icon='TIME')

        # Level toggles
        row = layout.row(align=True)
        for level in range(1, 6):
            row.prop(settings, f"show_level_{level}", text=str(level), toggle=True)

        layout.separator()

        # ── Export / Import ──
        row = layout.row(align=True)
        row.operator("ghost_tool.export_ghosts", text="Export", icon='EXPORT')
        row.operator("ghost_tool.import_ghosts", text="Import", icon='IMPORT')

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        """Invoke the popup.

        Args:
            context: The current Blender context.
            event: The triggering event.

        Returns:
            set[str]: Popup result.
        """
        return context.window_manager.invoke_popup(self, width=320)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  SECTION 5 — TIMELINE / DOPESHEET HEADER EXTENSION                    ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def _draw_timeline_header_extension(self, context: bpy.types.Context) -> None:
    """Append a compact ghost toggle strip to the Timeline/Dopesheet header.

    This function is appended to Blender's built-in header draw lists
    so Ghost Tool controls are always visible when animating.

    Args:
        self: The header panel instance.
        context: The current Blender context.
    """
    scene = context.scene
    if not hasattr(scene, 'ghost_tool'):
        return

    settings = scene.ghost_tool
    store = GhostStore.get(scene)
    layout = self.layout

    # Separator from Blender's built-in header items
    layout.separator_spacer()

    # Compact ghost strip in the header
    row = layout.row(align=True)

    # On/off toggle — the most important button
    icon = 'GHOST_ENABLED' if settings.is_active else 'GHOST_DISABLED'
    row.prop(settings, "is_active", text="", icon=icon, toggle=True)

    # Only show the rest when ghosts are active
    if settings.is_active:
        # Generate / Clear
        row.operator("ghost_tool.generate_ghosts", text="", icon='ADD')
        row.operator("ghost_tool.clear_ghosts", text="", icon='TRASH')

        # Subdivision level (compact)
        sub = row.row(align=True)
        sub.scale_x = 0.6
        sub.prop(settings, "subdivision_level", text="")

        row.separator(factor=0.5)

        # Drag mode
        row.operator("ghost_tool.drag_ghost", text="", icon='ORIENTATION_CURSOR')

        # Pin
        row.operator("ghost_tool.pin_ghost", text="", icon='PINNED')

        # Snapshot
        row.operator("ghost_tool.take_snapshot", text="", icon='CAMERA_DATA')

        # Display toggles
        row.separator(factor=0.5)
        row.prop(settings, "show_motion_arc", text="", icon='CURVE_PATH', toggle=True)
        row.prop(settings, "show_spacing_ticks", text="", icon='TIME', toggle=True)

        # Mesh onion skin toggle
        row.separator(factor=0.5)
        icon_mesh = 'MOD_MESHDEFORM' if settings.show_mesh_ghosts else 'MESH_DATA'
        row.prop(settings, "show_mesh_ghosts", text="", icon=icon_mesh, toggle=True)

        # Ghost count
        if len(store) > 0:
            row.label(text=f" {len(store)}")

    # Pop-out button (opens floating toolbar for full controls)
    row.separator(factor=0.5)
    row.operator("ghost_tool.floating_toolbar", text="", icon='WINDOW')


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  SECTION 6 — 3D VIEWPORT HEADER EXTENSION                             ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def _draw_viewport_header_extension(self, context: bpy.types.Context) -> None:
    """Append a minimal ghost toggle to the 3D Viewport header.

    Sits next to the overlay/gizmo dropdowns for quick access.

    Args:
        self: The header panel instance.
        context: The current Blender context.
    """
    scene = context.scene
    if not hasattr(scene, 'ghost_tool'):
        return

    settings = scene.ghost_tool
    layout = self.layout

    row = layout.row(align=True)
    icon = 'GHOST_ENABLED' if settings.is_active else 'GHOST_DISABLED'
    row.prop(settings, "is_active", text="", icon=icon, toggle=True)

    # Pop-out for full toolbar
    row.operator("ghost_tool.floating_toolbar", text="", icon='WINDOW')


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

CLASSES: tuple[type, ...] = (
    GhostToolEasingSettings,
    GHOST_PT_strip,
    GHOST_PT_settings,
    GHOST_PT_snapshot_manager,
    GHOST_OT_floating_toolbar,
)

# Track header appends for clean unregistration
_header_appends: list[tuple] = []


def register() -> None:
    """Register all UI classes and header extensions."""
    for cls in CLASSES:
        bpy.utils.register_class(cls)

    bpy.types.Scene.ghost_tool_easing = bpy.props.PointerProperty(
        type=GhostToolEasingSettings,
        name="Ghost Tool Easing Settings",
    )

    # Append to Timeline header
    try:
        bpy.types.DOPESHEET_HT_header.append(_draw_timeline_header_extension)
        _header_appends.append(
            (bpy.types.DOPESHEET_HT_header, _draw_timeline_header_extension)
        )
    except Exception as exc:
        warn(f"Could not append to Dopesheet header: {exc}")

    # Append to 3D Viewport header
    try:
        bpy.types.VIEW3D_HT_header.append(_draw_viewport_header_extension)
        _header_appends.append(
            (bpy.types.VIEW3D_HT_header, _draw_viewport_header_extension)
        )
    except Exception as exc:
        warn(f"Could not append to 3D Viewport header: {exc}")

    log("UI panels and header strips registered.")


def unregister() -> None:
    """Unregister all UI classes and remove header extensions."""
    # Remove header appends first
    for header_cls, func in _header_appends:
        try:
            header_cls.remove(func)
        except Exception as exc:
            warn(f"Warning removing header append: {exc}")
    _header_appends.clear()

    if hasattr(bpy.types.Scene, 'ghost_tool_easing'):
        del bpy.types.Scene.ghost_tool_easing

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

    log("UI panels and header strips unregistered.")


# ---------------------------------------------------------------------------
# Test notes
# ---------------------------------------------------------------------------
#
# Test 1: N-panel strip
# >>> # Open 3D Viewport → N → Ghost Tool tab
# >>> # Should see: big on/off toggle, generate/clear, tool icons, display toggles
#
# Test 2: Timeline header
# >>> # Open Timeline or Dopesheet editor
# >>> # Ghost toggle icon should appear in the header bar on the right
# >>> # Click it — ghosts toggle on/off
#
# Test 3: Floating toolbar
# >>> bpy.ops.ghost_tool.floating_toolbar('INVOKE_DEFAULT')
# >>> # A popup window should appear with the full icon grid
#
# Test 4: 3D Viewport header
# >>> # Small ghost icon should appear in the 3D viewport header
# >>> # Next to the overlay/gizmo buttons
