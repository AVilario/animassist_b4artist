"""
modal_operator.py — GhostDragOperator: modal loop for interactive ghost dragging.

This module provides the primary interaction operator for Ghost Tool.
When invoked, it enters a modal loop that:
1. Detects which ghost is under the cursor via screen-space proximity
2. Lets the user drag the ghost in 3D space with axis constraints
3. Recalculates the f-curve in real time as the ghost moves
4. Confirms with left-click release, cancels with right-click or Escape
5. Pushes to Blender's undo stack on confirmation
"""

from __future__ import annotations

from typing import Optional

import bpy
from bpy_extras import view3d_utils
from mathutils import Vector, Matrix

from .ghost_data import Ghost, GhostStore
from . import fcurve_utils
from .utils import log, warn, debug


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_GRAB_RADIUS_PX: int = 20
"""Default screen-space radius in pixels for ghost picking."""

DRAG_SENSITIVITY: float = 0.1
"""Scaling factor for delta magnitude in non-location channel calculations."""

_CONSTRAINT_PLANE_NORMALS = {
    "YZ": Vector((1, 0, 0)),
    "XZ": Vector((0, 1, 0)),
    "XY": Vector((0, 0, 1)),
}
"""Map plane constraint names to their normal vectors."""

_AXIS_MASKS = {
    "X": (True, False, False),
    "Y": (False, True, False),
    "Z": (False, False, True),
}
"""Map single-axis constraint names to component masks (x, y, z)."""

_SINGLE_AXIS_FALLBACKS = {
    "X": Vector((0, 0, 1)),
    "Y": Vector((1, 0, 0)),
    "Z": Vector((0, 1, 0)),
}
"""Fallback normals when view is parallel to an axis constraint."""


# ---------------------------------------------------------------------------
# Helper: view and direction utilities
# ---------------------------------------------------------------------------

def _get_view_direction(region_3d: bpy.types.RegionView3D) -> Vector:
    """Extract the camera/view direction from the 3D region data.

    The view direction is the negative Z axis of the view matrix.

    Args:
        region_3d: The 3D region viewport data.

    Returns:
        Vector: Normalized view direction vector.
    """
    view_dir = Vector((region_3d.view_matrix[2][0], region_3d.view_matrix[2][1], region_3d.view_matrix[2][2]))
    view_dir.normalize()
    return view_dir


# ---------------------------------------------------------------------------
# Helper: screen-space projection
# ---------------------------------------------------------------------------

def _world_to_screen(
    context: bpy.types.Context,
    world_pos: Vector,
) -> Optional[tuple[float, float]]:
    """Project a 3D world-space point to 2D screen coordinates.

    Args:
        context: The current Blender context (must have a 3D region).
        world_pos: The point in world space.

    Returns:
        tuple[float, float] or None: Screen coordinates (x, y), or None
            if the point is behind the camera.
    """
    region = context.region
    region_3d = context.region_data
    if not region or not region_3d:
        return None

    screen_pos = view3d_utils.location_3d_to_region_2d(region, region_3d, world_pos)
    if screen_pos is None:
        return None
    return (screen_pos.x, screen_pos.y)


def _find_ghost_under_cursor(
    context: bpy.types.Context,
    mouse_x: int,
    mouse_y: int,
    grab_radius: int,
) -> Optional[Ghost]:
    """Find the closest ghost within grab_radius of the mouse position.

    Args:
        context: The current Blender context.
        mouse_x: Mouse X position in region coordinates.
        mouse_y: Mouse Y position in region coordinates.
        grab_radius: Maximum distance in pixels to consider a ghost hit.

    Returns:
        Ghost or None: The closest ghost, or None if none are within range.
    """
    store = GhostStore.get(context.scene)
    best_ghost: Optional[Ghost] = None
    best_dist_sq = grab_radius * grab_radius

    for ghost in store:
        screen_pos = _world_to_screen(context, ghost.world_position)
        if screen_pos is None:
            continue

        dx = screen_pos[0] - mouse_x
        dy = screen_pos[1] - mouse_y
        dist_sq = dx * dx + dy * dy

        if dist_sq < best_dist_sq:
            best_dist_sq = dist_sq
            best_ghost = ghost

    return best_ghost


# ---------------------------------------------------------------------------
# Helper: ray-plane intersection for 3D dragging
# ---------------------------------------------------------------------------

def _get_depth_plane(
    context: bpy.types.Context,
    point: Vector,
) -> tuple[Vector, Vector]:
    """Compute a view-facing plane through the given point.

    This plane is perpendicular to the view direction, passing through
    the point.  Used as the default drag constraint plane.

    Args:
        context: The current Blender context.
        point: A world-space point the plane should pass through.

    Returns:
        tuple: (plane_point, plane_normal) both as Vectors.
    """
    region_3d = context.region_data
    view_dir = _get_view_direction(region_3d)
    return (point.copy(), view_dir)


def _ray_plane_intersect(
    origin: Vector,
    direction: Vector,
    plane_point: Vector,
    plane_normal: Vector,
) -> Optional[Vector]:
    """Compute the intersection of a ray with a plane.

    Args:
        origin: Ray origin point.
        direction: Ray direction (does not need to be normalized).
        plane_point: A point on the plane.
        plane_normal: The plane normal vector.

    Returns:
        Vector or None: Intersection point, or None if ray is parallel.
    """
    denom = plane_normal.dot(direction)
    if abs(denom) < 1e-8:
        return None

    t = plane_normal.dot(plane_point - origin) / denom
    if t < 0:
        return None

    return origin + direction * t


def _get_constraint_plane(
    axis_constraint: str,
    ghost_pos: Vector,
    context: bpy.types.Context,
) -> tuple[Vector, Vector]:
    """Get the constraint plane based on the active axis constraint.

    For plane constraints (YZ, XZ, XY), returns a fixed normal.
    For single-axis constraints (X, Y, Z), projects the view direction
    onto the perpendicular plane to handle arbitrary viewing angles.

    Args:
        axis_constraint: One of "NONE", "X", "Y", "Z", "YZ", "XZ", "XY".
        ghost_pos: The ghost's current world position (plane passes through this).
        context: The current Blender context.

    Returns:
        tuple: (plane_point, plane_normal).
    """
    # Plane constraints: use fixed normals
    if axis_constraint in _CONSTRAINT_PLANE_NORMALS:
        normal = _CONSTRAINT_PLANE_NORMALS[axis_constraint].copy()
        return (ghost_pos.copy(), normal)

    # Single-axis constraints: project view direction onto the perpendicular plane
    if axis_constraint in ("X", "Y", "Z"):
        region_3d = context.region_data
        view_dir = _get_view_direction(region_3d)

        # Get the axis vector for this constraint
        axis_vector = Vector((1, 0, 0)) if axis_constraint == "X" else \
                      Vector((0, 1, 0)) if axis_constraint == "Y" else \
                      Vector((0, 0, 1))

        # Project view direction onto the plane perpendicular to the axis
        normal = view_dir - axis_vector * view_dir.dot(axis_vector)

        # If view is parallel to the axis, use a fallback normal
        if normal.length < 0.001:
            normal = _SINGLE_AXIS_FALLBACKS[axis_constraint].copy()
        else:
            normal.normalize()

        return (ghost_pos.copy(), normal)

    # No constraint — use the view-facing depth plane
    return _get_depth_plane(context, ghost_pos)


def _apply_axis_constraint(
    new_pos: Vector,
    original_pos: Vector,
    axis_constraint: str,
) -> Vector:
    """Apply an axis constraint to a position delta.

    For single-axis constraints (X, Y, Z), only the constrained axis
    component is kept. For plane constraints (YZ, XZ, XY), two axes
    are kept.

    Args:
        new_pos: The unconstrained new position.
        original_pos: The ghost's original position before dragging.
        axis_constraint: The active constraint.

    Returns:
        Vector: The constrained position.
    """
    # Single-axis constraints: keep only the constrained axis
    if axis_constraint in _AXIS_MASKS:
        mask_x, mask_y, mask_z = _AXIS_MASKS[axis_constraint]
        return Vector((
            new_pos.x if mask_x else original_pos.x,
            new_pos.y if mask_y else original_pos.y,
            new_pos.z if mask_z else original_pos.z,
        ))

    # Plane constraints: keep two axes
    if axis_constraint == "YZ":
        return Vector((original_pos.x, new_pos.y, new_pos.z))
    elif axis_constraint == "XZ":
        return Vector((new_pos.x, original_pos.y, new_pos.z))
    elif axis_constraint == "XY":
        return Vector((new_pos.x, new_pos.y, original_pos.z))

    # No constraint
    return new_pos.copy()


# ---------------------------------------------------------------------------
# GhostDragOperator
# ---------------------------------------------------------------------------

class GhostDragOperator(bpy.types.Operator):
    """Modal operator for dragging ghost markers in the 3D viewport.

    When invoked, this operator finds the ghost nearest to the mouse cursor
    and enters a modal loop.  The user drags the ghost in 3D space, with
    optional axis constraints, and the f-curve is recalculated in real time.

    Keybindings during modal:
        MOUSEMOVE — Update ghost position
        X/Y/Z — Activate single-axis constraint
        SHIFT+X/Y/Z — Activate plane constraint (perpendicular to that axis)
        LEFT MOUSE release — Confirm and push to undo
        RIGHT MOUSE or ESC — Cancel and restore original f-curve
    """

    bl_idname = "ghost_tool.drag_ghost"
    bl_label = "Drag Ghost"
    bl_options = {'REGISTER', 'UNDO'}

    # --- Internal state (not Blender properties — set during invoke) ---

    _active_ghost: Optional[Ghost] = None
    _original_position: Optional[Vector] = None
    _original_local_value: float = 0.0
    _axis_constraint: str = "NONE"
    _undo_snapshots: dict[str, list[dict]] = {}  # fcurve_key -> snapshot
    _affected_fcurves: dict[str, bpy.types.FCurve] = {}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        """Check if the operator can run.

        Requires an active scene with ghost_tool settings and at least
        one ghost in the store.

        Args:
            context: The current Blender context.

        Returns:
            bool: True if the operator can execute.
        """
        scene = context.scene
        if not hasattr(scene, 'ghost_tool'):
            return False
        if not scene.ghost_tool.is_active:
            return False
        store = GhostStore.get(scene)
        return len(store) > 0

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        """Begin the modal ghost drag operation.

        Identifies the ghost under the cursor, snapshots affected f-curves,
        and enters modal mode.

        Args:
            context: The current Blender context.
            event: The triggering event.

        Returns:
            set[str]: {'RUNNING_MODAL'} on success, {'CANCELLED'} if no ghost found.
        """
        settings = context.scene.ghost_tool
        grab_radius = settings.grab_radius

        # Find ghost under cursor
        ghost = _find_ghost_under_cursor(
            context, event.mouse_region_x, event.mouse_region_y, grab_radius
        )

        if ghost is None:
            self.report({'WARNING'}, "No ghost under cursor")
            return {'CANCELLED'}

        self._active_ghost = ghost
        self._original_position = ghost.world_position.copy()
        self._original_local_value = ghost.local_value
        self._axis_constraint = "NONE"

        # Snapshot the affected f-curves for undo on cancel
        self._undo_snapshots = {}
        self._affected_fcurves = {}

        obj = bpy.data.objects.get(ghost.object_name)
        if obj:
            fcurve = fcurve_utils.resolve_fcurve(obj, ghost.bone_name, ghost.channel)
            if fcurve:
                fc_key = f"{ghost.object_name}:{ghost.bone_name}:{ghost.channel}"
                self._undo_snapshots[fc_key] = fcurve_utils.snapshot_fcurve(fcurve)
                self._affected_fcurves[fc_key] = fcurve

        # Mark ghost as selected for visual feedback
        ghost.is_selected = True

        context.window_manager.modal_handler_add(self)
        context.area.tag_redraw()

        return {'RUNNING_MODAL'}

    def modal(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        """Handle events during the modal drag loop.

        Args:
            context: The current Blender context.
            event: The current event.

        Returns:
            set[str]: Modal state ('RUNNING_MODAL', 'FINISHED', 'CANCELLED').
        """
        ghost = self._active_ghost
        if ghost is None:
            return {'CANCELLED'}

        # --- Axis constraint keys ---
        if event.type in {'X', 'Y', 'Z'} and event.value == 'PRESS':
            axis = event.type  # "X", "Y", or "Z"

            if event.shift:
                # SHIFT+axis → plane constraint (perpendicular to that axis)
                plane_map = {"X": "YZ", "Y": "XZ", "Z": "XY"}
                new_constraint = plane_map[axis]
            else:
                new_constraint = axis

            # Toggle: pressing the same constraint again removes it
            if self._axis_constraint == new_constraint:
                self._axis_constraint = "NONE"
            else:
                self._axis_constraint = new_constraint

            self.report({'INFO'}, f"Constraint: {self._axis_constraint}")
            return {'RUNNING_MODAL'}

        # --- Mouse movement: update ghost position ---
        if event.type == 'MOUSEMOVE':
            self._update_ghost_position(context, event)
            context.area.tag_redraw()
            return {'RUNNING_MODAL'}

        # --- Confirm drag with left mouse release ---
        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self._confirm_drag(context)
            return {'FINISHED'}

        # --- Cancel drag with right mouse or Escape ---
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self._cancel_drag(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def _update_ghost_position(
        self,
        context: bpy.types.Context,
        event: bpy.types.Event,
    ) -> None:
        """Update the ghost's world position based on cursor movement.

        Casts a ray from the mouse into the scene, intersects it with
        the constraint plane, and moves the ghost to the hit point.

        Args:
            context: The current Blender context.
            event: The mouse move event.
        """
        ghost = self._active_ghost
        if ghost is None:
            return

        region = context.region
        region_3d = context.region_data
        if not region or not region_3d:
            return

        mouse_pos = (event.mouse_region_x, event.mouse_region_y)

        # Build ray from mouse position
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, region_3d, mouse_pos)
        ray_direction = view3d_utils.region_2d_to_vector_3d(region, region_3d, mouse_pos)

        # Get the constraint plane
        plane_point, plane_normal = _get_constraint_plane(
            self._axis_constraint, self._original_position, context
        )

        # Intersect ray with plane
        hit = _ray_plane_intersect(ray_origin, ray_direction, plane_point, plane_normal)
        if hit is None:
            return

        # Apply axis constraint to the hit point
        constrained_pos = _apply_axis_constraint(
            hit, self._original_position, self._axis_constraint
        )

        # Update ghost data
        ghost.world_position = constrained_pos

        # Convert world position delta back to f-curve value.
        # We approximate this by computing the value offset based on the
        # channel axis.  For location channels, the mapping is direct.
        # For rotation/scale, a more sophisticated conversion is needed.
        self._update_fcurve_from_position(context, ghost, constrained_pos)

    def _update_fcurve_from_position(
        self,
        context: bpy.types.Context,
        ghost: Ghost,
        new_world_pos: Vector,
    ) -> None:
        """Recalculate the f-curve to match the ghost's new world position.

        For location channels, the world-space delta is converted to
        local space and applied directly.  For other channel types,
        a proportional approximation is used.

        Args:
            context: The current Blender context.
            ghost: The ghost being moved.
            new_world_pos: The ghost's new world-space position.
        """
        obj = bpy.data.objects.get(ghost.object_name)
        if not obj:
            return

        fcurve = fcurve_utils.resolve_fcurve(obj, ghost.bone_name, ghost.channel)
        if fcurve is None:
            return

        # Determine which value axis this channel represents
        channel_lower = ghost.channel.lower()

        if "location" in channel_lower:
            # For location channels, compute the local-space value from world pos
            delta_world = new_world_pos - self._original_position

            # Convert world delta to object local space
            if obj.parent:
                inv_parent = obj.parent.matrix_world.inverted()
                delta_local = inv_parent.to_3x3() @ delta_world
            else:
                delta_local = delta_world.copy()

            # If this is a bone channel, convert to bone local space
            if ghost.bone_name and obj.type == 'ARMATURE':
                pose_bone = obj.pose.bones.get(ghost.bone_name)
                if pose_bone and pose_bone.parent:
                    inv_bone = pose_bone.parent.matrix.inverted().to_3x3()
                    delta_local = inv_bone @ delta_world
                elif pose_bone:
                    inv_obj = obj.matrix_world.inverted().to_3x3()
                    delta_local = inv_obj @ delta_world

            # Extract the relevant axis component
            if channel_lower.endswith(".x"):
                new_value = self._original_local_value + delta_local.x
            elif channel_lower.endswith(".y"):
                new_value = self._original_local_value + delta_local.y
            elif channel_lower.endswith(".z"):
                new_value = self._original_local_value + delta_local.z
            else:
                new_value = self._original_local_value + delta_local.length
        else:
            # For non-location channels, use a proportional approximation.
            # The world-space delta magnitude is mapped to a value change.
            delta = new_world_pos - self._original_position
            new_value = self._original_local_value + delta.length * DRAG_SENSITIVITY

        # Recalculate the f-curve handles
        mode = context.scene.ghost_tool.curve_mode.lower()
        fcurve_utils.recalculate_handles(fcurve, ghost.frame, new_value, mode=mode)

        # Update the ghost's local value
        ghost.local_value = new_value

    def _confirm_drag(self, context: bpy.types.Context) -> None:
        """Finalize the drag operation.

        Pushes the change to Blender's undo stack and deselects the ghost.
        Fires any registered ghost-moved callbacks via the API.

        Args:
            context: The current Blender context.
        """
        ghost = self._active_ghost
        if ghost:
            ghost.is_selected = False

            # Fire callbacks for external addon integration
            try:
                from . import api as ghost_api
                ghost_api._fire_ghost_moved(ghost.uid)
            except Exception as exc:
                debug(f"Ghost moved callback error: {exc}")

        # Push to undo stack
        bpy.ops.ed.undo_push(message="Ghost Tool: Move Ghost")

        self._cleanup()
        context.area.tag_redraw()

    def _cancel_drag(self, context: bpy.types.Context) -> None:
        """Cancel the drag operation and restore original f-curve state.

        All affected f-curves are reverted to their pre-drag snapshots.

        Args:
            context: The current Blender context.
        """
        ghost = self._active_ghost
        if ghost:
            # Restore ghost position
            ghost.world_position = self._original_position.copy()
            ghost.local_value = self._original_local_value
            ghost.is_selected = False

        # Restore all affected f-curves
        for fc_key, snapshot in self._undo_snapshots.items():
            fc = self._affected_fcurves.get(fc_key)
            if fc:
                fcurve_utils.restore_fcurve(fc, snapshot)

        self._cleanup()
        context.area.tag_redraw()
        self.report({'INFO'}, "Ghost drag cancelled")

    def _cleanup(self) -> None:
        """Reset internal state after drag completion or cancellation."""
        self._active_ghost = None
        self._original_position = None
        self._original_local_value = 0.0
        self._axis_constraint = "NONE"
        self._undo_snapshots = {}
        self._affected_fcurves = {}


# ---------------------------------------------------------------------------
# Generate Ghosts Operator
# ---------------------------------------------------------------------------

class GHOST_OT_generate(bpy.types.Operator):
    """Generate ghost markers for the active object and selected bones.

    Samples f-curves at midpoints between keyframes and creates Ghost
    objects for visualization and manipulation.
    """

    bl_idname = "ghost_tool.generate_ghosts"
    bl_label = "Generate Ghosts"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        """Require an active object with animation data.

        Args:
            context: The current Blender context.

        Returns:
            bool: True if generation can proceed.
        """
        obj = context.active_object
        if not obj:
            return False
        if not obj.animation_data or not obj.animation_data.action:
            return False
        return True

    def execute(self, context: bpy.types.Context) -> set[str]:
        """Run ghost generation via the pipeline.

        Args:
            context: The current Blender context.

        Returns:
            set[str]: {'FINISHED'} on success.
        """
        from .ghost_data import LOCATION_CHANNELS
        from .ghost_pipeline import GhostPipeline

        obj = context.active_object
        settings = context.scene.ghost_tool

        # Determine bones to process
        bones: list[str] = []
        armature = None

        if obj.type == 'ARMATURE':
            armature = obj
            # Use selected pose bones, or all if none selected
            if context.selected_pose_bones:
                bones = [b.name for b in context.selected_pose_bones]
            elif obj.pose and obj.pose.bones:
                # Fallback: try pose bones with selection, or use all bones
                bones = [
                    b.name for b in obj.pose.bones
                    if getattr(b.bone, 'select', False)
                ]
                if not bones:
                    bones = [b.name for b in obj.pose.bones]

        # Determine frame range from range_mode settings
        frame_range = None
        range_mode = getattr(settings, 'ghost_range_mode', 'AROUND_CURSOR')

        if range_mode == "CUSTOM":
            frame_range = (settings.custom_range_start, settings.custom_range_end)
        elif range_mode == "FULL_TIMELINE":
            frame_range = (context.scene.frame_start, context.scene.frame_end)
        # AROUND_CURSOR and BETWEEN_KEYS are handled inside the pipeline

        # Generate for location channels by default
        channels = LOCATION_CHANNELS

        # Route through the pipeline for cache awareness
        pipeline = GhostPipeline.get(context.scene)
        count = pipeline.generate_manual(
            context=context,
            obj=obj,
            armature=armature,
            bones=bones,
            channels=channels,
            level=settings.subdivision_level,
            frame_range=frame_range,
            clear_existing=True,
        )

        # Activate display
        settings.is_active = True

        mode_label = getattr(settings, 'ghost_mode', 'SUBDIVISION')
        range_label = range_mode.replace('_', ' ').title()
        self.report({'INFO'}, f"Generated {count} ghosts ({mode_label}, {range_label})")
        context.area.tag_redraw()
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Clear Ghosts Operator
# ---------------------------------------------------------------------------

class GHOST_OT_clear(bpy.types.Operator):
    """Remove all ghosts from the current scene."""

    bl_idname = "ghost_tool.clear_ghosts"
    bl_label = "Clear All Ghosts"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: bpy.types.Context) -> set[str]:
        """Clear the ghost store, cache, and any mesh ghosts.

        Args:
            context: The current Blender context.

        Returns:
            set[str]: {'FINISHED'}.
        """
        from .ghost_pipeline import GhostPipeline

        # Clear point ghosts via pipeline (also clears cache)
        pipeline = GhostPipeline.get(context.scene)
        count = pipeline.clear(context)

        # Also clear mesh ghosts if they exist
        try:
            from .mesh_ghosts import clear_mesh_ghosts
            mesh_count = clear_mesh_ghosts(context)
            if mesh_count > 0:
                count += mesh_count
        except ImportError:
            debug("mesh_ghosts module not available for clear")

        self.report({'INFO'}, f"Cleared {count} ghosts")
        context.area.tag_redraw()
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Pin / Unpin Ghost Operators
# ---------------------------------------------------------------------------

class GHOST_OT_pin_ghost(bpy.types.Operator):
    """Toggle pin state on the ghost nearest to the cursor."""

    bl_idname = "ghost_tool.pin_ghost"
    bl_label = "Pin/Unpin Ghost"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        """Require active ghost display.

        Args:
            context: The current Blender context.

        Returns:
            bool: True if ghost display is active.
        """
        return hasattr(context.scene, 'ghost_tool') and context.scene.ghost_tool.is_active

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event) -> set[str]:
        """Find and toggle the pin state of the nearest ghost.

        Args:
            context: The current Blender context.
            event: The triggering event.

        Returns:
            set[str]: {'FINISHED'} or {'CANCELLED'}.
        """
        settings = context.scene.ghost_tool
        ghost = _find_ghost_under_cursor(
            context, event.mouse_region_x, event.mouse_region_y,
            settings.grab_radius,
        )

        if ghost is None:
            self.report({'WARNING'}, "No ghost under cursor to pin")
            return {'CANCELLED'}

        ghost.is_pinned = not ghost.is_pinned
        state = "pinned" if ghost.is_pinned else "unpinned"
        self.report({'INFO'}, f"Ghost {state} at frame {ghost.frame:.1f}")
        context.area.tag_redraw()
        return {'FINISHED'}


class GHOST_OT_unpin_all(bpy.types.Operator):
    """Unpin all pinned ghosts in the current scene."""

    bl_idname = "ghost_tool.unpin_all"
    bl_label = "Unpin All Ghosts"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: bpy.types.Context) -> set[str]:
        """Unpin every ghost.

        Args:
            context: The current Blender context.

        Returns:
            set[str]: {'FINISHED'}.
        """
        store = GhostStore.get(context.scene)
        count = 0
        for ghost in store:
            if ghost.is_pinned:
                ghost.is_pinned = False
                count += 1
        self.report({'INFO'}, f"Unpinned {count} ghosts")
        context.area.tag_redraw()
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

CLASSES: tuple[type, ...] = (
    GhostDragOperator,
    GHOST_OT_generate,
    GHOST_OT_clear,
    GHOST_OT_pin_ghost,
    GHOST_OT_unpin_all,
)


def register() -> None:
    """Register all modal operator classes."""
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister() -> None:
    """Unregister all modal operator classes."""
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


# ---------------------------------------------------------------------------
# Test notes
# ---------------------------------------------------------------------------
#
# Test 1: Operator poll
# >>> # With a cube with 3 keyframes and ghosts generated:
# >>> bpy.ops.ghost_tool.drag_ghost('INVOKE_DEFAULT')
# >>> # Should enter modal mode if cursor is near a ghost
#
# Test 2: Axis constraints
# >>> # During drag, press X → ghost should only move along X axis
# >>> # Press SHIFT+X → ghost moves in YZ plane
# >>> # Press X again → constraint released
#
# Test 3: Cancel restores original
# >>> # Drag a ghost, then press ESC
# >>> # F-curve should return to pre-drag state
#
# Test 4: Undo after confirm
# >>> # Drag and release left mouse → Ctrl+Z should undo the move
