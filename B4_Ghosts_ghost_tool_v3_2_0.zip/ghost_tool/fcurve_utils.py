"""
fcurve_utils.py — F-curve sampling, handle recalculation, and overshoot prevention.

This module provides all f-curve manipulation functions used by Ghost Tool.
It handles reading curve values, finding adjacent keyframes, recalculating
bezier handles when a ghost is moved, and applying easing presets.

All f-curve writes are designed to be non-destructive: handles are adjusted
but keyframes are never added or removed unless explicitly requested.
"""

from __future__ import annotations

import math
from typing import Optional

import bpy
from mathutils import Vector

from .utils import log, warn, debug


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HANDLE_CLAMP_FACTOR: float = 0.4
"""Maximum fraction of the segment width that a handle can extend.

This prevents overshooting oscillation when handles are adjusted to pass
through a new ghost position.  0.4 means a handle can extend at most 40%
of the frame distance to the adjacent keyframe.
"""

HANDLE_MIN_LENGTH: float = 0.01
"""Minimum handle length to prevent degenerate zero-length handles."""

CONVERGENCE_THRESHOLD: float = 0.001
"""Tolerance for convergence in handle recalculation iterations."""

MAX_CONVERGENCE_ITERATIONS: int = 5
"""Maximum number of iterations for convergence in free mode."""


# ---------------------------------------------------------------------------
# F-curve Sampling
# ---------------------------------------------------------------------------

def sample_fcurve(fcurve: bpy.types.FCurve, frame: float) -> float:
    """Return the f-curve's interpolated value at the given frame.

    Args:
        fcurve: The f-curve to sample. May be None.
        frame: The frame number to evaluate at.

    Returns:
        float: The curve value at the frame, or 0.0 if the fcurve is None.
    """
    if fcurve is None:
        warn("sample_fcurve called with None fcurve, returning 0.0")
        return 0.0
    try:
        return fcurve.evaluate(frame)
    except Exception as exc:
        warn(f"Failed to evaluate fcurve at frame {frame}: {exc}")
        return 0.0


# ---------------------------------------------------------------------------
# Keyframe Lookup
# ---------------------------------------------------------------------------

def get_adjacent_keyframes(
    fcurve: bpy.types.FCurve,
    frame: float,
) -> tuple[Optional[bpy.types.Keyframe], Optional[bpy.types.Keyframe]]:
    """Return the keyframes immediately before and after the given frame.

    Args:
        fcurve: The f-curve to search.
        frame: The frame number to look around.

    Returns:
        tuple: (left_keyframe, right_keyframe).  Either may be None if
               the frame is before the first or after the last keyframe.
    """
    if fcurve is None:
        return (None, None)

    keyframes = sorted(fcurve.keyframe_points, key=lambda kp: kp.co.x)

    left: Optional[bpy.types.Keyframe] = None
    right: Optional[bpy.types.Keyframe] = None

    for kp in keyframes:
        if kp.co.x < frame:
            left = kp
        elif kp.co.x > frame:
            right = kp
            break

    return (left, right)


def get_keyframe_at_frame(
    fcurve: bpy.types.FCurve,
    frame: float,
    tolerance: float = 0.01,
) -> Optional[bpy.types.Keyframe]:
    """Find a keyframe at or very near the given frame.

    Args:
        fcurve: The f-curve to search.
        frame: Target frame number.
        tolerance: Maximum frame distance to consider a match.

    Returns:
        Keyframe or None: The matching keyframe point, if found.
    """
    if fcurve is None:
        return None
    for kp in fcurve.keyframe_points:
        if abs(kp.co.x - frame) <= tolerance:
            return kp
    return None


# ---------------------------------------------------------------------------
# Handle Recalculation
# ---------------------------------------------------------------------------

def recalculate_handles(
    fcurve: bpy.types.FCurve,
    frame: float,
    new_value: float,
    mode: str = "free",
) -> bool:
    """Modify an f-curve so it passes through new_value at the given frame.

    This is the core function called when a ghost is dragged to a new
    position.  It adjusts the bezier handles of the surrounding keyframes
    to reshape the curve segment without adding or removing keyframes.

    Three modes are supported:
        - "free": Handles adjust both angle and length to hit the target.
        - "locked": Handle angles are preserved; only lengths change.
        - "smooth": Handle influence is redistributed evenly across the segment.

    Args:
        fcurve: The f-curve to modify.
        frame: The frame where the new value should appear.
        new_value: The desired f-curve value at this frame.
        mode: One of "free", "locked", "smooth".

    Returns:
        bool: True if the recalculation succeeded, False otherwise.
    """
    if fcurve is None:
        warn("recalculate_handles called with None fcurve")
        return False

    left_kp, right_kp = get_adjacent_keyframes(fcurve, frame)
    if left_kp is None or right_kp is None:
        warn(f"Cannot recalculate handles at frame {frame} — missing adjacent keyframes.")
        return False

    try:
        if mode == "free":
            _recalc_free(fcurve, left_kp, right_kp, frame, new_value)
        elif mode == "locked":
            _recalc_locked(fcurve, left_kp, right_kp, frame, new_value)
        elif mode == "smooth":
            _recalc_smooth(fcurve, left_kp, right_kp, frame, new_value)
        else:
            warn(f"Unknown curve mode '{mode}', using 'free'")
            _recalc_free(fcurve, left_kp, right_kp, frame, new_value)

        # Clamp handles to prevent overshoot
        _clamp_handles(left_kp, right_kp)

        fcurve.update()
        return True

    except Exception as exc:
        warn(f"Error during handle recalculation: {exc}")
        return False


def _recalc_free(
    fcurve: bpy.types.FCurve,
    left_kp: bpy.types.Keyframe,
    right_kp: bpy.types.Keyframe,
    frame: float,
    new_value: float,
) -> None:
    """Free mode: adjust handle angles and lengths to pass through the target.

    This uses a simple proportional offset approach.  The current
    midpoint value is compared to the desired value, and the handle
    offsets are adjusted proportionally.

    Args:
        fcurve: The f-curve being modified.
        left_kp: The keyframe to the left of the target frame.
        right_kp: The keyframe to the right of the target frame.
        frame: The target frame.
        new_value: The desired value at the target frame.
    """
    # Set handles to FREE type so we can manipulate them directly
    left_kp.handle_right_type = 'FREE'
    right_kp.handle_left_type = 'FREE'

    # Current value at the target frame
    current_value = fcurve.evaluate(frame)
    delta = new_value - current_value

    if abs(delta) < 1e-7:
        return

    # Parametric position of the frame within the segment [0..1]
    segment_width = right_kp.co.x - left_kp.co.x
    if segment_width < 0.001:
        return
    t = (frame - left_kp.co.x) / segment_width

    # Distribute the correction to both handles based on parametric position.
    # The closer handle gets more influence (complement weighting).
    left_influence = 1.0 - t
    right_influence = t

    # Adjust left keyframe's right handle (controls the exit from left KP)
    left_kp.handle_right[1] += delta * left_influence * 0.75
    # Adjust right keyframe's left handle (controls the entry to right KP)
    right_kp.handle_left[1] += delta * right_influence * 0.75

    # Iterate to converge on the target value, since bezier
    # handle adjustments don't map linearly to midpoint values.
    for _ in range(MAX_CONVERGENCE_ITERATIONS):
        fcurve.update()
        current_value = fcurve.evaluate(frame)
        residual = new_value - current_value

        if abs(residual) < CONVERGENCE_THRESHOLD:
            break

        left_kp.handle_right[1] += residual * left_influence * 0.5
        right_kp.handle_left[1] += residual * right_influence * 0.5


def _recalc_locked(
    fcurve: bpy.types.FCurve,
    left_kp: bpy.types.Keyframe,
    right_kp: bpy.types.Keyframe,
    frame: float,
    new_value: float,
) -> None:
    """Locked mode: preserve handle angles, only adjust handle lengths.

    The direction from each keyframe to its handle is preserved, but the
    handle is extended or shortened to make the curve pass through the
    target value.

    Args:
        fcurve: The f-curve being modified.
        left_kp: The keyframe to the left of the target frame.
        right_kp: The keyframe to the right of the target frame.
        frame: The target frame.
        new_value: The desired value at the target frame.
    """
    left_kp.handle_right_type = 'FREE'
    right_kp.handle_left_type = 'FREE'

    current_value = fcurve.evaluate(frame)
    delta = new_value - current_value

    if abs(delta) < 1e-7:
        return

    segment_width = right_kp.co.x - left_kp.co.x
    if segment_width < 0.001:
        return
    t = (frame - left_kp.co.x) / segment_width

    # Compute handle direction vectors (from keyframe to handle tip)
    left_handle_dir = Vector((
        left_kp.handle_right[0] - left_kp.co.x,
        left_kp.handle_right[1] - left_kp.co.y,
    ))
    right_handle_dir = Vector((
        right_kp.handle_left[0] - right_kp.co.x,
        right_kp.handle_left[1] - right_kp.co.y,
    ))

    left_len = left_handle_dir.length
    right_len = right_handle_dir.length

    if left_len < HANDLE_MIN_LENGTH or right_len < HANDLE_MIN_LENGTH:
        # Fall back to free mode if handles are degenerate
        _recalc_free(fcurve, left_kp, right_kp, frame, new_value)
        return

    # Normalize directions
    left_dir_norm = left_handle_dir / left_len
    right_dir_norm = right_handle_dir / right_len

    # Scale handles proportionally to close the gap
    for _ in range(8):
        fcurve.update()
        current_value = fcurve.evaluate(frame)
        residual = new_value - current_value
        if abs(residual) < CONVERGENCE_THRESHOLD:
            break

        # Scale factor: how much to stretch handles to achieve the residual
        scale_left = 1.0 + (residual * (1.0 - t) * 0.3) / max(abs(left_len), 0.1)
        scale_right = 1.0 + (residual * t * 0.3) / max(abs(right_len), 0.1)

        # Clamp scale to prevent extreme handle lengths
        scale_left = max(0.1, min(scale_left, 3.0))
        scale_right = max(0.1, min(scale_right, 3.0))

        new_left_handle = left_dir_norm * (left_len * scale_left)
        new_right_handle = right_dir_norm * (right_len * scale_right)

        left_kp.handle_right[0] = left_kp.co.x + new_left_handle.x
        left_kp.handle_right[1] = left_kp.co.y + new_left_handle.y
        right_kp.handle_left[0] = right_kp.co.x + new_right_handle.x
        right_kp.handle_left[1] = right_kp.co.y + new_right_handle.y

        left_len = new_left_handle.length
        right_len = new_right_handle.length


def _recalc_smooth(
    fcurve: bpy.types.FCurve,
    left_kp: bpy.types.Keyframe,
    right_kp: bpy.types.Keyframe,
    frame: float,
    new_value: float,
) -> None:
    """Smooth mode: redistribute handle influence evenly across the segment.

    Both handles are reset to a balanced configuration first, then
    adjusted symmetrically to hit the target value.

    Args:
        fcurve: The f-curve being modified.
        left_kp: The keyframe to the left of the target frame.
        right_kp: The keyframe to the right of the target frame.
        frame: The target frame.
        new_value: The desired value at the target frame.
    """
    left_kp.handle_right_type = 'FREE'
    right_kp.handle_left_type = 'FREE'

    segment_width = right_kp.co.x - left_kp.co.x
    if segment_width < 0.001:
        return

    # Reset handles to a smooth balanced state (1/3 of segment width)
    one_third = segment_width / 3.0
    value_diff = right_kp.co.y - left_kp.co.y
    slope = value_diff / segment_width

    left_kp.handle_right[0] = left_kp.co.x + one_third
    left_kp.handle_right[1] = left_kp.co.y + slope * one_third

    right_kp.handle_left[0] = right_kp.co.x - one_third
    right_kp.handle_left[1] = right_kp.co.y - slope * one_third

    # Now iteratively adjust to hit the target
    for _ in range(8):
        fcurve.update()
        current_value = fcurve.evaluate(frame)
        residual = new_value - current_value
        if abs(residual) < CONVERGENCE_THRESHOLD:
            break

        # Apply correction symmetrically to both handles
        correction = residual * 0.4
        left_kp.handle_right[1] += correction
        right_kp.handle_left[1] += correction


def _clamp_handles(
    left_kp: bpy.types.Keyframe,
    right_kp: bpy.types.Keyframe,
) -> None:
    """Clamp handle lengths to prevent overshoot and oscillation.

    Ensures that handles don't extend beyond a fraction of the segment
    width, which would cause the curve to overshoot the keyframe values.

    Args:
        left_kp: The left keyframe of the segment.
        right_kp: The right keyframe of the segment.
    """
    segment_width = right_kp.co.x - left_kp.co.x
    max_extend = segment_width * HANDLE_CLAMP_FACTOR

    if max_extend < HANDLE_MIN_LENGTH:
        return

    # Clamp left keyframe's right handle (shouldn't extend past the midpoint)
    handle_dx = left_kp.handle_right[0] - left_kp.co.x
    if handle_dx > max_extend:
        scale = max_extend / handle_dx
        left_kp.handle_right[0] = left_kp.co.x + max_extend
        # Scale the Y proportionally to preserve angle
        handle_dy = left_kp.handle_right[1] - left_kp.co.y
        left_kp.handle_right[1] = left_kp.co.y + handle_dy * scale
    elif handle_dx < 0:
        # Handle pointing backward — force it forward with minimum length
        left_kp.handle_right[0] = left_kp.co.x + HANDLE_MIN_LENGTH

    # Clamp right keyframe's left handle (shouldn't extend past the midpoint)
    handle_dx = right_kp.handle_left[0] - right_kp.co.x
    if handle_dx < -max_extend:
        scale = max_extend / abs(handle_dx)
        right_kp.handle_left[0] = right_kp.co.x - max_extend
        handle_dy = right_kp.handle_left[1] - right_kp.co.y
        right_kp.handle_left[1] = right_kp.co.y + handle_dy * scale
    elif handle_dx > 0:
        # Handle pointing forward — force it backward
        right_kp.handle_left[0] = right_kp.co.x - HANDLE_MIN_LENGTH


# ---------------------------------------------------------------------------
# World Position Evaluation
# ---------------------------------------------------------------------------

# Frame evaluation cache: avoids calling scene.frame_set multiple times
# for the same frame during a single operation pass.
_frame_cache: dict[int, dict[str, Vector]] = {}


def clear_frame_cache() -> None:
    """Clear the world position evaluation cache.

    Should be called at the start of each ghost generation or drag update
    cycle to prevent stale data.
    """
    _frame_cache.clear()


def get_world_position_at_frame(
    obj: bpy.types.Object,
    bone_name: str,
    channel: str,
    frame: float,
) -> Vector:
    """Get the world-space position of an object or bone at a given frame.

    Temporarily sets the scene frame, evaluates the pose, and returns
    the world position.  Results are cached per frame to minimize the
    cost of repeated scene.frame_set() calls.

    Args:
        obj: The Blender object (armature or mesh).
        bone_name: The pose bone name, or empty string for object origin.
        channel: The channel identifier (used only for cache keying).
        frame: The frame to evaluate at.

    Returns:
        Vector: World-space position of the bone head or object origin.
    """
    scene = bpy.context.scene

    # Build a cache key
    int_frame = int(frame)
    subframe = frame - int_frame
    cache_key = f"{obj.name}:{bone_name}"

    if int_frame in _frame_cache and cache_key in _frame_cache[int_frame]:
        return _frame_cache[int_frame][cache_key].copy()

    # Save current frame
    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe if hasattr(scene, 'frame_subframe') else 0.0

    try:
        scene.frame_set(int_frame, subframe=subframe)
        depsgraph = bpy.context.evaluated_depsgraph_get()
        depsgraph.update()

        if bone_name and obj.type == 'ARMATURE':
            pose_bone = obj.pose.bones.get(bone_name)
            if pose_bone:
                world_pos = obj.matrix_world @ pose_bone.head.copy()
            else:
                warn(f"Bone '{bone_name}' not found on '{obj.name}'")
                world_pos = obj.matrix_world.translation.copy()
        else:
            world_pos = obj.matrix_world.translation.copy()

        # Cache the result
        if int_frame not in _frame_cache:
            _frame_cache[int_frame] = {}
        _frame_cache[int_frame][cache_key] = world_pos.copy()

        return world_pos.copy()

    except Exception as exc:
        warn(f"Error evaluating world position at frame {frame}: {exc}")
        return Vector((0.0, 0.0, 0.0))

    finally:
        # Always restore the original frame
        scene.frame_set(original_frame)


# ---------------------------------------------------------------------------
# F-curve Snapshot for Undo Support
# ---------------------------------------------------------------------------

def snapshot_fcurve(fcurve: bpy.types.FCurve) -> list[dict]:
    """Capture the current state of an f-curve's keyframes and handles.

    Used before a ghost drag to enable cancellation / undo.

    Args:
        fcurve: The f-curve to snapshot.

    Returns:
        list[dict]: A list of dicts, one per keyframe, containing all
                    editable properties (co, handles, types, interpolation).
    """
    if fcurve is None:
        return []

    snapshot = []
    for kp in fcurve.keyframe_points:
        snapshot.append({
            "co": (kp.co.x, kp.co.y),
            "handle_left": (kp.handle_left[0], kp.handle_left[1]),
            "handle_right": (kp.handle_right[0], kp.handle_right[1]),
            "handle_left_type": kp.handle_left_type,
            "handle_right_type": kp.handle_right_type,
            "interpolation": kp.interpolation,
            "easing": kp.easing if hasattr(kp, 'easing') else 'AUTO',
        })
    return snapshot


def restore_fcurve(fcurve: bpy.types.FCurve, snapshot: list[dict]) -> bool:
    """Restore an f-curve to a previously captured snapshot state.

    Args:
        fcurve: The f-curve to restore.
        snapshot: The snapshot data from snapshot_fcurve().

    Returns:
        bool: True if restoration succeeded, False otherwise.
    """
    if fcurve is None or not snapshot:
        return False

    try:
        keyframes = fcurve.keyframe_points
        if len(keyframes) != len(snapshot):
            warn(f"Keyframe count mismatch during restore ({len(keyframes)} vs {len(snapshot)}). Restoring what we can.")

        for i, kp_data in enumerate(snapshot):
            if i >= len(keyframes):
                break

            kp = keyframes[i]
            kp.co.x = kp_data["co"][0]
            kp.co.y = kp_data["co"][1]
            kp.handle_left[0] = kp_data["handle_left"][0]
            kp.handle_left[1] = kp_data["handle_left"][1]
            kp.handle_right[0] = kp_data["handle_right"][0]
            kp.handle_right[1] = kp_data["handle_right"][1]
            kp.handle_left_type = kp_data["handle_left_type"]
            kp.handle_right_type = kp_data["handle_right_type"]
            kp.interpolation = kp_data["interpolation"]
            if hasattr(kp, 'easing'):
                kp.easing = kp_data.get("easing", 'AUTO')

        fcurve.update()
        return True

    except Exception as exc:
        warn(f"Error restoring fcurve snapshot: {exc}")
        return False


# ---------------------------------------------------------------------------
# F-curve Channel Resolution
# ---------------------------------------------------------------------------

def resolve_fcurve(
    obj: bpy.types.Object,
    bone_name: str,
    channel: str,
) -> Optional[bpy.types.FCurve]:
    """Resolve a bone/channel pair to an actual FCurve on the object's action.

    Compatible with both legacy (Blender < 4.4) and slotted (5.x+) Actions.

    Args:
        obj: The Blender object (must have animation data with an action).
        bone_name: Pose bone name, or empty string for object channels.
        channel: Channel identifier like "location.x" or "rotation_euler.z".

    Returns:
        FCurve or None: The resolved f-curve, or None if not found.
    """
    from .utils import find_fcurve_in_action

    if not obj or not obj.animation_data or not obj.animation_data.action:
        return None

    action = obj.animation_data.action
    axis_map = {"x": 0, "y": 1, "z": 2, "w": 3}

    parts = channel.rsplit(".", 1)
    if len(parts) == 2:
        prop_name = parts[0]
        axis = parts[1].lower()
        array_index = axis_map.get(axis, 0)
    else:
        prop_name = channel
        array_index = 0

    if bone_name:
        data_path = f'pose.bones["{bone_name}"].{prop_name}'
    else:
        data_path = prop_name

    # Use the compatibility helper that handles both legacy and slotted APIs
    return find_fcurve_in_action(action, data_path, array_index, obj=obj)


# ---------------------------------------------------------------------------
# Easing Preset Application (delegates to easing_presets module)
# ---------------------------------------------------------------------------

def apply_easing_preset(
    fcurve: bpy.types.FCurve,
    frame_a: float,
    frame_b: float,
    preset_name: str,
) -> bool:
    """Apply a named easing preset to the f-curve handles between two keyframes.

    This function delegates to easing_presets.apply_preset_to_range() but
    provides a stable interface for use by other Ghost Tool modules.

    Args:
        fcurve: The f-curve to modify.
        frame_a: Frame of the left keyframe.
        frame_b: Frame of the right keyframe.
        preset_name: Identifier of the preset (e.g. "EASE_IN", "BOUNCE").

    Returns:
        bool: True if the preset was applied successfully, False otherwise.
    """
    # Lazy import to avoid circular dependency at module load time
    try:
        from . import easing_presets
        return easing_presets.apply_preset_to_range(fcurve, frame_a, frame_b, preset_name)
    except ImportError:
        warn("easing_presets module not available")
        return False
    except Exception as exc:
        warn(f"Error applying easing preset '{preset_name}': {exc}")
        return False


# ---------------------------------------------------------------------------
# Test notes
# ---------------------------------------------------------------------------
#
# Test 1: sample_fcurve handles None gracefully
# >>> val = sample_fcurve(None, 10.0)
# >>> assert val == 0.0
#
# Test 2: get_adjacent_keyframes finds correct neighbors
# >>> # Setup: object with keyframes at frames 1, 10, 20
# >>> left, right = get_adjacent_keyframes(fcurve, 15.0)
# >>> assert left.co.x == 10.0 and right.co.x == 20.0
#
# Test 3: recalculate_handles adjusts curve to hit target value
# >>> original = fcurve.evaluate(5.0)
# >>> recalculate_handles(fcurve, 5.0, original + 2.0, mode="free")
# >>> new_val = fcurve.evaluate(5.0)
# >>> assert abs(new_val - (original + 2.0)) < 0.1
#
# Test 4: snapshot_fcurve / restore_fcurve round-trips correctly
# >>> snap = snapshot_fcurve(fcurve)
# >>> recalculate_handles(fcurve, 5.0, 999.0)
# >>> restore_fcurve(fcurve, snap)
# >>> assert abs(fcurve.evaluate(5.0) - original) < 0.01
