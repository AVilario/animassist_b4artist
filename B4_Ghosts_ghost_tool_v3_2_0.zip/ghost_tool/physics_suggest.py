"""
physics_suggest.py — Parabolic arc correction for physics-informed ghost suggestions.

This is a Tier 3 stretch-goal feature.  After a ghost is dragged, the user
can invoke "Suggest" to apply a simple parabolic arc correction to nearby
ghosts, simulating gravity.  This is NOT a full physics simulation — it is
a mathematical correction pass.

Suggestions are previewed as a ghost overlay and must be accepted explicitly.
"""

from __future__ import annotations

from typing import Optional

import bpy
from mathutils import Vector

from .ghost_data import GhostStore, Ghost
from . import fcurve_utils


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_GRAVITY_STRENGTH: float = 9.81
"""Default gravity magnitude (m/s^2, matching real-world gravity)."""

DEFAULT_GRAVITY_AXIS: str = "Z"
"""Default axis along which gravity acts (negative direction)."""

GRAVITY_CORRECTION_SCALE: float = 0.1
"""Scale factor applied to displacement-based value corrections.

This factor dampens the raw displacement magnitude (which is in world units)
to produce a reasonable local value delta. It prevents over-correction that
would cause ghosts to "fly away" and maintains visual plausibility while
keeping the f-curve values in a sensible range relative to the scene scale.
"""

POSITION_ADJUSTMENT_SCALE: float = 0.01
"""Scale factor applied to positional adjustments in ballistic preview and correction.

This factor scales the gravitational displacement for visual rendering clarity.
A smaller scale (0.01) produces more subtle arc curvature, allowing the ghost
positions to remain close to the original path while still conveying the
parabolic trajectory. This keeps preview overlays readable without exaggerated
deflections that would obscure the underlying motion.
"""


# ---------------------------------------------------------------------------
# Parabolic Correction
# ---------------------------------------------------------------------------

def _compute_ghost_displacement(
    ghost: Ghost,
    frame_a: float,
    frame_b: float,
    frame_rate: float,
    gravity_strength: float,
    gravity_axis: str,
    axis_idx: int,
) -> dict:
    """Compute physics displacement for a single ghost in a keyframe segment.

    Calculates the parabolic correction and positional adjustment for a ghost
    within a parent keyframe segment, accounting for gravitational acceleration
    over the segment duration.

    The parabolic profile peaks at the segment midpoint (t=0.5) and tapers to
    zero at both parent keyframes (t=0 and t=1), modeling the time-in-air effect
    of projectile motion.

    Args:
        ghost: The ghost to compute displacement for.
        frame_a: Start frame of the parent keyframe segment.
        frame_b: End frame of the parent keyframe segment.
        frame_rate: Scene frame rate (fps).
        gravity_strength: Gravity magnitude in scene units per second^2.
        gravity_axis: Axis of gravity ("X", "Y", or "Z").
        axis_idx: Numeric index of the gravity axis (0=X, 1=Y, 2=Z).

    Returns:
        dict: Displacement result containing:
            - "correction" (float): Value delta to apply to local_value
            - "suggested_position" (Vector): Adjusted world position
            - "delta" (float): Alias for correction
    """
    segment_duration_frames = frame_b - frame_a
    segment_duration_seconds = segment_duration_frames / frame_rate

    # Parametric position within segment [0..1]
    t = (ghost.frame - frame_a) / segment_duration_frames

    # Parabolic profile: peaks at t=0.5, zero at t=0 and t=1
    # This models the "time spent in the air" effect
    parabolic_factor = 4.0 * t * (1.0 - t)

    # Time in seconds for this ghost's position in the arc
    time_s = t * segment_duration_seconds

    # Gravitational displacement: 0.5 * g * t * (T - t)
    # where T is the total segment time
    displacement = 0.5 * gravity_strength * time_s * (segment_duration_seconds - time_s)

    # Apply correction as a value delta
    # The sign depends on the channel axis matching the gravity axis
    channel_lower = ghost.channel.lower()
    correction = 0.0

    if gravity_axis.lower() in channel_lower:
        correction = -displacement * parabolic_factor * GRAVITY_CORRECTION_SCALE

    # Compute suggested world position
    suggested_pos = ghost.world_position.copy()
    grav_vec_component = -gravity_strength * parabolic_factor * POSITION_ADJUSTMENT_SCALE
    suggested_pos[axis_idx] += grav_vec_component

    return {
        "correction": correction,
        "suggested_position": suggested_pos,
        "delta": correction,
    }


def compute_parabolic_suggestion(
    ghost: Ghost,
    store: GhostStore,
    gravity_strength: float = DEFAULT_GRAVITY_STRENGTH,
    gravity_axis: str = DEFAULT_GRAVITY_AXIS,
    frame_rate: float = 24.0,
) -> list[dict]:
    """Compute parabolic arc corrections for ghosts near a reference ghost.

    Given a ghost (typically one just dragged by the user), this function
    identifies the ghost chain it belongs to and applies a parabolic offset
    based on the assumption that the object is under constant gravitational
    acceleration.

    The correction is strongest at the midpoint of the arc and tapers to
    zero at the parent keyframes.

    Args:
        ghost: The reference ghost (usually the one just moved).
        store: The GhostStore containing all ghosts.
        gravity_strength: Magnitude of gravity in scene units per second^2.
        gravity_axis: Axis of gravity ("X", "Y", or "Z").
        frame_rate: Scene frame rate for time conversion.

    Returns:
        list[dict]: Suggested corrections, each containing:
            - "uid" (str): Ghost UID
            - "suggested_value" (float): New local value
            - "suggested_position" (Vector): New world position
            - "delta" (float): The applied correction amount
    """
    # Get the chain this ghost belongs to
    chain = store.get_chain(ghost.object_name, ghost.bone_name, ghost.channel)

    if len(chain) < 3:
        return []

    # Determine gravity vector
    grav_vec = Vector((0, 0, 0))
    axis_idx = {"X": 0, "Y": 1, "Z": 2}.get(gravity_axis.upper(), 2)
    grav_vec[axis_idx] = -gravity_strength

    # Find the parent keyframe frames for the affected range
    frame_a = ghost.parent_frame_a
    frame_b = ghost.parent_frame_b
    segment_duration_frames = frame_b - frame_a
    segment_duration_seconds = segment_duration_frames / frame_rate

    if segment_duration_seconds < 0.001:
        return []

    suggestions = []

    for g in chain:
        # Only affect ghosts in the same parent segment
        if g.parent_frame_a != frame_a or g.parent_frame_b != frame_b:
            continue

        displacement = _compute_ghost_displacement(
            g,
            frame_a,
            frame_b,
            frame_rate,
            gravity_strength,
            gravity_axis,
            axis_idx,
        )

        suggested_value = g.local_value + displacement["correction"]

        suggestions.append({
            "uid": g.uid,
            "suggested_value": suggested_value,
            "suggested_position": displacement["suggested_position"],
            "delta": displacement["delta"],
        })

    return suggestions


def compute_ballistic_preview(
    store: GhostStore,
    gravity_strength: float = DEFAULT_GRAVITY_STRENGTH,
    gravity_axis: str = DEFAULT_GRAVITY_AXIS,
    offset: tuple[float, float, float] = (0.0, 0.0, 0.0),
    frame_rate: float = 24.0,
) -> list[dict]:
    """Compute ballistic preview positions for all ghosts in the store.

    Projects each ghost's position along a parabolic arc based on gravity,
    producing preview positions that can be drawn as an overlay in the viewport.

    Unlike ``compute_parabolic_suggestion`` (which modifies values), this
    function is purely visual — it does not alter ghost data or f-curves.

    Args:
        store: The GhostStore containing ghosts to preview.
        gravity_strength: Gravity magnitude (m/s²).
        gravity_axis: Axis of gravity ("X", "Y", or "Z").
        offset: Manual offset vector applied to all preview positions.
        frame_rate: Scene frame rate for time conversion.

    Returns:
        list[dict]: Preview entries, each with:
            - "uid" (str): Ghost UID
            - "preview_position" (Vector): Predicted world position
            - "frame" (float): Ghost frame
    """
    all_ghosts = sorted(store.all_ghosts, key=lambda g: g.frame)
    if len(all_ghosts) < 2:
        return []

    axis_idx = {"X": 0, "Y": 1, "Z": 2}.get(gravity_axis.upper(), 2)
    offset_vec = Vector(offset)

    first_frame = all_ghosts[0].frame
    last_frame = all_ghosts[-1].frame
    total_frames = last_frame - first_frame
    if total_frames <= 0:
        return []

    total_time = total_frames / frame_rate
    previews = []

    for g in all_ghosts:
        t_sec = (g.frame - first_frame) / frame_rate

        # Parabolic displacement peaking at midpoint: 0.5 * g * t * (T - t)
        displacement = 0.5 * gravity_strength * t_sec * (total_time - t_sec)

        pos = g.world_position.copy()
        pos[axis_idx] -= displacement * POSITION_ADJUSTMENT_SCALE
        pos += offset_vec

        previews.append({
            "uid": g.uid,
            "preview_position": pos,
            "frame": g.frame,
        })

    return previews


def apply_suggestions(
    suggestions: list[dict],
    store: GhostStore,
    scene: bpy.types.Scene,
) -> int:
    """Apply physics suggestions to ghosts and their f-curves.

    Args:
        suggestions: List of suggestion dicts from compute_parabolic_suggestion.
        store: The GhostStore containing the ghosts to update.
        scene: The Blender scene.

    Returns:
        int: Number of ghosts updated.
    """
    applied = 0

    for suggestion in suggestions:
        uid = suggestion["uid"]
        ghost = store.get_by_uid(uid)
        if ghost is None:
            continue

        new_value = suggestion["suggested_value"]
        ghost.local_value = new_value
        ghost.world_position = suggestion["suggested_position"]

        # Update the f-curve
        obj = bpy.data.objects.get(ghost.object_name)
        if obj:
            fc = fcurve_utils.resolve_fcurve(obj, ghost.bone_name, ghost.channel)
            if fc:
                mode = "free"
                if hasattr(scene, 'ghost_tool'):
                    mode = scene.ghost_tool.curve_mode.lower()
                fcurve_utils.recalculate_handles(fc, ghost.frame, new_value, mode=mode)
                applied += 1

    return applied


# ---------------------------------------------------------------------------
# Operator
# ---------------------------------------------------------------------------

class GHOST_OT_physics_suggest(bpy.types.Operator):
    """Apply parabolic arc correction to nearby ghosts (physics suggestion)."""

    bl_idname = "ghost_tool.physics_suggest"
    bl_label = "Physics Suggest"
    bl_options = {'REGISTER', 'UNDO'}

    gravity_strength: bpy.props.FloatProperty(
        name="Gravity Strength",
        description="Gravity magnitude in scene units per second squared",
        default=DEFAULT_GRAVITY_STRENGTH,
        min=0.0,
        max=100.0,
    )  # type: ignore[assignment]

    gravity_axis: bpy.props.EnumProperty(
        name="Gravity Axis",
        description="Axis along which gravity acts (negative direction)",
        items=[
            ("X", "X", "Gravity along -X"),
            ("Y", "Y", "Gravity along -Y"),
            ("Z", "Z", "Gravity along -Z"),
        ],
        default="Z",
    )  # type: ignore[assignment]

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        """Require active ghost display with ghosts present.

        Args:
            context: The current Blender context.

        Returns:
            bool: True if the operator can run.
        """
        if not hasattr(context.scene, 'ghost_tool'):
            return False
        store = GhostStore.get(context.scene)
        return len(store) > 0

    def execute(self, context: bpy.types.Context) -> set[str]:
        """Compute and apply physics suggestions.

        Applies to selected ghosts, or all ghosts if none selected.

        Args:
            context: The current Blender context.

        Returns:
            set[str]: {'FINISHED'} or {'CANCELLED'}.
        """
        store = GhostStore.get(context.scene)
        selected = store.get_selected()

        if not selected:
            # Use all ghosts if none selected
            selected = store.all_ghosts

        if not selected:
            self.report({'WARNING'}, "No ghosts to apply suggestions to")
            return {'CANCELLED'}

        total_applied = 0
        frame_rate = context.scene.render.fps

        for ghost in selected:
            suggestions = compute_parabolic_suggestion(
                ghost, store,
                gravity_strength=self.gravity_strength,
                gravity_axis=self.gravity_axis,
                frame_rate=frame_rate,
            )
            applied = apply_suggestions(suggestions, store, context.scene)
            total_applied += applied

        self.report({'INFO'}, f"Applied physics suggestions to {total_applied} ghosts")
        context.area.tag_redraw()
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

CLASSES: tuple[type, ...] = (
    GHOST_OT_physics_suggest,
)


def register() -> None:
    """Register physics suggestion classes."""
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister() -> None:
    """Unregister physics suggestion classes."""
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
