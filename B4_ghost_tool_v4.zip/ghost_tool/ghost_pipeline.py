"""
ghost_pipeline.py — Central orchestrator for the ghost generation pipeline.

This module provides the GhostPipeline class, the single entry point for
all ghost generation flows.  Whether the user clicks "Generate" manually,
or live mode auto-updates on frame change, everything flows through here.

Pipeline stages:
    1. Frame Source — determine which frames to ghost (from settings)
    2. Evaluate — sample f-curves and world positions at those frames
    3. Cache — store results, check dirty flags
    4. Notify — update GhostStore, tag viewport for redraw

The pipeline also manages live-update handlers (frame_change_post,
depsgraph_update_post) that are registered/unregistered based on the
live_point_ghosts / live_mesh_ghosts settings.

Design goals:
    - Single code path for manual and live generation
    - Throttled updates to prevent performance tanking during scrubbing
    - Dirty-flag system so only changed data is re-evaluated
    - Clean handler lifecycle tied to addon register/unregister
"""

from __future__ import annotations

import time
from typing import Optional

import bpy

from .ghost_data import (
    Ghost,
    GhostStore,
    generate_ghosts,
    generate_ghosts_frame_step,
    generate_ghosts_at_keyframes,
    build_frame_list_from_settings,
    LOCATION_CHANNELS,
)
from .ghost_cache import GhostCache
from .utils import log, warn, debug


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_THROTTLE_SEC: float = 0.05
"""Minimum seconds between live updates (50ms = ~20 updates/sec max)."""


# ---------------------------------------------------------------------------
# GhostPipeline — per-scene orchestrator
# ---------------------------------------------------------------------------

class GhostPipeline:
    """Central orchestrator for ghost generation, caching, and live updates.

    One GhostPipeline instance exists per scene, mirroring the GhostStore
    and GhostCache singletons.  It coordinates:

    - Manual generation (user clicks Generate)
    - Live point ghost updates (frame_change_post)
    - Live mesh ghost updates (frame_change_post, throttled)
    - Dirty detection (settings changed, keyframe edited, frame moved)
    - Throttling to prevent performance issues during scrubbing

    Usage:
        pipeline = GhostPipeline.get(scene)
        pipeline.generate_manual(context)     # manual mode
        pipeline.mark_dirty()                 # flag for live update
        pipeline.update_if_needed(context)    # called from draw handler
    """

    # Per-scene singleton instances
    _instances: dict[str, GhostPipeline] = {}

    # =========================================================================
    # Initialization
    # =========================================================================

    def __init__(self, scene_name: str) -> None:
        """Initialize the pipeline for a scene.

        Args:
            scene_name: The name of the Blender scene this pipeline manages.
        """
        self._scene_name: str = scene_name
        self._cache: Optional[GhostCache] = None

    # --- Singleton access ---

    @classmethod
    def get(cls, scene: bpy.types.Scene) -> GhostPipeline:
        """Retrieve or create the GhostPipeline for a scene.

        Args:
            scene: The Blender scene.

        Returns:
            GhostPipeline: The pipeline instance for this scene.
        """
        key = scene.name
        if key not in cls._instances:
            cls._instances[key] = cls(key)
        return cls._instances[key]

    @classmethod
    def clear_instance(cls, scene_name: str) -> None:
        """Remove the pipeline instance for a scene."""
        cls._instances.pop(scene_name, None)

    @classmethod
    def clear_all_instances(cls) -> None:
        """Remove all pipeline instances (addon unregistration)."""
        cls._instances.clear()

    # --- Cache access ---

    def _get_cache(self) -> GhostCache:
        """Lazily get or create the cache for this scene.

        Returns:
            GhostCache: The cache instance.
        """
        if self._cache is None:
            self._cache = GhostCache.get(self._scene_name)
        return self._cache

    # --- Dirty flag pass-through ---

    def mark_dirty(self) -> None:
        """Mark the pipeline as needing regeneration.

        Called by frame_change or depsgraph_update handlers, or when
        the user changes settings.
        """
        self._get_cache().mark_dirty()

    def mark_object_dirty(self, object_name: str) -> None:
        """Mark a specific object as needing re-evaluation.

        Called when a keyframe is edited on a specific object.

        Args:
            object_name: The name of the modified object.
        """
        self._get_cache().mark_object_dirty(object_name)

    # --- Manual generation (user clicks Generate) ---

    def generate_manual(
        self,
        context: bpy.types.Context,
        obj: bpy.types.Object,
        armature: Optional[bpy.types.Object],
        bones: list[str],
        channels: list[str],
        level: int,
        frame_range: Optional[tuple[int, int]] = None,
        clear_existing: bool = True,
    ) -> int:
        """Run a full ghost generation pass (manual / button-press mode).

        This is the equivalent of the old generate_and_store_ghosts() but
        routed through the pipeline for cache awareness.

        Args:
            context: The current Blender context.
            obj: The object to generate ghosts for.
            armature: The armature (or None).
            bones: Pose bone names.
            channels: Channel identifiers.
            level: Subdivision depth (for SUBDIVISION mode).
            frame_range: Optional frame range.
            clear_existing: Whether to clear existing ghosts first.

        Returns:
            int: Number of ghosts generated.
        """
        cache = self._get_cache()
        store = GhostStore.get(context.scene)
        settings = context.scene.ghost_tool

        if clear_existing:
            store.clear()
            cache.invalidate_all()

        # Determine generation mode from settings; ghost_mode: SUBDIVISION, FRAME_STEP, or KEYFRAMES_ONLY
        mode = getattr(settings, 'ghost_mode', 'SUBDIVISION')

        debug(f"Manual generate: mode={mode}, obj={obj.name}")

        # Run the appropriate generator
        ghosts = self._evaluate_ghosts(
            context, obj, armature, bones, channels, level, frame_range, mode, settings
        )

        # Store results
        store.replace_all(ghosts)

        # Update cache metadata
        cache.last_frame = context.scene.frame_current
        cache.update_settings_hash(compute_settings_hash(settings))
        cache.mark_clean()

        debug(f"Generated {len(ghosts)} ghosts, cache clean.")

        return len(ghosts)

    # --- Live update check (called from draw handler or timer) ---

    def update_if_needed(self, context: bpy.types.Context) -> bool:
        """Check if regeneration is needed and run it if so.

        This is designed to be called frequently (e.g., every draw cycle).
        It checks dirty flags and throttle timing before doing any work.

        Args:
            context: The current Blender context.

        Returns:
            bool: True if an update was performed.
        """
        scene = context.scene
        if not hasattr(scene, 'ghost_tool'):
            return False

        settings = scene.ghost_tool

        # Only run if any live mode is enabled
        live_points = getattr(settings, 'live_point_ghosts', False)
        live_mesh = getattr(settings, 'live_mesh_ghosts', False)
        if not live_points and not live_mesh:
            return False

        # Check freeze
        if getattr(settings, 'live_freeze', False):
            return False

        # Skip during playback to avoid performance issues
        if context.screen and context.screen.is_animation_playing:
            return False

        cache = self._get_cache()

        # Check if anything changed
        current_frame = scene.frame_current
        new_hash = compute_settings_hash(settings)

        frame_changed = cache.last_frame != current_frame
        settings_changed = cache.needs_settings_update(new_hash)

        if not frame_changed and not settings_changed and not cache.is_dirty:
            return False

        # Throttle check
        throttle_ms = getattr(settings, 'live_throttle_ms', 50)
        throttle_sec = throttle_ms / 1000.0
        now = time.monotonic()
        if now - cache.last_update_time < throttle_sec:
            return False

        reason = []
        if frame_changed:
            reason.append(f"frame:{cache.last_frame}->{current_frame}")
        if settings_changed:
            reason.append("settings")
        if cache.is_dirty:
            reason.append("dirty")
        debug(f"Live update triggered: {', '.join(reason)}")

        # Run the generation
        self._run_live_update(context, settings, new_hash)
        return True

    # =========================================================================
    # Live Updates
    # =========================================================================

    def _run_live_update(
        self,
        context: bpy.types.Context,
        settings: bpy.types.PropertyGroup,
        settings_hash: str,
    ) -> None:
        """Execute a live regeneration pass.

        Uses the same generation logic as manual mode but operates on
        the active object automatically.

        Args:
            context: The Blender context.
            settings: GhostToolSceneSettings.
            settings_hash: Pre-computed hash of current settings.
        """
        obj = context.active_object
        if not obj:
            return

        cache = self._get_cache()

        live_points = getattr(settings, 'live_point_ghosts', False)
        live_mesh = getattr(settings, 'live_mesh_ghosts', False)

        # Update point ghosts if enabled
        if live_points:
            self._update_point_ghosts_live(context, obj, settings)

        # Update cache state
        cache.last_frame = context.scene.frame_current
        cache.update_settings_hash(settings_hash)
        cache.mark_clean()

        # Update mesh ghosts if enabled
        if live_mesh and getattr(settings, 'show_mesh_ghosts', False):
            self._update_mesh_ghosts_live(context, settings)

        # Tag viewport for redraw
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

    def _update_point_ghosts_live(
        self,
        context: bpy.types.Context,
        obj: bpy.types.Object,
        settings: bpy.types.PropertyGroup,
    ) -> None:
        """Update point ghosts in live mode.

        Evaluates and stores point ghosts for the active object if it has
        animation data. Skips silently if there's no animation.

        Args:
            context: Blender context.
            obj: The object to update point ghosts for.
            settings: GhostToolSceneSettings.
        """
        if not obj.animation_data or not obj.animation_data.action:
            # No animation data — can't generate point ghosts
            return

        store = GhostStore.get(context.scene)

        # Determine bones and armature
        bones: list[str] = []
        armature = None
        if obj.type == 'ARMATURE':
            armature = obj
            if context.selected_pose_bones:
                bones = [b.name for b in context.selected_pose_bones]
            elif obj.data.bones:
                bones = [b.name for b in obj.data.bones if b.select]

        # Determine frame range; ghost_range_mode: AROUND_CURSOR, FULL_TIMELINE, BETWEEN_KEYS, or CUSTOM
        frame_range = None
        range_mode = getattr(settings, 'ghost_range_mode', 'AROUND_CURSOR')
        if range_mode == "CUSTOM":
            frame_range = (settings.custom_range_start, settings.custom_range_end)
        elif range_mode == "FULL_TIMELINE":
            frame_range = (context.scene.frame_start, context.scene.frame_end)

        mode = getattr(settings, 'ghost_mode', 'SUBDIVISION')
        channels = LOCATION_CHANNELS

        # Evaluate and store
        ghosts = self._evaluate_ghosts(
            context, obj, armature, bones, channels,
            settings.subdivision_level, frame_range, mode, settings
        )
        store.replace_all(ghosts)

    def _update_mesh_ghosts_live(
        self,
        context: bpy.types.Context,
        settings: bpy.types.PropertyGroup,
    ) -> None:
        """Attempt incremental mesh ghost update; fall back to full rebuild.

        First tries the fast foreach_set path.  If that fails (frame window
        shifted, topology changed, no existing ghosts), does a full
        generate_mesh_ghosts() call instead.

        Args:
            context: Blender context.
            settings: GhostToolSceneSettings.
        """
        try:
            from .mesh_ghosts import (
                update_mesh_ghosts_incremental,
                generate_mesh_ghosts,
                _resolve_mesh_object,
            )

            # Try incremental first (fast path)
            success = update_mesh_ghosts_incremental(context)

            if not success:
                # Need full rebuild — frame window shifted or no existing ghosts
                obj = context.active_object
                if obj is None:
                    return

                mesh_obj = _resolve_mesh_object(obj)
                if mesh_obj is None:
                    return

                current_frame = context.scene.frame_current
                past_count = getattr(settings, 'mesh_ghost_past_count', 3)
                future_count = getattr(settings, 'mesh_ghost_future_count', 3)
                frame_step = getattr(settings, 'mesh_ghost_step', 2)
                # mesh_ghost_mode: display style for mesh ghosts (SOLID, WIREFRAME, BOUNDS)
                mode = getattr(settings, 'mesh_ghost_mode', 'SOLID')

                # Build list of frames before and after the current frame
                ghost_frames = []
                # Add past frames at regular intervals
                for i in range(1, past_count + 1):
                    ghost_frames.append(current_frame - i * frame_step)
                # Add future frames at regular intervals
                for i in range(1, future_count + 1):
                    ghost_frames.append(current_frame + i * frame_step)

                start = context.scene.frame_start
                end = context.scene.frame_end
                ghost_frames = [f for f in ghost_frames if start <= f <= end]

                generate_mesh_ghosts(
                    context=context,
                    source_obj=obj,
                    ghost_frames=ghost_frames,
                    mode=mode,
                    past_count=past_count,
                    future_count=future_count,
                    step=1,
                )

                debug("Mesh ghosts: full rebuild")
            else:
                debug("Mesh ghosts: incremental update")

        except Exception as exc:
            warn(f"Mesh ghost update error: {exc}")

    # =========================================================================
    # Ghost Evaluation (shared by manual and live)
    # =========================================================================

    def _evaluate_ghosts(
        self,
        context: bpy.types.Context,
        obj: bpy.types.Object,
        armature: Optional[bpy.types.Object],
        bones: list[str],
        channels: list[str],
        level: int,
        frame_range: Optional[tuple[int, int]],
        mode: str,
        settings: bpy.types.PropertyGroup,
    ) -> list[Ghost]:
        """Evaluate ghosts using the appropriate generator.

        This is the shared evaluation logic used by both manual and live
        generation paths.

        Args:
            context: Blender context.
            obj: Target object.
            armature: Armature (or None).
            bones: Bone names.
            channels: Channel identifiers.
            level: Subdivision depth.
            frame_range: Optional frame range.
            mode: Ghost mode string (SUBDIVISION, FRAME_STEP, KEYFRAMES_ONLY).
            settings: GhostToolSceneSettings.

        Returns:
            list[Ghost]: Evaluated ghost objects.
        """
        # FRAME_STEP mode: generate ghosts at fixed frame intervals
        if mode == "FRAME_STEP":
            frame_list = build_frame_list_from_settings(settings, context.scene)
            return generate_ghosts_frame_step(obj, armature, bones, channels, frame_list)
        # KEYFRAMES_ONLY mode: generate ghosts only at existing keyframes
        elif mode == "KEYFRAMES_ONLY":
            return generate_ghosts_at_keyframes(obj, armature, bones, channels, frame_range)
        else:
            # SUBDIVISION — original mode or unknown mode fallback
            if mode != "SUBDIVISION":
                warn(f"Unknown ghost mode '{mode}', falling back to SUBDIVISION")
            return generate_ghosts(obj, armature, bones, channels, level, frame_range)

    # =========================================================================
    # Cache Management
    # =========================================================================

    def clear(self, context: bpy.types.Context) -> int:
        """Clear all ghosts and cache for this scene.

        Args:
            context: Blender context.

        Returns:
            int: Number of ghosts that were cleared.
        """
        store = GhostStore.get(context.scene)
        count = len(store)
        store.clear()

        cache = self._get_cache()
        cache.invalidate_all()

        debug(f"Cleared {count} ghosts + cache.")

        return count


# ---------------------------------------------------------------------------
# Settings hash — detect when properties change
# ---------------------------------------------------------------------------

# WARNING: When adding new settings properties to GhostToolSceneSettings,
# you MUST add them here too, or cache invalidation will silently break.
def compute_settings_hash(settings: bpy.types.PropertyGroup) -> str:
    """Compute a hash string from ghost tool settings for change detection.

    This captures all settings that affect ghost generation so the pipeline
    can detect when regeneration is needed. Any change to these properties
    invalidates the cache and triggers a full regeneration on the next update.

    Args:
        settings: GhostToolSceneSettings PropertyGroup.

    Returns:
        str: A short hash string representing the current settings state.
    """
    # Collect all generation-affecting properties into a fingerprint tuple
    # NOTE: When adding new settings to GhostToolSceneSettings, add them here too
    settings_fingerprint = (
        getattr(settings, 'ghost_mode', 'SUBDIVISION'),
        getattr(settings, 'ghost_range_mode', 'AROUND_CURSOR'),
        getattr(settings, 'subdivision_level', 1),
        getattr(settings, 'frame_step', 2),
        getattr(settings, 'ghosts_before', 8),
        getattr(settings, 'ghosts_after', 8),
        getattr(settings, 'custom_range_start', 1),
        getattr(settings, 'custom_range_end', 250),
        getattr(settings, 'ghost_color_mode', 'TIME'),
        getattr(settings, 'ghost_fade_factor', 0.7),
        getattr(settings, 'show_arc_lines', True),
        getattr(settings, 'arc_line_style', 'SPEED'),
        getattr(settings, 'show_mesh_ghosts', False),
        getattr(settings, 'mesh_ghost_past_count', 3),
        getattr(settings, 'mesh_ghost_future_count', 3),
        getattr(settings, 'mesh_ghost_step', 2),
        getattr(settings, 'mesh_ghost_opacity', 0.35),
    )

    # Use a fast hash — we don't need cryptographic strength
    return str(hash(settings_fingerprint))


# ---------------------------------------------------------------------------
# Handler Management for Live Mode
# ---------------------------------------------------------------------------

# Module-level references for handler registration/removal.
# These store handler function objects to enable safe unregistration later.
_frame_change_handler = None
_depsgraph_update_handler = None


def _on_frame_change_pipeline(scene: bpy.types.Scene, depsgraph=None) -> None:
    """Handler called on frame_change_post.

    Marks the pipeline dirty so the next draw cycle triggers a live update.
    This lightweight handler is always registered but only does work when
    ghost display is active and live mode is enabled.

    Args:
        scene: The scene that changed.
        depsgraph: The dependency graph (unused, but required by Blender).
    """
    if not hasattr(scene, 'ghost_tool'):
        return

    settings = scene.ghost_tool
    if not settings.is_active:
        return

    # Only mark dirty if any live mode is enabled
    live_points = getattr(settings, 'live_point_ghosts', False)
    live_mesh = getattr(settings, 'live_mesh_ghosts', False)
    if not live_points and not live_mesh:
        return

    pipeline = GhostPipeline.get(scene)
    pipeline.mark_dirty()


def _on_depsgraph_update_pipeline(scene: bpy.types.Scene, depsgraph=None) -> None:
    """Handler called on depsgraph_update_post.

    Detects keyframe edits and marks the affected object dirty so live update
    will regenerate ghosts on the next draw cycle.

    Args:
        scene: The scene that was updated.
        depsgraph: The dependency graph with update info.
    """
    if not hasattr(scene, 'ghost_tool'):
        return

    settings = scene.ghost_tool
    if not settings.is_active:
        return

    # Only check depsgraph updates if any live mode is enabled
    live_points = getattr(settings, 'live_point_ghosts', False)
    live_mesh = getattr(settings, 'live_mesh_ghosts', False)
    if not live_points and not live_mesh:
        return

    if depsgraph is None:
        return

    pipeline = GhostPipeline.get(scene)

    # Check if any animation data was updated (Action or Object with animation)
    for update in depsgraph.updates:
        if hasattr(update, 'id') and update.id is not None:
            # If an Action or Object was updated, mark dirty and regenerate
            if isinstance(update.id, (bpy.types.Action, bpy.types.Object)):
                pipeline.mark_dirty()
                break


def _register_live_handlers() -> None:
    """Register frame_change and depsgraph handlers for live mode.

    Safe to call multiple times — checks for existing registration.
    """
    global _frame_change_handler, _depsgraph_update_handler

    if _frame_change_handler is None:
        _frame_change_handler = _on_frame_change_pipeline
        if _frame_change_handler not in bpy.app.handlers.frame_change_post:
            bpy.app.handlers.frame_change_post.append(_frame_change_handler)
            debug("Registered frame_change_post handler.")

    if _depsgraph_update_handler is None:
        _depsgraph_update_handler = _on_depsgraph_update_pipeline
        if _depsgraph_update_handler not in bpy.app.handlers.depsgraph_update_post:
            bpy.app.handlers.depsgraph_update_post.append(_depsgraph_update_handler)
            debug("Registered depsgraph_update_post handler.")


def _unregister_live_handlers() -> None:
    """Remove frame_change and depsgraph handlers.

    Safe to call multiple times — handles already-removed handlers gracefully.
    """
    global _frame_change_handler, _depsgraph_update_handler

    if _frame_change_handler is not None:
        try:
            bpy.app.handlers.frame_change_post.remove(_frame_change_handler)
        except ValueError:
            debug("Handler frame_change_post already removed")
        _frame_change_handler = None
        debug("Unregistered frame_change_post handler.")

    if _depsgraph_update_handler is not None:
        try:
            bpy.app.handlers.depsgraph_update_post.remove(_depsgraph_update_handler)
        except ValueError:
            debug("Handler depsgraph_update_post already removed")
        _depsgraph_update_handler = None
        debug("Unregistered depsgraph_update_post handler.")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register() -> None:
    """Register the pipeline module.

    Registers live-mode app handlers.  The handlers are lightweight
    (just set a dirty flag) so they're always registered — the pipeline's
    update_if_needed() checks the live toggle before doing real work.
    """
    _register_live_handlers()
    log("Ghost pipeline registered.")


def unregister() -> None:
    """Unregister the pipeline module.

    Removes app handlers and clears all pipeline instances.
    """
    _unregister_live_handlers()
    GhostPipeline.clear_all_instances()
    GhostCache.clear_all_instances()
    log("Ghost pipeline unregistered.")
