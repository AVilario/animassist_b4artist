"""
Ghost Tool — Cascadeur-style ghost keyframe visualization and manipulation for Blender.

This addon gives Blender animators the ability to visualize and directly
manipulate in-between frames in 3D space.  It generates "ghost" markers at
mathematically interpolated positions between existing keyframes, displays
them as draggable 3D handles in the viewport, and recalculates f-curves in
real time as ghosts are moved.

Addon registration file.  All modules are imported and their register/
unregister functions are called in the correct dependency order.
"""

bl_info = {
    "name": "Ghost Tool",
    "author": "GoingGhost",
    "version": (3, 2, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Ghost Tool",
    "description": "Cascadeur-style ghost keyframe visualization and manipulation for Blender",
    "category": "Animation",
    "doc_url": "",
    "tracker_url": "",
}

# ---------------------------------------------------------------------------
# Module imports — ordered by dependency
# ---------------------------------------------------------------------------

# Submodules are imported lazily within register() to handle cases where
# Blender reloads the addon (the importlib.reload chain).

_modules_loaded = False


def _clear_pycache():
    """Remove stale __pycache__ bytecode to prevent version mismatch issues.

    When a new version of the addon is installed over an old one,
    Blender/Bforartists may use cached .pyc files from the previous version
    instead of the new .py source.  This function deletes the __pycache__
    directory on every load to force a fresh compile.
    """
    import os
    import shutil
    from . import utils

    addon_dir = os.path.dirname(os.path.abspath(__file__))
    cache_dir = os.path.join(addon_dir, "__pycache__")

    if os.path.isdir(cache_dir):
        try:
            shutil.rmtree(cache_dir)
            utils.log(f"Cleared __pycache__ at {cache_dir}")
        except (OSError, IOError) as exc:
            utils.warn(f"Could not clear __pycache__: {exc}")


# Always clear bytecode cache on module load to avoid stale .pyc issues
_clear_pycache()


def _import_modules():
    """Import all submodules.  Handles both first-load and reload scenarios."""
    global _modules_loaded

    import importlib

    # First-time imports
    from . import utils
    from . import ghost_data
    from . import session_state
    from . import ghost_cache
    from . import ghost_pipeline
    from . import fcurve_utils
    from . import easing_presets
    from . import snapshot
    from . import physics_suggest
    from . import export_import
    from . import modal_operator
    from . import selection_operators
    from . import viewport_draw
    from . import ui_panel
    from . import preferences
    from . import api
    from . import mesh_ghosts

    if _modules_loaded:
        # Reload all modules when the addon is re-enabled (fresh state for debugging/updates)
        importlib.reload(utils)
        importlib.reload(ghost_data)
        importlib.reload(session_state)
        importlib.reload(ghost_cache)
        importlib.reload(ghost_pipeline)
        importlib.reload(fcurve_utils)
        importlib.reload(easing_presets)
        importlib.reload(snapshot)
        importlib.reload(physics_suggest)
        importlib.reload(export_import)
        importlib.reload(modal_operator)
        importlib.reload(selection_operators)
        importlib.reload(mesh_ghosts)
        importlib.reload(viewport_draw)
        importlib.reload(ui_panel)
        importlib.reload(preferences)
        importlib.reload(api)

    _modules_loaded = True

    # Return dict for downstream register/unregister calls
    return {
        "utils": utils,
        "ghost_data": ghost_data,
        "session_state": session_state,
        "ghost_cache": ghost_cache,
        "ghost_pipeline": ghost_pipeline,
        "fcurve_utils": fcurve_utils,
        "easing_presets": easing_presets,
        "snapshot": snapshot,
        "physics_suggest": physics_suggest,
        "export_import": export_import,
        "modal_operator": modal_operator,
        "selection_operators": selection_operators,
        "mesh_ghosts": mesh_ghosts,
        "viewport_draw": viewport_draw,
        "ui_panel": ui_panel,
        "preferences": preferences,
        "api": api,
    }


# ---------------------------------------------------------------------------
# Registration Order
#
# Dependencies flow downward; each module must be registered before modules
# that reference its classes or properties.
#
# 1.  utils           (no dependencies, no registration needed)
# 2.  ghost_data      (registers GhostToolSceneSettings PropertyGroup)
# 3.  ghost_cache     (no registration needed — pure Python class)
# 4.  ghost_pipeline  (registers app handlers — after ghost_data)
# 5.  fcurve_utils    (no registration needed — pure functions)
# 6.  easing_presets  (registers GHOST_OT_apply_easing)
# 7.  snapshot        (registers snapshot operators)
# 8.  physics_suggest (registers GHOST_OT_physics_suggest)
# 9.  export_import   (registers export/import operators)
# 10. modal_operator  (registers GhostDragOperator + generate/clear/pin ops)
# 11. selection_operators (registers GHOST_OT_box_select — after modal ops)
# 12. mesh_ghosts     (registers mesh ghost operators)
# 13. viewport_draw   (registers draw handlers — after operators so they exist)
# 14. ui_panel        (registers panels — after all operators they reference)
# 15. preferences     (registers AddonPreferences + keymaps — last)
# ---------------------------------------------------------------------------

_REGISTER_ORDER = [
    "ghost_data",
    "ghost_pipeline",
    "easing_presets",
    "snapshot",
    "physics_suggest",
    "export_import",
    "modal_operator",
    "selection_operators",
    "mesh_ghosts",
    "viewport_draw",
    "ui_panel",
    "preferences",
]


def register() -> None:
    """Register all Ghost Tool modules in dependency order.

    If any module fails to register, previously registered modules are rolled back
    and a RuntimeError is raised. This ensures a clean state on failure.
    """
    from . import utils
    import traceback

    modules = _import_modules()

    utils.log("Registering addon...")

    # Track successfully registered modules for rollback on failure
    registered = []

    # Register in dependency order (see _REGISTER_ORDER comment above)
    for module_name in _REGISTER_ORDER:
        module = modules.get(module_name)
        if module and hasattr(module, 'register'):
            try:
                module.register()
                registered.append(module)
                utils.log(f"  Registered: {module_name}")
            except Exception as exc:
                # Log the error
                utils.warn(f"ERROR registering {module_name}: {exc}")
                traceback.print_exc()

                # Roll back previously registered modules
                for prev_mod in reversed(registered):
                    try:
                        prev_mod.unregister()
                    except Exception as rollback_exc:
                        traceback.print_exc()

                raise RuntimeError(f"Ghost Tool registration failed at {module_name}: {exc}") from exc

    utils.log(f"Addon v{'.'.join(str(v) for v in bl_info['version'])} registered.")


def unregister() -> None:
    """Unregister all Ghost Tool modules in reverse dependency order.

    Draw handlers are removed first to prevent crashes from stale callbacks.
    """
    from . import utils

    modules = _import_modules()

    utils.log("Unregistering addon...")

    # Unregister in reverse dependency order (UI -> viewport -> operators -> data)
    for module_name in reversed(_REGISTER_ORDER):
        module = modules.get(module_name)
        if module and hasattr(module, 'unregister'):
            try:
                module.unregister()
                utils.log(f"  Unregistered: {module_name}")
            except Exception as exc:
                # Log but continue: ensure all modules are unregistered
                utils.warn(f"ERROR unregistering {module_name}: {exc}")
                import traceback
                traceback.print_exc()

    # Clean up the API callback registry (external addon listeners)
    try:
        from . import api
        api.clear_all_callbacks()
    except Exception as exc:
        utils.warn(f"Failed to clear API callbacks during unregister: {exc}")

    # Clean up transient session state (hover, selection)
    try:
        from .session_state import SessionState
        SessionState.clear_all_instances()
    except Exception as exc:
        utils.warn(f"Failed to clear SessionState during unregister: {exc}")

    utils.log("Addon unregistered.")


# ---------------------------------------------------------------------------
# Allow running as a script for quick testing
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    register()
