# --- EDITOR HEADER TOOLBARS ---
"""Compact toolbar strips appended to editor headers for rapid-fire tools.

These toolbars surface the most frequently-used animation actions directly
in the header bar of each editor, eliminating the need to open the sidebar
for routine operations like breakdown percentages, retime presets, and
transform matching.

Placement rationale
-------------------
Animators perform these actions hundreds of times per shot.  Burying them
in sidebar panels forces a mouse trip away from the working area.  Header
toolbars keep the controls one click away while eyes stay on the curves,
keys, or viewport.

Registration
------------
Each ``_draw_*`` function is appended to the corresponding Blender header
class.  ``register()`` / ``unregister()`` manage the lifecycle and track
appended functions for clean removal.
"""

from __future__ import annotations

import bpy

# Track appended draw functions for clean unregister.
_appended_header_draws: list[tuple[type, object]] = []


# ---------------------------------------------------------------------------
# Shared toolbar row builders (DRY helpers used by multiple editors)
# ---------------------------------------------------------------------------

def _draw_breakdown_row(layout: bpy.types.UILayout) -> None:
    """Draw breakdown percentage buttons (25/50/75) and a drag-breakdown icon.

    Used identically in both the Dope Sheet and Graph Editor headers so
    animators retain muscle memory when switching editors.
    """
    row = layout.row(align=True)
    row.separator()

    for percent_value, label in ((25, "25"), (50, "50"), (75, "75")):
        op = row.operator(
            "animassist.breakdown_percentage",
            text=label,
        )
        op.percent = percent_value

    row.operator(
        "animassist.modal_drag_breakdown",
        text="",
        icon="MOUSE_MOVE",
    )


def _draw_pushpull_row(layout: bpy.types.UILayout) -> None:
    """Draw push/pull buttons that nudge the current key toward neighbours.

    Four directional buttons: push toward previous, pull toward previous,
    pull toward next, push toward next.
    """
    row = layout.row(align=True)
    row.separator()

    row.operator("animassist.breakdown_push_prev", text="", icon="TRIA_LEFT")
    row.operator("animassist.breakdown_pull_prev", text="", icon="BACK")
    row.operator("animassist.breakdown_pull_next", text="", icon="FORWARD")
    row.operator("animassist.breakdown_push_next", text="", icon="TRIA_RIGHT")


def _draw_retime_row(layout: bpy.types.UILayout) -> None:
    """Draw speed-scaling preset buttons (80/90/110/120%) and a ripple button.

    Each number represents the playback-speed percentage applied to selected
    keys.  The ripple button shifts all downstream keys to accommodate the
    new timing.
    """
    row = layout.row(align=True)
    row.separator()

    for speed_factor, label in ((0.8, "80"), (0.9, "90"), (1.1, "110"), (1.2, "120")):
        op = row.operator(
            "animassist.p6_scale_keys",
            text=label,
        )
        op.scale_factor = speed_factor

    row.operator(
        "animassist.p6_ripple_forward",
        text="",
        icon="TRACKING_FORWARDS_SINGLE",
    )


# ---------------------------------------------------------------------------
# Dope Sheet header toolbar
# ---------------------------------------------------------------------------

def _draw_dopesheet_toolbar(self, context: bpy.types.Context) -> None:
    """Append breakdown, push/pull, retime, and selection shortcuts to the
    Dope Sheet header.

    Groups are visually separated so the animator can find them at a glance:
        [Breakdown 25|50|75|Drag]  [Push/Pull ◄►]  [Retime 80|90|110|120|Ripple]  [Select ◄ ● ►]
    """
    layout = self.layout

    _draw_breakdown_row(layout)
    _draw_pushpull_row(layout)
    _draw_retime_row(layout)

    # -- Key selection shortcuts (Dope Sheet only) --
    select_row = layout.row(align=True)
    select_row.separator()

    select_row.operator(
        "animassist.select_frame_range",
        text="",
        icon="TRIA_LEFT",
    )
    select_row.operator(
        "animassist.select_all_visible",
        text="",
        icon="KEYFRAME",
    )
    select_row.operator(
        "animassist.select_first_last",
        text="",
        icon="TRIA_RIGHT",
    )


# ---------------------------------------------------------------------------
# Graph Editor header toolbar
# ---------------------------------------------------------------------------

def _draw_graph_editor_toolbar(self, context: bpy.types.Context) -> None:
    """Append breakdown and retime shortcuts to the Graph Editor header.

    Mirrors the Dope Sheet toolbar so muscle memory transfers between editors.
    Omits key-selection shortcuts (Graph Editor has its own selection tools).
    """
    layout = self.layout

    _draw_breakdown_row(layout)
    _draw_pushpull_row(layout)
    _draw_retime_row(layout)


# ---------------------------------------------------------------------------
# 3D Viewport header toolbar
# ---------------------------------------------------------------------------

def _draw_viewport_toolbar(self, context: bpy.types.Context) -> None:
    """Append trajectory toggle, issue navigation, and quick-match buttons
    to the 3D Viewport header.

    Only draws when the active object is an armature, so it stays invisible
    during modelling or other non-animation work.
    """
    active_object = context.active_object
    if active_object is None or active_object.type != "ARMATURE":
        return

    layout = self.layout

    # -- Trajectory overlay toggle + issue nav --
    trajectory_row = layout.row(align=True)
    trajectory_row.separator()

    trajectory_row.operator(
        "animassist.p5_enable_overlay",
        text="",
        icon="CURVE_PATH",
    )
    trajectory_row.operator(
        "animassist.p5_disable_overlay",
        text="",
        icon="PANEL_CLOSE",
    )

    issue_nav_row = layout.row(align=True)
    issue_nav_row.operator(
        "animassist.p5_jump_prev_issue",
        text="",
        icon="TRIA_LEFT",
    )
    issue_nav_row.operator(
        "animassist.p5_run_diagnostics",
        text="",
        icon="VIEWZOOM",
    )
    issue_nav_row.operator(
        "animassist.p5_jump_next_issue",
        text="",
        icon="TRIA_RIGHT",
    )

    # -- Quick match (only in Pose Mode) --
    if context.mode == "POSE":
        match_row = layout.row(align=True)
        match_row.separator()

        match_row.operator("animassist.p8_match_to_world", text="W")
        match_row.operator("animassist.p8_match_to_parent", text="P")
        match_row.operator("animassist.p8_visual_match", text="V")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

def register() -> None:
    """Append toolbar draw functions to editor headers."""
    _append_pairs = (
        (bpy.types.DOPESHEET_HT_header, _draw_dopesheet_toolbar),
        (bpy.types.GRAPH_HT_header, _draw_graph_editor_toolbar),
        (bpy.types.VIEW3D_HT_header, _draw_viewport_toolbar),
    )

    for header_class, draw_function in _append_pairs:
        header_class.append(draw_function)
        _appended_header_draws.append((header_class, draw_function))


def unregister() -> None:
    """Remove all appended toolbar draw functions from headers."""
    for header_class, draw_function in reversed(_appended_header_draws):
        header_class.remove(draw_function)
    _appended_header_draws.clear()
